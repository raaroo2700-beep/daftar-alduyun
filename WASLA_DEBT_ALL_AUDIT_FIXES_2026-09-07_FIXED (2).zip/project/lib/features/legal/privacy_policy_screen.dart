import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';

/// شاشة سياسة الخصوصية. المحتوى هنا مسودة مبنية على سلوك التطبيق الفعلي
/// الحالي (تخزين محلي، نسخ احتياطي اختياري إلى Google Drive الخاص
/// بالمستخدم، تفعيل عبر معرّف جهاز). يُنصح بمراجعتها من مختص قانوني
/// وتحديث معلومات التواصل قبل النشر النهائي على المتجر.
class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  static const String _lastUpdated = '2026-09-07';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سياسة الخصوصية')),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingLarge),
        children: const [
          Text(
            'سياسة الخصوصية — تطبيق دفتر الديون',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 4),
          Text(
            'آخر تحديث: $_lastUpdated',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          SizedBox(height: 20),
          _PolicySection(
            title: '١. البيانات التي يخزّنها التطبيق',
            body:
                'يقوم تطبيق "دفتر الديون" بتخزين بيانات العملاء والمعاملات '
                'والمرفقات التي تُدخلها بنفسك (مثل الأسماء والمبالغ '
                'والملاحظات وصور الفواتير) محليًا فقط على جهازك، داخل '
                'قاعدة بيانات خاصة بالتطبيق. لا يتم إرسال هذه البيانات إلى '
                'أي خادم خاص بنا، ولا تتم مشاركتها مع أي طرف ثالث.',
          ),
          _PolicySection(
            title: '٢. النسخ الاحتياطي',
            body:
                'يمكنك اختياريًا إنشاء نسخة احتياطية من بياناتك وحفظها '
                'محليًا على جهازك في مجلد تختاره، أو رفعها إلى حساب '
                'Google Drive الخاص بك. في الحالتين تبقى النسخة الاحتياطية '
                'ملكًا لك بالكامل: النسخة المحلية على جهازك فقط، والنسخة '
                'على Google Drive داخل مساحتك الشخصية على ذلك الحساب فقط، '
                'ولا يملك مطوّرو التطبيق أي وصول إليها.',
          ),
          _PolicySection(
            title: '٣. تفعيل البرنامج',
            body:
                'لإدارة التفعيل، يُنشئ التطبيق معرّفًا فريدًا لجهازك '
                '(Device ID) ويرسله إلى خادم التفعيل للتحقق من صلاحية رمز '
                'التفعيل فقط. لا يحتوي هذا المعرّف على أي معلومات شخصية '
                'عنك، ولا يُستخدم لأي غرض آخر غير ربط الترخيص بجهازك.',
          ),
          _PolicySection(
            title: '٤. صلاحيات Google Drive',
            body:
                'عند تفعيلك ميزة النسخ الاحتياطي على Google Drive، يطلب '
                'التطبيق صلاحية محدودة (drive.file) تتيح له فقط رؤية '
                'وإدارة الملفات التي أنشأها هو نفسه على حسابك، ولا يمكنه '
                'الوصول إلى أي ملفات أخرى في حسابك على Google Drive.',
          ),
          _PolicySection(
            title: '٥. عدم وجود إعلانات أو تتبّع',
            body:
                'لا يعرض التطبيق أي إعلانات، ولا يشارك بياناتك مع شركات '
                'إعلانية أو تحليلية من أي نوع.',
          ),
          _PolicySection(
            title: '٦. حذف البيانات',
            body:
                'يمكنك حذف بياناتك في أي وقت من داخل التطبيق (حذف العملاء '
                'أو المعاملات)، أو بإلغاء تثبيت التطبيق بالكامل مما يحذف '
                'قاعدة البيانات المحلية. النسخ الاحتياطية المحفوظة على '
                'جهازك أو على Google Drive الخاص بك تبقى تحت سيطرتك ويجب '
                'حذفها يدويًا إن رغبت.',
          ),
          _PolicySection(
            title: '٧. التواصل بخصوص الخصوصية',
            body:
                'لأي استفسار يخص هذه السياسة أو بياناتك، يمكنك التواصل عبر '
                'support@wasla.com أو أرقام واتساب الدعم الظاهرة في شاشة '
                'التفعيل داخل التطبيق.',
          ),
        ],
      ),
    );
  }
}

class _PolicySection extends StatelessWidget {
  final String title;
  final String body;
  const _PolicySection({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 6),
          Text(body, style: const TextStyle(height: 1.6)),
        ],
      ),
    );
  }
}
