import { onRequest } from 'firebase-functions/v2/https';
import { setGlobalOptions } from 'firebase-functions/v2/options';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue, Timestamp } from 'firebase-admin/firestore';
import crypto from 'node:crypto';
import express, { Request, Response } from 'express';

initializeApp();
setGlobalOptions({ region: 'us-central1', maxInstances: 10 });

const db = getFirestore();
const app = express();
app.use(express.json({ limit: '16kb' }));

const PLANS = new Set(['30d', '90d', '180d', '365d', 'lifetime']);
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const HMAC_SECRET = process.env.ACTIVATION_HMAC_SECRET;
const ADMIN_API_KEY = process.env.ACTIVATION_ADMIN_KEY;

function fail(res: Response, status: number, reason: string) {
  return res.status(status).json({ valid: false, reason });
}

function normalizeCode(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const code = value.trim().toUpperCase();
  if (!/^WASLA-[A-Z0-9]{4}(?:-[A-Z0-9]{4}){2}$/.test(code)) return null;
  return code;
}

function normalizeDeviceId(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const deviceId = value.trim();
  if (deviceId.length < 4 || deviceId.length > 256) return null;
  return deviceId;
}

function codeHash(code: string): string {
  if (!HMAC_SECRET) throw new Error('ACTIVATION_HMAC_SECRET is not configured');
  return crypto.createHmac('sha256', HMAC_SECRET).update(code).digest('hex');
}

function randomCode(): string {
  const bytes = crypto.randomBytes(12);
  let raw = '';
  for (const byte of bytes) raw += CODE_ALPHABET[byte % CODE_ALPHABET.length];
  return `WASLA-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}`;
}

function expiryForPlan(plan: string): Timestamp | null {
  if (plan === 'lifetime') return null;
  const days = Number(plan.slice(0, -1));
  return Timestamp.fromMillis(Date.now() + days * 24 * 60 * 60 * 1000);
}

function publicLicense(doc: FirebaseFirestore.DocumentData, licenseId: string) {
  const expiresAt = doc.expiresAt instanceof Timestamp ? doc.expiresAt.toMillis() : null;
  return {
    licenseId,
    plan: doc.plan,
    expiresAt,
    status: doc.status,
  };
}

app.post('/v1/activation/verify', async (req: Request, res: Response) => {
  const code = normalizeCode(req.body?.code);
  const deviceId = normalizeDeviceId(req.body?.deviceId);
  if (!code || !deviceId) return fail(res, 400, 'invalid_request');
  if (!HMAC_SECRET) return fail(res, 503, 'service_not_configured');

  try {
    const id = codeHash(code);
    const ref = db.collection('licenses').doc(id);
    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists) return { kind: 'invalid' as const };
      const data = snap.data()!;
      const now = Date.now();
      const expiresAt = data.expiresAt instanceof Timestamp ? data.expiresAt.toMillis() : null;

      if (data.status === 'revoked') return { kind: 'revoked' as const };
      if (expiresAt !== null && expiresAt <= now) {
        tx.update(ref, { status: 'expired', updatedAt: FieldValue.serverTimestamp() });
        return { kind: 'expired' as const };
      }
      if (data.deviceId && data.deviceId !== deviceId) return { kind: 'wrong_device' as const };

      if (!data.deviceId) {
        tx.update(ref, {
          deviceId,
          status: 'active',
          activatedAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
        });
      }
      return { kind: 'active' as const, data, licenseId: id };
    });

    if (result.kind !== 'active') return fail(res, 200, result.kind);
    const fresh = await ref.get();
    return res.status(200).json({
      valid: true,
      deviceId,
      ...publicLicense(fresh.data()!, result.licenseId),
    });
  } catch (error) {
    console.error('activation verify failed', error);
    return fail(res, 500, 'server_error');
  }
});

app.post('/v1/activation/status', async (req: Request, res: Response) => {
  const licenseId = typeof req.body?.licenseId === 'string' ? req.body.licenseId.trim() : '';
  const deviceId = normalizeDeviceId(req.body?.deviceId);
  if (!licenseId || !deviceId || licenseId.length > 128) return fail(res, 400, 'invalid_request');

  try {
    const ref = db.collection('licenses').doc(licenseId);
    const snap = await ref.get();
    if (!snap.exists) return fail(res, 200, 'invalid');
    const data = snap.data()!;
    if (data.deviceId !== deviceId) return fail(res, 200, 'wrong_device');

    const expiresAt = data.expiresAt instanceof Timestamp ? data.expiresAt.toMillis() : null;
    let status = data.status as string;
    if (status === 'active' && expiresAt !== null && expiresAt <= Date.now()) {
      status = 'expired';
      await ref.update({ status, updatedAt: FieldValue.serverTimestamp() });
    }

    return res.status(200).json({
      valid: status === 'active',
      status,
      plan: data.plan,
      expiresAt,
    });
  } catch (error) {
    console.error('activation status failed', error);
    return fail(res, 500, 'server_error');
  }
});

function requireAdmin(req: Request, res: Response): boolean {
  if (!ADMIN_API_KEY) {
    fail(res, 503, 'admin_not_configured');
    return false;
  }
  const supplied = req.header('x-admin-key') ?? '';
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_API_KEY);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    fail(res, 401, 'unauthorized');
    return false;
  }
  return true;
}

app.post('/v1/admin/licenses', async (req: Request, res: Response) => {
  if (!requireAdmin(req, res)) return;
  const plan = typeof req.body?.plan === 'string' ? req.body.plan : '';
  if (!PLANS.has(plan)) return fail(res, 400, 'invalid_plan');

  const code = randomCode();
  const id = codeHash(code);
  const ref = db.collection('licenses').doc(id);
  const expiresAt = expiryForPlan(plan);
  await ref.set({
    plan,
    status: 'active',
    deviceId: null,
    expiresAt,
    createdAt: FieldValue.serverTimestamp(),
    activatedAt: null,
    updatedAt: FieldValue.serverTimestamp(),
  });

  return res.status(201).json({
    licenseId: id,
    code,
    plan,
    expiresAt: expiresAt?.toMillis() ?? null,
  });
});

app.post('/v1/admin/licenses/revoke', async (req: Request, res: Response) => {
  if (!requireAdmin(req, res)) return;
  const licenseId = typeof req.body?.licenseId === 'string' ? req.body.licenseId.trim() : '';
  if (!licenseId || licenseId.length > 128) return fail(res, 400, 'invalid_license');
  const ref = db.collection('licenses').doc(licenseId);
  const snap = await ref.get();
  if (!snap.exists) return fail(res, 404, 'not_found');
  await ref.update({ status: 'revoked', updatedAt: FieldValue.serverTimestamp() });
  return res.status(200).json({ ok: true, licenseId, status: 'revoked' });
});

app.get('/health', (_req, res) => res.status(200).json({ ok: true }));

export const api = onRequest({ cors: true }, app);
