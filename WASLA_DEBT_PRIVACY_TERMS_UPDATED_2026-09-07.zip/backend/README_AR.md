# Wasla Debt — Backend التفعيل المجاني

تم نقل Backend التفعيل من Firebase Cloud Functions إلى:

- Cloudflare Workers Free
- Cloudflare D1 Free

لا تحتاج إلى ترقية Firebase إلى Blaze لتشغيل التفعيل.

ابدأ من مجلد `cloudflare` واتبع `cloudflare/README_AR.md`.
