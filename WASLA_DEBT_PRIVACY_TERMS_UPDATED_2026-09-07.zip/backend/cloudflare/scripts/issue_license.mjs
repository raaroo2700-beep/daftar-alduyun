import { createInterface } from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

const [baseUrl, plan = '365d'] = process.argv.slice(2);
if (!baseUrl) {
  console.error('Usage: node issue_license.mjs <BASE_URL> [30d|90d|180d|365d|lifetime]');
  process.exit(1);
}
const rl = createInterface({ input, output });
const adminKey = await rl.question('Admin key: ');
rl.close();
const response = await fetch(`${baseUrl.replace(/\/$/, '')}/v1/admin/licenses`, {
  method: 'POST',
  headers: {'content-type': 'application/json', 'x-admin-key': adminKey},
  body: JSON.stringify({plan}),
});
console.log(await response.text());
if (!response.ok) process.exit(1);
