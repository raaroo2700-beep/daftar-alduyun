import { createInterface } from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

const [baseUrl, licenseId] = process.argv.slice(2);
if (!baseUrl || !licenseId) {
  console.error('Usage: node revoke_license.mjs <BASE_URL> <LICENSE_ID>');
  process.exit(1);
}
const rl = createInterface({ input, output });
const adminKey = await rl.question('Admin key: ');
rl.close();
const response = await fetch(`${baseUrl.replace(/\/$/, '')}/v1/admin/licenses/revoke`, {
  method: 'POST',
  headers: {'content-type': 'application/json', 'x-admin-key': adminKey},
  body: JSON.stringify({licenseId}),
});
console.log(await response.text());
if (!response.ok) process.exit(1);
