# Wasla Debt — Backend تفعيل مجاني

هذا هو Backend التفعيل البديل المجاني بدل Firebase Cloud Functions.

- Cloudflare Workers Free
- Cloudflare D1 Free
- لا يحتاج Firebase Blaze لهذا الجزء.
- كود التفعيل لا يُخزّن كنص صريح؛ يُخزّن HMAC فقط.
- أول جهاز يفعّل الرمز يصبح الجهاز المرتبط به.
- الخطط: 30d / 90d / 180d / 365d / lifetime.
- يوجد تحقق دوري وإلغاء (revoke).
- يوجد حد أساسي لمحاولات التحقق من نفس IP.

## 1) تثبيت Wrangler

```powershell
npm install
npx wrangler login
```

## 2) إنشاء D1

```powershell
npx wrangler d1 create wasla-activation
```

ضع `database_id` الذي يظهر في `wrangler.toml`.

## 3) إنشاء الأسرار

```powershell
npx wrangler secret put ACTIVATION_HMAC_SECRET
npx wrangler secret put ACTIVATION_ADMIN_KEY
```

أنشئ قيمًا عشوائية قوية محليًا، ولا ترسلها لأي شخص.

## 4) إنشاء الجداول

```powershell
npm run db:migrate
```

## 5) فحص النوع ثم النشر

```powershell
npm run typecheck
npm run deploy
```

سيظهر لك رابط الـ Worker. هذا هو `ACTIVATION_API_BASE_URL`.

## 6) إصدار رمز

```powershell
node scripts/issue_license.mjs https://YOUR-WORKER.workers.dev 365d
```

سيطلب منك Admin key داخل PowerShell ولن يطبعه في الأمر.

## 7) إلغاء رمز

```powershell
node scripts/revoke_license.mjs https://YOUR-WORKER.workers.dev LICENSE_ID
```

## 8) بناء Flutter

```powershell
flutter build apk --release --dart-define=ACTIVATION_API_BASE_URL=https://YOUR-WORKER.workers.dev
```
