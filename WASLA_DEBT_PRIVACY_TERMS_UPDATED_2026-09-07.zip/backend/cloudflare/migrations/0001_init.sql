CREATE TABLE IF NOT EXISTS licenses (
  license_id TEXT PRIMARY KEY,
  code_hash TEXT NOT NULL UNIQUE,
  plan TEXT NOT NULL CHECK (plan IN ('30d','90d','180d','365d','lifetime')),
  status TEXT NOT NULL CHECK (status IN ('active','used','expired','revoked')) DEFAULT 'active',
  device_id TEXT,
  created_at INTEGER NOT NULL,
  bound_at INTEGER,
  expires_at INTEGER,
  revoked_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_licenses_code_hash ON licenses(code_hash);
CREATE INDEX IF NOT EXISTS idx_licenses_device_id ON licenses(device_id);

CREATE TABLE IF NOT EXISTS rate_limits (
  rate_key TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  request_count INTEGER NOT NULL
);
