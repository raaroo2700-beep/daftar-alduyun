import { Hono } from 'hono';
import type { Context } from 'hono';
import type { ContentfulStatusCode } from 'hono/utils/http-status';
import { cors } from 'hono/cors';
import { createHmac, randomUUID } from 'node:crypto';

interface Env {
  DB: D1Database;
  ACTIVATION_HMAC_SECRET: string;
  ACTIVATION_ADMIN_KEY: string;
}

type LicenseRow = {
  license_id: string;
  code_hash: string;
  plan: string;
  status: string;
  device_id: string | null;
  created_at: number;
  bound_at: number | null;
  expires_at: number | null;
  revoked_at: number | null;
};

type RateLimitRow = {
  window_start: number;
  request_count: number;
};

const app = new Hono<{ Bindings: Env }>();

app.use(
  '*',
  cors({
    origin: '*',
    allowMethods: ['GET', 'POST', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'X-Admin-Key'],
  }),
);

const now = () => Date.now();

const normalizeCode = (value: string) =>
  value.trim().toUpperCase().replace(/\s+/g, '');

function codeHash(code: string, secret: string): string {
  return createHmac('sha256', secret).update(code).digest('hex');
}

function jsonError(
  c: Context<{ Bindings: Env }>,
  status: ContentfulStatusCode,
  error: string,
) {
  return c.json(
    {
      valid: false,
      error,
    },
    status,
  );
}

function isPlan(
  value: unknown,
): value is '30d' | '90d' | '180d' | '365d' | 'lifetime' {
  return (
    value === '30d' ||
    value === '90d' ||
    value === '180d' ||
    value === '365d' ||
    value === 'lifetime'
  );
}

function expiryForPlan(
  plan: string,
  createdAt: number,
): number | null {
  if (plan === 'lifetime') {
    return null;
  }

  const days = Number(plan.replace('d', ''));

  if (!Number.isFinite(days)) {
    return null;
  }

  return createdAt + days * 24 * 60 * 60 * 1000;
}

function publicLicense(row: LicenseRow) {
  return {
    valid:
      row.status === 'active' ||
      row.status === 'used',
    licenseId: row.license_id,
    deviceId: row.device_id,
    plan: row.plan,
    expiresAt: row.expires_at,
    status: row.status,
  };
}

async function rateLimit(
  c: Context<{ Bindings: Env }>,
  key: string,
): Promise<boolean> {
  const current = now();
  const windowMs = 10 * 60 * 1000;

  const row = await c.env.DB
    .prepare(
      'SELECT window_start, request_count FROM rate_limits WHERE rate_key = ?',
    )
    .bind(key)
    .first<RateLimitRow>();

  if (
    !row ||
    current - row.window_start >= windowMs
  ) {
    await c.env.DB
      .prepare(
        'INSERT OR REPLACE INTO rate_limits(rate_key, window_start, request_count) VALUES(?, ?, 1)',
      )
      .bind(key, current)
      .run();

    return true;
  }

  if (row.request_count >= 20) {
    return false;
  }

  await c.env.DB
    .prepare(
      'UPDATE rate_limits SET request_count = request_count + 1 WHERE rate_key = ?',
    )
    .bind(key)
    .run();

  return true;
}

function clientIp(c: Context<{ Bindings: Env }>): string {
  return (
    c.req.header('CF-Connecting-IP') ||
    c.req
      .header('X-Forwarded-For')
      ?.split(',')[0]
      ?.trim() ||
    'unknown'
  );
}

function requireAdmin(c: Context<{ Bindings: Env }>): boolean {
  return (
    c.req.header('X-Admin-Key') ===
    c.env.ACTIVATION_ADMIN_KEY
  );
}

/**
 * Health check
 */
app.get('/health', (c) => {
  return c.json({
    ok: true,
    service: 'wasla-activation-api',
  });
});

/**
 * Verify activation code
 */
app.post(
  '/v1/activation/verify',
  async (c) => {
    const body = (await c.req
      .json<{
        code?: string;
        deviceId?: string;
      }>()
      .catch(() => null)) as {
      code?: string;
      deviceId?: string;
    } | null;

    const code =
      typeof body?.code === 'string'
        ? normalizeCode(body.code)
        : '';

    const deviceId =
      typeof body?.deviceId === 'string'
        ? body.deviceId.trim()
        : '';

    if (!code || !deviceId) {
      return jsonError(
        c,
        400,
        'invalid_request',
      );
    }

    const allowed = await rateLimit(
      c,
      `verify:ip:${clientIp(c)}`,
    );

    if (!allowed) {
      return jsonError(
        c,
        429,
        'too_many_attempts',
      );
    }

    const hash = codeHash(
      code,
      c.env.ACTIVATION_HMAC_SECRET,
    );
    let row = await c.env.DB
      .prepare(
        'SELECT * FROM licenses WHERE code_hash = ?',
      )
      .bind(hash)
      .first<LicenseRow>();

    if (!row) {
      return jsonError(
        c,
        404,
        'invalid_code',
      );
    }

    const current = now();

    if (row.status === 'revoked') {
      return jsonError(
        c,
        403,
        'revoked',
      );
    }

    if (
      row.expires_at !== null &&
      row.expires_at <= current
    ) {
      await c.env.DB
        .prepare(
          "UPDATE licenses SET status = 'expired' WHERE license_id = ?",
        )
        .bind(row.license_id)
        .run();

      return jsonError(
        c,
        403,
        'expired',
      );
    }

    if (
      row.device_id &&
      row.device_id !== deviceId
    ) {
      return jsonError(
        c,
        409,
        'wrong_device',
      );
    }

    if (!row.device_id) {
      const result = await c.env.DB
        .prepare(
          "UPDATE licenses SET device_id = ?, bound_at = ?, status = 'used' WHERE license_id = ? AND device_id IS NULL AND status = 'active'",
        )
        .bind(
          deviceId,
          current,
          row.license_id,
        )
        .run();

      if (result.meta.changes === 0) {
        row = await c.env.DB
          .prepare(
            'SELECT * FROM licenses WHERE license_id = ?',
          )
          .bind(row.license_id)
          .first<LicenseRow>();

        if (!row) {
          return jsonError(
            c,
            404,
            'invalid_code',
          );
        }

        if (
          row.device_id !== deviceId
        ) {
          return jsonError(
            c,
            409,
            'wrong_device',
          );
        }
      } else {
        row = await c.env.DB
          .prepare(
            'SELECT * FROM licenses WHERE license_id = ?',
          )
          .bind(row.license_id)
          .first<LicenseRow>();

        if (!row) {
          return jsonError(
            c,
            404,
            'invalid_code',
          );
        }
      }
    }

    if (row.status === 'used') {
      row = {
        ...row,
        status: 'active',
      };
    }

    return c.json(
      publicLicense(row),
    );
  },
);

/**
 * Activation status
 */
app.post(
  '/v1/activation/status',
  async (c) => {
    const body = (await c.req
      .json<{
        licenseId?: string;
        deviceId?: string;
      }>()
      .catch(() => null)) as {
      licenseId?: string;
      deviceId?: string;
    } | null;

    const licenseId =
      typeof body?.licenseId === 'string'
        ? body.licenseId.trim()
        : '';

    const deviceId =
      typeof body?.deviceId === 'string'
        ? body.deviceId.trim()
        : '';

    if (!licenseId || !deviceId) {
      return jsonError(
        c,
        400,
        'invalid_request',
      );
    }

    const row = await c.env.DB
      .prepare(
        'SELECT * FROM licenses WHERE license_id = ?',
      )
      .bind(licenseId)
      .first<LicenseRow>();

    if (!row) {
      return jsonError(
        c,
        404,
        'not_found',
      );
    }

    if (row.device_id !== deviceId) {
      return jsonError(
        c,
        403,
        'wrong_device',
      );
    }

    if (row.status === 'revoked') {
      return c.json(
        {
          ...publicLicense(row),
          valid: false,
        },
        200,
      );
    }

    if (
      row.expires_at !== null &&
      row.expires_at <= now()
    ) {
      await c.env.DB
        .prepare(
          "UPDATE licenses SET status = 'expired' WHERE license_id = ?",
        )
        .bind(licenseId)
        .run();

      return c.json(
        {
          ...publicLicense({
            ...row,
            status: 'expired',
          }),
          valid: false,
        },
        200,
      );
    }

    const normalized =
      row.status === 'used'
        ? {
            ...row,
            status: 'active',
          }
        : row;
        return c.json(
      {
        ...publicLicense(normalized),
        valid: true,
      },
      200,
    );
  },
);

/**
 * Admin: create license
 */
app.post(
  '/v1/admin/licenses',
  async (c) => {
    if (!requireAdmin(c)) {
      return c.json(
        {
          error: 'unauthorized',
        },
        401,
      );
    }

    const body = (await c.req
      .json<{
        plan?: string;
      }>()
      .catch(() => null)) as {
      plan?: string;
    } | null;

    const plan =
      body?.plan ?? '365d';

    if (!isPlan(plan)) {
      return c.json(
        {
          error: 'invalid_plan',
        },
        400,
      );
    }

    const createdAt = now();
    const licenseId = randomUUID();

    const token = randomUUID()
      .replace(/-/g, '')
      .toUpperCase();

    const raw =
      `WASLA-${token.slice(0, 4)}-${token.slice(4, 8)}-${token.slice(8, 12)}`;
    const hash = codeHash(
      raw,
      c.env.ACTIVATION_HMAC_SECRET,
    );

    const expiresAt =
      expiryForPlan(
        plan,
        createdAt,
      );

    await c.env.DB
      .prepare(
        "INSERT INTO licenses(license_id, code_hash, plan, status, created_at, expires_at) VALUES(?, ?, ?, 'active', ?, ?)",
      )
      .bind(
        licenseId,
        hash,
        plan,
        createdAt,
        expiresAt,
      )
      .run();

    return c.json(
      {
        licenseId,
        code: raw,
        plan,
        expiresAt,
      },
      201,
    );
  },
);

/**
 * Admin: revoke license
 */
app.post(
  '/v1/admin/licenses/revoke',
  async (c) => {
    if (!requireAdmin(c)) {
      return c.json(
        {
          error: 'unauthorized',
        },
        401,
      );
    }

    const body = (await c.req
      .json<{
        licenseId?: string;
      }>()
      .catch(() => null)) as {
      licenseId?: string;
    } | null;

    const licenseId =
      typeof body?.licenseId === 'string'
        ? body.licenseId.trim()
        : '';

    if (!licenseId) {
      return c.json(
        {
          error: 'licenseId_required',
        },
        400,
      );
    }

    const result = await c.env.DB
      .prepare(
        "UPDATE licenses SET status = 'revoked', revoked_at = ? WHERE license_id = ?",
      )
      .bind(
        now(),
        licenseId,
      )
      .run();

    if (result.meta.changes === 0) {
      return c.json(
        {
          error: 'not_found',
        },
        404,
      );
    }

    return c.json({
      ok: true,
      licenseId,
      status: 'revoked',
    });
  },
);

export default app;
