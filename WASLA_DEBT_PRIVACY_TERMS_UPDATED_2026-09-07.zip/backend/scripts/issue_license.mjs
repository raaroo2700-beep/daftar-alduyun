const [baseUrl, adminKey, plan = '365d'] = process.argv.slice(2);
if (!baseUrl || !adminKey) {
  console.error('Usage: node issue_license.mjs <BASE_URL> <ADMIN_KEY> [30d|90d|180d|365d|lifetime]');
  process.exit(1);
}
const response = await fetch(`${baseUrl.replace(/\/$/, '')}/v1/admin/licenses`, {
  method: 'POST',
  headers: {'content-type': 'application/json', 'x-admin-key': adminKey},
  body: JSON.stringify({plan}),
});
console.log(await response.text());
if (!response.ok) process.exit(1);
