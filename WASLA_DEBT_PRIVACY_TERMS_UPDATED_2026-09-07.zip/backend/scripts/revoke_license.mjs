const [baseUrl, adminKey, licenseId] = process.argv.slice(2);
if (!baseUrl || !adminKey || !licenseId) {
  console.error('Usage: node revoke_license.mjs <BASE_URL> <ADMIN_KEY> <LICENSE_ID>');
  process.exit(1);
}
const response = await fetch(`${baseUrl.replace(/\/$/, '')}/v1/admin/licenses/revoke`, {
  method: 'POST',
  headers: {'content-type': 'application/json', 'x-admin-key': adminKey},
  body: JSON.stringify({licenseId}),
});
console.log(await response.text());
if (!response.ok) process.exit(1);
