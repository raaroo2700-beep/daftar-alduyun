import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/core/services/attachment_service.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';

class CustomerService {
  static final CustomerRepository _repository = CustomerRepository();
  static final TransactionRepository _transactionRepository = TransactionRepository();
  static final AttachmentService _attachmentService = AttachmentService();

  static Future<void> updateCustomer(Customer customer) async {
    final id = customer.id;
    if (id == null) throw Exception('العميل غير موجود');
    if (customer.name.trim().isEmpty) throw Exception('اسم العميل مطلوب');
    if ([customer.debtLimitYer, customer.debtLimitSar, customer.debtLimitUsd, customer.creditLimitYer, customer.creditLimitSar, customer.creditLimitUsd].any((v) => v != null && v < 0)) {
      throw Exception('سقف الحساب لا يمكن أن يكون سالبًا');
    }
    final db = await _repository.appDatabase.database;
    await db.transaction((txn) async {
      final oldCustomer = await _repository.getCustomerByIdWithTxn(id, txn);
      if (oldCustomer == null) throw Exception('العميل غير موجود');
      final updatedCustomer = Customer(
        id: id,
        name: customer.name.trim(),
        phone: customer.phone,
        note: customer.note,
        debtLimit: customer.debtLimit,
        creditLimit: customer.creditLimit,
        debtLimitYer: customer.debtLimitYer,
        debtLimitSar: customer.debtLimitSar,
        debtLimitUsd: customer.debtLimitUsd,
        creditLimitYer: customer.creditLimitYer,
        creditLimitSar: customer.creditLimitSar,
        creditLimitUsd: customer.creditLimitUsd,
        createdAt: oldCustomer.createdAt,
        updatedAt: DateTime.now().millisecondsSinceEpoch,
        isArchived: oldCustomer.isArchived,
      );
      if (await _repository.updateCustomerWithTxn(updatedCustomer, txn) != 1) {
        throw Exception('تعذر تعديل بيانات العميل');
      }
      await AuditService.logCustomerUpdate(oldCustomer: oldCustomer, newCustomer: updatedCustomer, txn: txn);
    });
  }

  static Future<void> archiveCustomer(int customerId) async {
    final db = await _repository.appDatabase.database;
    await db.transaction((txn) async {
      final oldCustomer = await _repository.getCustomerByIdWithTxn(customerId, txn);
      if (oldCustomer == null) throw Exception('العميل غير موجود');
      if (oldCustomer.isArchived) return;
      final newCustomer = oldCustomer.copyWith(isArchived: true, updatedAt: DateTime.now().millisecondsSinceEpoch);
      if (await _repository.archiveCustomerWithTxn(customerId, txn) != 1) throw Exception('تعذر أرشفة العميل');
      await AuditService.logCustomerArchive(oldCustomer: oldCustomer, newCustomer: newCustomer, txn: txn);
    });
  }

  static Future<void> restoreCustomer(int customerId) async {
    final db = await _repository.appDatabase.database;
    await db.transaction((txn) async {
      final oldCustomer = await _repository.getCustomerByIdWithTxn(customerId, txn);
      if (oldCustomer == null) throw Exception('العميل غير موجود');
      if (!oldCustomer.isArchived) return;
      final newCustomer = oldCustomer.copyWith(isArchived: false, updatedAt: DateTime.now().millisecondsSinceEpoch);
      if (await _repository.restoreCustomerWithTxn(customerId, txn) != 1) throw Exception('تعذر استعادة العميل');
      await AuditService.logCustomerRestore(oldCustomer: oldCustomer, newCustomer: newCustomer, txn: txn);
    });
  }

  static Future<void> deleteCustomer(int customerId) async {
    final transactionIds = await _transactionRepository.getTransactionIdsByCustomer(customerId);
    final db = await _repository.appDatabase.database;
    await db.transaction((txn) async {
      final customer = await _repository.getCustomerByIdWithTxn(customerId, txn);
      if (customer == null) throw Exception('العميل غير موجود');
      if (!customer.isArchived) throw Exception('يجب أرشفة العميل أولًا قبل الحذف النهائي');
      await AuditService.logCustomerDelete(customer: customer, txn: txn);
      if (await _repository.deleteCustomerWithTxn(customerId, txn) != 1) throw Exception('تعذر حذف العميل');
    });
    for (final transactionId in transactionIds) {
      try { await _attachmentService.deleteAttachment(transactionId); } catch (_) {}
    }
  }
}
