import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sqflite/sqflite.dart';
import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/core/services/attachment_service.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

class TransactionService {
  static final TransactionRepository _transactions = TransactionRepository();
  static final CustomerRepository _customers = CustomerRepository();
  static final AttachmentService _attachments = AttachmentService();

  static Future<void> updateTransaction({
    required DebtTransaction transaction,
    String? replacementImagePath,
  }) async {
    final id = transaction.id;
    if (id == null) throw Exception('المعاملة غير موجودة');
    if (transaction.amount <= 0) throw Exception('المبلغ يجب أن يكون أكبر من صفر');
    final db = await AppDatabase().database;
    String? newAttachment;
    try {
      await db.transaction((txn) async {
        final old = await _transactions.getTransactionByIdWithTxn(id, txn);
        if (old == null) throw Exception('المعاملة غير موجودة');
        final customer = await _customers.getCustomerByIdWithTxn(transaction.customerId, txn);
        if (customer == null || customer.isArchived) throw Exception('العميل غير موجود أو مؤرشف');
        final updated = transaction.copyWith(updatedAt: DateTime.now().millisecondsSinceEpoch);
        await _validateLimit(updated, customer, txn);
        if (replacementImagePath != null && replacementImagePath.isNotEmpty) {
          newAttachment = await _attachments.saveAttachment(id, XFile(replacementImagePath));
        }
        final finalTx = newAttachment == null ? updated : updated.copyWith(imagePath: newAttachment);
        if (await _transactions.updateTransactionWithTxn(finalTx, txn) != 1) throw Exception('تعذر تعديل المعاملة');
        await AuditService.logTransactionUpdate(oldTransaction: old, newTransaction: finalTx, note: 'تم تعديل المعاملة', txn: txn);
      });
    } catch (e) {
      if (newAttachment != null) {
        try { await _attachments.deleteAttachmentPath(newAttachment!); } catch (_) {}
      }
      rethrow;
    }
    if (newAttachment != null && transaction.imagePath != null && transaction.imagePath != newAttachment) {
      try { await _attachments.deleteAttachmentPath(transaction.imagePath!); } catch (_) {}
    }
  }

  static Future<void> _validateLimit(DebtTransaction candidate, Customer customer, Transaction txn) async {
    final txMaps = await txn.query('transactions', where: 'customerId = ? AND isArchived = 0 AND id != ?', whereArgs: [candidate.customerId, candidate.id]);
    final txs = txMaps.map(DebtTransaction.fromMap).toList()..add(candidate);
    final payMaps = await txn.query('payments', where: 'customerId = ?', whereArgs: [candidate.customerId]);
    final pays = payMaps.map(Payment.fromMap).toList();
    final balance = BalanceCalculator.calculateClientBalance(transactions: txs, payments: pays)[candidate.currency]?.balance ?? 0;
    if (balance > 0 && customer.debtLimitFor(candidate.currency) != null && balance > customer.debtLimitFor(candidate.currency)!) {
      throw Exception('تم تجاوز سقف الدين المحدد (${MoneyFormat.amount(customer.debtLimitFor(candidate.currency)!)})');
    }
    if (balance < 0 && customer.creditLimitFor(candidate.currency) != null && balance.abs() > customer.creditLimitFor(candidate.currency)!) {
      throw Exception('تم تجاوز سقف الرصيد للعميل (${MoneyFormat.amount(customer.creditLimitFor(candidate.currency)!)})');
    }
  }

  static Future<String?> transferWarning({
    required int fromCustomerId,
    required double amount,
    required Currency currency,
  }) async {
    final db = await AppDatabase().database;
    final txs = (await db.query('transactions',
      where: 'customerId = ? AND isArchived = 0', whereArgs: [fromCustomerId],
    )).map(DebtTransaction.fromMap).toList();
    final pays = (await db.query('payments',
      where: 'customerId = ?', whereArgs: [fromCustomerId],
    )).map(Payment.fromMap).toList();
    final current = BalanceCalculator.calculateClientBalance(
      transactions: txs, payments: pays,
    )[currency]?.balance ?? 0;
    if (current < amount) {
      return 'رصيد العميل المصدر هو ${MoneyFormat.amount(current)} ${currency.name.toUpperCase()}، بينما مبلغ التحويل ${MoneyFormat.amount(amount)}. سيؤدي التحويل إلى تجاوز الرصيد المتاح. هل تريد المتابعة؟';
    }
    return null;
  }

  static Future<void> transfer({
    required int fromCustomerId,
    required int toCustomerId,
    required double amount,
    required Currency currency,
    String? note,
    bool allowOverdraft = false,
  }) async {
    if (fromCustomerId == toCustomerId) throw Exception('اختر عميلين مختلفين');
    if (amount <= 0) throw Exception('المبلغ يجب أن يكون أكبر من صفر');
    final db = await AppDatabase().database;
    await db.transaction((txn) async {
      final from = await _customers.getCustomerByIdWithTxn(fromCustomerId, txn);
      final to = await _customers.getCustomerByIdWithTxn(toCustomerId, txn);
      if (from == null || to == null || from.isArchived || to.isArchived) throw Exception('يجب أن يكون العميلان نشطين');
      final txs = (await txn.query('transactions', where: 'customerId = ? AND isArchived = 0', whereArgs: [fromCustomerId])).map(DebtTransaction.fromMap).toList();
      final pays = (await txn.query('payments', where: 'customerId = ?', whereArgs: [fromCustomerId])).map(Payment.fromMap).toList();
      final current = BalanceCalculator.calculateClientBalance(transactions: txs, payments: pays)[currency]?.balance ?? 0;
      if (current < amount && !allowOverdraft) throw Exception('الرصيد المدين للعميل المصدر غير كافٍ للتحويل');

      final now = DateTime.now().millisecondsSinceEpoch;
      // A transfer creates a debit on the destination, so enforce the same
      // destination debt/credit limits used by normal transactions.
      final destinationTxs = (await txn.query('transactions', where: 'customerId = ? AND isArchived = 0', whereArgs: [toCustomerId])).map(DebtTransaction.fromMap).toList();
      final destinationPays = (await txn.query('payments', where: 'customerId = ?', whereArgs: [toCustomerId])).map(Payment.fromMap).toList();
      final projectedDestination = BalanceCalculator.calculateClientBalance(
        transactions: [...destinationTxs, DebtTransaction(customerId: toCustomerId, type: DebtType.debit, amount: amount, currency: currency, date: now, createdAt: now, updatedAt: now)],
        payments: destinationPays,
      )[currency]?.balance ?? 0;
      if (projectedDestination > 0 && to.debtLimitFor(currency) != null && projectedDestination > to.debtLimitFor(currency)!) {
        throw Exception('سيؤدي التحويل إلى تجاوز سقف الدين للعميل المستلم');
      }
      if (projectedDestination < 0 && to.creditLimitFor(currency) != null && projectedDestination.abs() > to.creditLimitFor(currency)!) {
        throw Exception('سيؤدي التحويل إلى تجاوز سقف الرصيد للعميل المستلم');
      }
      final credit = DebtTransaction(customerId: fromCustomerId, type: DebtType.credit, amount: amount, currency: currency, details: 'تحويل إلى ${to.name}${note == null || note.trim().isEmpty ? '' : ' - ${note.trim()}'}', date: now, createdAt: now, updatedAt: now);
      final debit = DebtTransaction(customerId: toCustomerId, type: DebtType.debit, amount: amount, currency: currency, details: 'تحويل من ${from.name}${note == null || note.trim().isEmpty ? '' : ' - ${note.trim()}'}', date: now, createdAt: now, updatedAt: now);
      final fromId = await _transactions.insertTransactionWithTxn(credit, txn);
      final toId = await _transactions.insertTransactionWithTxn(debit, txn);
      await AuditService.logTransactionCreate(transaction: credit.copyWith(id: fromId), note: 'تحويل: خصم من حساب ${from.name} إلى ${to.name}', txn: txn);
      await AuditService.logTransactionCreate(transaction: debit.copyWith(id: toId), note: 'تحويل: إضافة إلى حساب ${to.name} من ${from.name}', txn: txn);
      await AuditService.logTransfer(sourceTransactionId: fromId, destinationTransactionId: toId, fromCustomerId: fromCustomerId, toCustomerId: toCustomerId, amount: amount, currency: currency.name.toUpperCase(), txn: txn);
    });
  }
}
