import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:google_sign_in/google_sign_in.dart';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class GoogleDriveService {
  static final GoogleSignIn _googleSignIn = GoogleSignIn(
    serverClientId:
    '927535919481-pp9d0jtnt2n542c8gubhmrgv50q39q9v.apps.googleusercontent.com',
    scopes: ['https://www.googleapis.com/auth/drive.file'],
  );

// تسجيل الدخول
static Future<GoogleSignInAccount?> signIn() async {
try {
return await _googleSignIn.signIn();
} catch (e) {
throw Exception('فشل تسجيل الدخول: $e');
}
}

// تسجيل الخروج
static Future<void> signOut() async {
await _googleSignIn.signOut();
}

static bool get isSignedIn => _googleSignIn.currentUser != null;
static GoogleSignInAccount? get currentUser => _googleSignIn.currentUser;

// الحصول على Access Token
static Future<String> _getAccessToken() async {
final account = _googleSignIn.currentUser;
if (account == null) throw Exception('الرجاء تسجيل الدخول أولاً');

final authHeaders = await account.authHeaders;
final accessToken = authHeaders['Authorization']?.replaceFirst('Bearer ', '');
if (accessToken == null) throw Exception('فشل الحصول على رمز الوصول');
return accessToken;
}

// رفع ملف
// إصلاح 7.3: كانت تُستخدم http.MultipartRequest التي تبني دائمًا طلب
// multipart/form-data (نماذج الويب العادية)، بينما Google Drive API لرفع
// الملفات بطريقة multipart يتطلب صراحة multipart/related بجزأين: JSON
// للـ metadata ثم محتوى الملف، بحد (boundary) خاص بهذا التنسيق. الطلب
// القديم كان يرسل الـ metadata كحقل نموذج عادي، ما يتسبب غالبًا في فشل
// الطلب أو تجاهل الاسم/المجلد الهدف.
static Future<String> uploadFile({
required String localFilePath,
required String fileName,
}) async {
try {
final token = await _getAccessToken();
final file = File(localFilePath);
final fileBytes = await file.readAsBytes();

final uri = Uri.parse('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart');

const boundary = 'wasla_debt_backup_boundary';
final metadataJson = jsonEncode({
  'name': fileName,
  'mimeType': 'application/zip',
  'appProperties': {'waslaApp': 'wasla_debt', 'backupType': 'zip'},
});

final bodyBuilder = BytesBuilder();
bodyBuilder.add(utf8.encode(
  '--$boundary\r\n'
  'Content-Type: application/json; charset=UTF-8\r\n\r\n'
  '$metadataJson\r\n',
));
bodyBuilder.add(utf8.encode(
  '--$boundary\r\n'
  'Content-Type: application/zip\r\n\r\n',
));
bodyBuilder.add(fileBytes);
bodyBuilder.add(utf8.encode('\r\n--$boundary--'));

final response = await http.post(
  uri,
  headers: {
    'Authorization': 'Bearer $token',
    'Content-Type': 'multipart/related; boundary=$boundary',
  },
  body: bodyBuilder.toBytes(),
).timeout(const Duration(seconds: 60));

if (response.statusCode != 200) {
throw Exception('فشل الرفع: ${response.body}');
}

final jsonResponse = jsonDecode(response.body) as Map<String, dynamic>;
return jsonResponse['id'] as String;
} catch (e) {
throw Exception('فشل الرفع: $e');
}
}

// جلب قائمة النسخ الاحتياطية
static Future<List<Map<String, dynamic>>> listBackups() async {
try {
final token = await _getAccessToken();
final uri = Uri.parse(
'https://www.googleapis.com/drive/v3/files?q=appProperties has { key=\'waslaApp\' and value=\'wasla_debt\' } and trashed = false&orderBy=createdTime desc&pageSize=50&fields=files(id,name,size,createdTime,modifiedTime,appProperties)',
);

final response = await http.get(
uri,
headers: {'Authorization': 'Bearer $token'},
).timeout(const Duration(seconds: 30));

if (response.statusCode != 200) {
throw Exception('فشل جلب القائمة: ${response.body}');
}

final jsonResponse = jsonDecode(response.body) as Map<String, dynamic>;
return List<Map<String, dynamic>>.from(jsonResponse['files'] ?? []);
} catch (e) {
throw Exception('فشل جلب القائمة: $e');
}
}

// تحميل ملف
static Future<String> downloadFile(String fileId) async {
try {
final token = await _getAccessToken();
final uri = Uri.parse('https://www.googleapis.com/drive/v3/files/$fileId?alt=media');

final response = await http.get(
uri,
headers: {'Authorization': 'Bearer $token'},
).timeout(const Duration(seconds: 30));

if (response.statusCode != 200) {
throw Exception('فشل التحميل: ${response.body}');
}

final tempDir = await getTemporaryDirectory();
final fileName = 'wasla_backup_${DateTime.now().millisecondsSinceEpoch}.zip';
final localPath = '${tempDir.path}/$fileName';
final localFile = File(localPath);
await localFile.writeAsBytes(response.bodyBytes);
return localPath;
} catch (e) {
throw Exception('فشل التحميل: $e');
}
}
// حذف ملف
  static Future<void> deleteFile(String fileId) async {
    try {
      final token = await _getAccessToken();
      final uri = Uri.parse('https://www.googleapis.com/drive/v3/files/$fileId');

      final response = await http.delete(
        uri,
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode != 204) {
        throw Exception('فشل الحذف: ${response.body}');
      }
    } catch (e) {
      throw Exception('فشل الحذف: $e');
    }
  }
}