import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DeviceIdService {
  static const _channel = MethodChannel('wasla_debt/device_id');
  static const _fallbackKey = 'wasla_device_id';

  static Future<String> getDeviceId() async {
    try {
      final id = await _channel.invokeMethod<String>('getDeviceId');
      if (id != null && id.trim().isNotEmpty) return id.trim();
    } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_fallbackKey);
    if (existing != null && existing.isNotEmpty) return existing;
    final generated = 'WD-${DateTime.now().microsecondsSinceEpoch}';
    await prefs.setString(_fallbackKey, generated);
    return generated;
  }
}
