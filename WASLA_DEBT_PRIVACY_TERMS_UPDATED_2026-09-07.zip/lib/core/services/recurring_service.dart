import 'dart:developer' as developer;
import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/models/recurring_schedule.dart';
import 'package:wasla_debt/data/repositories/recurring_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';

class RecurringService {
  final RecurringRepository _repo = RecurringRepository();
  final TransactionRepository _transactionRepo = TransactionRepository();
  final CustomerRepository _customerRepo = CustomerRepository();

  Future<void> processDueSchedules() async {
    final schedules = await _repo.getEnabledSchedules();
    final now = DateTime.now();
    final nowMs = now.millisecondsSinceEpoch;
    final db = await AppDatabase().database;

    for (final schedule in schedules) {
      if (schedule.nextRun > nowMs) continue;
      try {
        await db.transaction((txn) async {
        var due = DateTime.fromMillisecondsSinceEpoch(schedule.nextRun);
        var nextRun = due;
        final customer = await _customerRepo.getCustomerByIdWithTxn(schedule.customerId, txn);
        if (customer == null || customer.isArchived) return;

        final txMaps = await txn.query('transactions', where: 'customerId = ? AND isArchived = 0', whereArgs: [schedule.customerId]);
        final payMaps = await txn.query('payments', where: 'customerId = ?', whereArgs: [schedule.customerId]);
        final txs = txMaps.map(DebtTransaction.fromMap).toList();
        final pays = payMaps.map(Payment.fromMap).toList();
        final created = <DebtTransaction>[];

        while (!nextRun.isAfter(now)) {
          final candidate = DebtTransaction(
            customerId: schedule.customerId,
            type: schedule.type,
            amount: schedule.amount,
            currency: schedule.currency,
            details: '${schedule.details ?? 'عملية متكررة'} (تلقائي)',
            date: nextRun.millisecondsSinceEpoch,
            createdAt: nowMs,
            updatedAt: nowMs,
          );
          final projected = [...txs, ...created, candidate];
          final balance = BalanceCalculator.calculateClientBalance(transactions: projected, payments: pays)[schedule.currency]?.balance ?? 0;
          if (balance > 0 && customer.debtLimitFor(schedule.currency) != null && balance > customer.debtLimitFor(schedule.currency)!) {
            throw Exception('تم إيقاف الجدولة لتجاوز سقف الدين للعميل');
          }
          if (balance < 0 && customer.creditLimitFor(schedule.currency) != null && balance.abs() > customer.creditLimitFor(schedule.currency)!) {
            throw Exception('تم إيقاف الجدولة لتجاوز سقف الرصيد للعميل');
          }
          final id = await _transactionRepo.insertTransactionWithTxn(candidate, txn);
          final stored = candidate.copyWith(id: id);
          created.add(stored);
          await AuditService.logTransactionCreate(transaction: stored, note: 'إنشاء تلقائي من جدولة متكررة', txn: txn);
          nextRun = _nextRunFrom(nextRun, schedule.interval);
        }

        final updated = schedule.copyWith(nextRun: nextRun.millisecondsSinceEpoch, updatedAt: nowMs);
        if (await _repo.updateScheduleWithTxn(updated, txn) != 1) throw Exception('تعذر تحديث الجدولة');
        });
      } catch (e) {
        // A broken schedule must not prevent other due schedules from running.
        // Limit violations disable this schedule until the user adjusts its
        // limit; other database errors are isolated to this schedule.
        developer.log('Recurring schedule ${schedule.id} failed', name: 'wasla.recurring', error: e);
        if (e.toString().contains('تم إيقاف الجدولة لتجاوز سقف')) {
          try {
            await _repo.toggleSchedule(schedule.id!, false);
          } catch (_) {}
        }
      }
    }
  }

  static DateTime _nextRunFrom(DateTime base, RecurringInterval interval) {
    switch (interval) {
      case RecurringInterval.daily:
        return base.add(const Duration(days: 1));
      case RecurringInterval.weekly:
        return base.add(const Duration(days: 7));
      case RecurringInterval.monthly:
        final nextMonth = base.month == 12 ? DateTime(base.year + 1, 1, 1) : DateTime(base.year, base.month + 1, 1);
        final lastDay = DateTime(nextMonth.year, nextMonth.month + 1, 0).day;
        final baseLastDay = DateTime(base.year, base.month + 1, 0).day;
        final day = base.day == baseLastDay ? lastDay : (base.day > lastDay ? lastDay : base.day);
        return DateTime(nextMonth.year, nextMonth.month, day, base.hour, base.minute, base.second, base.millisecond, base.microsecond);
    }
  }
}
