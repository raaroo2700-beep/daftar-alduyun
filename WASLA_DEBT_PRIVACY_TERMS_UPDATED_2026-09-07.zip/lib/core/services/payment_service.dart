import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/payment_repository.dart';

class PaymentService {
  static final PaymentRepository _repo = PaymentRepository();

  static Future<void> updatePayment(Payment payment) async {
    if (payment.id == null || payment.amount <= 0) throw Exception('بيانات السداد غير صحيحة');
    final db = await AppDatabase().database;
    await db.transaction((txn) async {
      final old = await _repo.getPaymentByIdWithTxn(payment.id!, txn);
      if (old == null) throw Exception('السداد غير موجود');
      final updated = payment.copyWith(updatedAt: DateTime.now().millisecondsSinceEpoch);
      if (await _repo.updatePaymentWithTxn(updated, txn) != 1) throw Exception('تعذر تعديل السداد');
      await AuditService.logPaymentUpdate(oldPayment: old, newPayment: updated, txn: txn);
    });
  }

  static Future<void> deletePayment(int id) async {
    final db = await AppDatabase().database;
    await db.transaction((txn) async {
      final payment = await _repo.getPaymentByIdWithTxn(id, txn);
      if (payment == null) throw Exception('السداد غير موجود');
      await AuditService.logPaymentDelete(payment: payment, txn: txn);
      if (await _repo.deletePaymentWithTxn(id, txn) != 1) throw Exception('تعذر حذف السداد');
    });
  }
}
