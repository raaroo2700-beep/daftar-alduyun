import 'package:wasla_debt/core/utils/money_format.dart';
import 'dart:io';

import 'package:excel/excel.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';

class ExportService {
  static Future<pw.Font> _loadArabicFont() async {
    try {
      final fontData = await rootBundle.load('assets/fonts/Cairo-Regular.ttf');
      return pw.Font.ttf(fontData);
    } catch (_) {
      return pw.Font.helvetica();
    }
  }

  static Future<pw.Font> _loadArabicBoldFont() async {
    try {
      final fontData = await rootBundle.load('assets/fonts/Cairo-Bold.ttf');
      return pw.Font.ttf(fontData);
    } catch (_) {
      return _loadArabicFont();
    }
  }

  static String _currency(Currency c) => c.name.toUpperCase();

  static String _paymentDirection(PaymentDirection direction) {
    return direction == PaymentDirection.customerToBusiness
        ? 'دفع لي'
        : 'دفعت له';
  }

  static String _balanceLabel(double balance) {
    if (balance > 0) return 'عليه';
    if (balance < 0) return 'له';
    return 'مسدد';
  }

  static String _money(double value) => MoneyFormat.amount(value);

  /// كشف حساب عميل كامل، مع اتجاه RTL واضح، وملخص مستقل لكل عملة.
  static Future<String> generatePDF({
    required Customer customer,
    required List<DebtTransaction> transactions,
    required Map<Currency, BalanceResult> balances,
    List<Payment> payments = const [],
  }) async {
    final pdf = pw.Document();
    final font = await _loadArabicFont();
    final boldFont = await _loadArabicBoldFont();

    final currencies = <Currency>{
      ...balances.keys,
      ...transactions.map((t) => t.currency),
      ...payments.map((p) => p.currency),
    }.toList();
    currencies.sort((a, b) => a.index.compareTo(b.index));

    final summaryRows = <pw.TableRow>[
      pw.TableRow(children: [
        _buildHeaderCell('العملة', boldFont),
        _buildHeaderCell('إجمالي عليه', boldFont),
        _buildHeaderCell('إجمالي له', boldFont),
        _buildHeaderCell('دفع لي', boldFont),
        _buildHeaderCell('دفعت له', boldFont),
        _buildHeaderCell('الرصيد', boldFont),
        _buildHeaderCell('الحالة', boldFont),
      ]),
    ];
    for (final c in currencies) {
      final b = balances[c] ?? BalanceResult(currency: c, totalDebit: 0, totalCredit: 0);
      summaryRows.add(pw.TableRow(children: [
        _buildDataCell(_currency(c), font),
        _buildDataCell(_money(b.totalDebit), font),
        _buildDataCell(_money(b.totalCredit), font),
        _buildDataCell(_money(b.totalPaymentsReceived), font),
        _buildDataCell(_money(b.totalPaymentsPaid), font),
        _buildDataCell(_money(b.balance), font),
        _buildDataCell(_balanceLabel(b.balance), font),
      ]));
    }

    final transactionRows = <pw.TableRow>[
      pw.TableRow(children: [
        _buildHeaderCell('التاريخ', boldFont),
        _buildHeaderCell('المبلغ', boldFont),
        _buildHeaderCell('العملة', boldFont),
        _buildHeaderCell('النوع', boldFont),
        _buildHeaderCell('التفاصيل', boldFont),
      ]),
      ...transactions.map((t) => pw.TableRow(children: [
        _buildDataCell(_date(t.date), font),
        _buildDataCell(_money(t.amount), font),
        _buildDataCell(_currency(t.currency), font),
        _buildDataCell(t.type == DebtType.credit ? 'له' : 'عليه', font),
        _buildDataCell(t.details ?? '', font),
      ])),
    ];

    final paymentRows = <pw.TableRow>[
      pw.TableRow(children: [
        _buildHeaderCell('التاريخ', boldFont),
        _buildHeaderCell('المبلغ', boldFont),
        _buildHeaderCell('العملة', boldFont),
        _buildHeaderCell('الاتجاه', boldFont),
        _buildHeaderCell('الملاحظات', boldFont),
      ]),
      ...payments.map((p) => pw.TableRow(children: [
        _buildDataCell(_date(p.paymentDate), font),
        _buildDataCell(_money(p.amount), font),
        _buildDataCell(_currency(p.currency), font),
        _buildDataCell(_paymentDirection(p.direction), font),
        _buildDataCell(p.note ?? '', font),
      ])),
    ];

    pdf.addPage(
      pw.MultiPage(
        pageTheme: const pw.PageTheme(
          margin: pw.EdgeInsets.fromLTRB(24, 28, 24, 28),
        ),
        build: (_) => [
          pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                pw.Text(
                  'كشف حساب العميل: ${customer.name}',
                  textAlign: pw.TextAlign.right,
                  style: pw.TextStyle(font: boldFont, fontSize: 21),
                ),
                pw.SizedBox(height: 6),
                pw.Text(
                  'رقم الهاتف: ${customer.phone ?? 'لا يوجد'}',
                  textAlign: pw.TextAlign.right,
                  style: pw.TextStyle(font: font, fontSize: 12),
                ),
                pw.SizedBox(height: 18),
                pw.Text(
                  'ملخص الحساب',
                  textAlign: pw.TextAlign.right,
                  style: pw.TextStyle(font: boldFont, fontSize: 16),
                ),
                pw.SizedBox(height: 8),
                pw.Table(
                  border: pw.TableBorder.all(color: PdfColors.grey400),
                  defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: summaryRows,
                ),
                pw.SizedBox(height: 20),
                pw.Text(
                  'المعاملات',
                  textAlign: pw.TextAlign.right,
                  style: pw.TextStyle(font: boldFont, fontSize: 16),
                ),
                pw.SizedBox(height: 8),
                if (transactions.isEmpty)
                  pw.Text('لا توجد معاملات', textAlign: pw.TextAlign.right, style: pw.TextStyle(font: font))
                else
                  pw.Table(
                    border: pw.TableBorder.all(color: PdfColors.grey400),
                    defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                    children: transactionRows,
                  ),
                if (payments.isNotEmpty) ...[
                  pw.SizedBox(height: 20),
                  pw.Text(
                    'السدادات',
                    textAlign: pw.TextAlign.right,
                    style: pw.TextStyle(font: boldFont, fontSize: 16),
                  ),
                  pw.SizedBox(height: 8),
                  pw.Table(
                    border: pw.TableBorder.all(color: PdfColors.grey400),
                    defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                    children: paymentRows,
                  ),
                ],
                pw.SizedBox(height: 18),
                pw.Text(
                  'تم الإنشاء: ${DateFormat('yyyy-MM-dd HH:mm', 'ar').format(DateTime.now())}',
                  textAlign: pw.TextAlign.right,
                  style: pw.TextStyle(font: font, fontSize: 9, color: PdfColors.grey700),
                ),
              ],
            ),
          ),
        ],
      ),
    );

    final output = await getTemporaryDirectory();
    final safeName = customer.name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final file = File('${output.path}/كشف_حساب_${safeName}_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file.path;
  }

  static String _date(int milliseconds) =>
      DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(milliseconds));

  static pw.Widget _buildHeaderCell(String text, pw.Font font) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(6),
      alignment: pw.Alignment.center,
      child: pw.Text(
        text,
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(fontWeight: pw.FontWeight.bold, font: font, fontSize: 9),
      ),
    );
  }

  static pw.Widget _buildDataCell(String text, pw.Font font) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(6),
      alignment: pw.Alignment.center,
      child: pw.Text(
        text,
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(font: font, fontSize: 8.5),
      ),
    );
  }

  /// كشف Excel مرتب: ملخص كامل لكل عملة + تفاصيل العمليات + تفاصيل السدادات.
  static Future<String> generateExcel({
    required Customer customer,
    required List<DebtTransaction> transactions,
    required Map<Currency, BalanceResult> balances,
    List<Payment> payments = const [],
  }) async {
    final excel = Excel.createExcel();
    final sheet = excel['كشف الحساب'];

    final currencies = <Currency>{
      ...balances.keys,
      ...transactions.map((t) => t.currency),
      ...payments.map((p) => p.currency),
    }.toList()..sort((a, b) => a.index.compareTo(b.index));

    sheet.appendRow([TextCellValue('كشف حساب العميل')]);
    sheet.appendRow([TextCellValue(customer.name)]);
    sheet.appendRow([TextCellValue('رقم الهاتف'), TextCellValue(customer.phone ?? 'لا يوجد')]);
    sheet.appendRow([]);

    sheet.appendRow([
      TextCellValue('ملخص الحساب'),
    ]);
    sheet.appendRow([
      TextCellValue('العملة'),
      TextCellValue('إجمالي عليه'),
      TextCellValue('إجمالي له'),
      TextCellValue('دفع لي'),
      TextCellValue('دفعت له'),
      TextCellValue('الرصيد'),
      TextCellValue('الحالة'),
    ]);
    for (final c in currencies) {
      final b = balances[c] ?? BalanceResult(currency: c, totalDebit: 0, totalCredit: 0);
      sheet.appendRow([
        TextCellValue(_currency(c)),
        TextCellValue(_money(b.totalDebit)),
        TextCellValue(_money(b.totalCredit)),
        TextCellValue(_money(b.totalPaymentsReceived)),
        TextCellValue(_money(b.totalPaymentsPaid)),
        TextCellValue(_money(b.balance)),
        TextCellValue(_balanceLabel(b.balance)),
      ]);
    }

    sheet.appendRow([]);
    sheet.appendRow([TextCellValue('المعاملات')]);
    sheet.appendRow([
      TextCellValue('التاريخ'),
      TextCellValue('المبلغ'),
      TextCellValue('العملة'),
      TextCellValue('النوع'),
      TextCellValue('التفاصيل'),
    ]);
    for (final t in transactions) {
      sheet.appendRow([
        TextCellValue(_date(t.date)),
        TextCellValue(_money(t.amount)),
        TextCellValue(_currency(t.currency)),
        TextCellValue(t.type == DebtType.credit ? 'له' : 'عليه'),
        TextCellValue(t.details ?? ''),
      ]);
    }

    sheet.appendRow([]);
    sheet.appendRow([TextCellValue('السدادات')]);
    sheet.appendRow([
      TextCellValue('التاريخ'),
      TextCellValue('المبلغ'),
      TextCellValue('العملة'),
      TextCellValue('الاتجاه'),
      TextCellValue('الملاحظات'),
    ]);
    for (final p in payments) {
      sheet.appendRow([
        TextCellValue(_date(p.paymentDate)),
        TextCellValue(_money(p.amount)),
        TextCellValue(_currency(p.currency)),
        TextCellValue(_paymentDirection(p.direction)),
        TextCellValue(p.note ?? ''),
      ]);
    }

    final bytes = excel.encode();
    if (bytes == null) throw Exception('فشل إنشاء ملف Excel');
    final output = await getTemporaryDirectory();
    final safeName = customer.name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final file = File('${output.path}/كشف_حساب_${safeName}_${DateTime.now().millisecondsSinceEpoch}.xlsx');
    await file.writeAsBytes(bytes);
    return file.path;
  }

  static Future<void> shareFile(String filePath, {String message = 'كشف الحساب'}) async {
    await SharePlus.instance.share(
      ShareParams(files: [XFile(filePath)], text: message),
    );
  }

  static Future<String> generateGeneralPDF({
    required String title,
    required List<List<String>> rows,
    required List<String> headers,
  }) async {
    final pdf = pw.Document();
    final font = await _loadArabicFont();
    final bold = await _loadArabicBoldFont();
    pdf.addPage(
      pw.MultiPage(
        build: (_) => [
          pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                pw.Text(title, textAlign: pw.TextAlign.right, style: pw.TextStyle(font: bold, fontSize: 20)),
                pw.SizedBox(height: 12),
                pw.Table(
                  border: pw.TableBorder.all(color: PdfColors.grey400),
                  defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: [
                    pw.TableRow(children: headers.map((h) => _buildHeaderCell(h, bold)).toList()),
                    ...rows.map((r) => pw.TableRow(children: r.map((c) => _buildDataCell(c, font)).toList())),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/report_${DateTime.now().millisecondsSinceEpoch}.pdf';
    await File(path).writeAsBytes(await pdf.save());
    return path;
  }

  static Future<String> generateGeneralExcel({
    required String title,
    required List<List<String>> rows,
    required List<String> headers,
  }) async {
    final excel = Excel.createExcel();
    final sheet = excel['التقرير'];
    sheet.appendRow([TextCellValue(title)]);
    sheet.appendRow(headers.map(TextCellValue.new).toList());
    for (final row in rows) {
      sheet.appendRow(row.map(TextCellValue.new).toList());
    }
    final bytes = excel.encode();
    if (bytes == null) throw Exception('تعذر إنشاء ملف Excel');
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/report_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    await File(path).writeAsBytes(bytes);
    return path;
  }
}
