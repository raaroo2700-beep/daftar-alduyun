import 'dart:convert';
import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wasla_debt/core/services/device_id_service.dart';
import 'package:url_launcher/url_launcher.dart';

enum ActivationStatus { active, used, expired, revoked }

class ActivationInfo {
  final String code;
  final ActivationStatus status;
  final int? expiryDate;
  final String duration;
  final String? deviceId;
  final String? licenseId;
  final int? lastVerifiedAt;

  ActivationInfo({
    required this.code,
    required this.status,
    required this.expiryDate,
    required this.duration,
    this.deviceId,
    this.licenseId,
    this.lastVerifiedAt,
  });

  bool get isActive => status == ActivationStatus.active && (isLifetime || (expiryDate != null && expiryDate! > DateTime.now().millisecondsSinceEpoch));
  bool get isLifetime => duration == 'lifetime';

  Map<String, dynamic> toMap() {
    return {
      'code': code,
      'status': status.name,
      'expiryDate': expiryDate,
      'duration': duration,
      'deviceId': deviceId,
      'licenseId': licenseId,
      'lastVerifiedAt': lastVerifiedAt,
    };
  }

  factory ActivationInfo.fromMap(Map<String, dynamic> map) {
    return ActivationInfo(
      code: map['code'],
      status: ActivationStatus.values.firstWhere(
            (e) => e.name == map['status'],
        orElse: () => ActivationStatus.expired,
      ),
      expiryDate: (map['expiryDate'] as num?)?.toInt(),
      duration: (map['duration'] as String?) ?? '30d',
      deviceId: map['deviceId'] as String?,
      licenseId: map['licenseId'] as String?,
      lastVerifiedAt: (map['lastVerifiedAt'] as num?)?.toInt(),
    );
  }
}

class ActivationService {
static const String _storageKey = 'activation_info';
static const int _freeCustomersLimit = 30;

// ⚠️ إصلاح 6.1: هذه القائمة كانت الطريقة *الوحيدة* للتحقق من رموز التفعيل،
// أي أن أي شخص يملك نسخة من الكود يمكنه استخراج رموز مدى الحياة صالحة مجانًا.
// - في وضع الإصدار (release) لم تعد تُستخدم إطلاقًا؛ التحقق يمر إجباريًا عبر
//   نقطة النهاية الخلفية (_verifyCodeRemote).
// - أُبقيت هنا فقط للتطوير/الاختبار المحلي بدون اتصال (kDebugMode).
// TODO(backend): استبدل _verifyEndpoint بالرابط الفعلي لخادم التفعيل الخاص
// بكم بعد بنائه؛ هذا الملف لا يستطيع بناء ذلك الخادم من داخل التطبيق نفسه.
static const String _apiBaseUrl = String.fromEnvironment(
  'ACTIVATION_API_BASE_URL',
  defaultValue: 'https://wasla-activation-api.wasla-activation-api.workers.dev',
);
static Uri get _verifyEndpoint => Uri.parse('$_apiBaseUrl/v1/activation/verify');
static Uri get _statusEndpoint => Uri.parse('$_apiBaseUrl/v1/activation/status');
static const Duration _statusRefreshInterval = Duration(days: 3);
static const Duration _offlineGracePeriod = Duration(days: 7);

static Future<ActivationInfo?> verifyCode(String code) async {
  final deviceId = await DeviceIdService.getDeviceId();
  if (kDebugMode) {
    const debugOnlyTestCodes = <String, String>{
      'WASLA-ABCD-1234-EFGH': '365d',
      'WASLA-TEST-5678-IJKL': '30d',
      'WASLA-LIFE-9012-MNOP': 'lifetime',
    };
    final duration = debugOnlyTestCodes[code];
    if (duration != null) {
      return ActivationInfo(code: code, status: ActivationStatus.active, expiryDate: _calculateExpiry(duration), duration: duration, deviceId: deviceId, licenseId: 'debug-$code', lastVerifiedAt: DateTime.now().millisecondsSinceEpoch);
    }
  }
  return _verifyCodeRemote(code, deviceId);
}

/// يتحقق من الرمز عبر الخادم الخلفي. يعيد null إن كان الرمز غير صالح أو
/// تعذّر الاتصال (بدلاً من رمي استثناء يوقف تدفق الشاشة).
static Future<ActivationInfo?> _verifyCodeRemote(String code, String deviceId) async {
  try {
    final response = await http
        .post(
          _verifyEndpoint,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'code': code, 'deviceId': deviceId}),
        )
        .timeout(const Duration(seconds: 10));

    if (response.statusCode != 200) return null;
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (body['valid'] != true) return null;
    final returnedDeviceId = body['deviceId'] as String?;
    if (returnedDeviceId != null && returnedDeviceId != deviceId) return null;

    final duration = body['plan'] as String? ?? body['duration'] as String? ?? '30d';
    final expiryDate = (body['expiresAt'] as num?)?.toInt();
    return ActivationInfo(
      code: code,
      status: ActivationStatus.active,
      expiryDate: duration == 'lifetime' ? null : expiryDate,
      duration: duration,
      deviceId: deviceId,
      licenseId: body['licenseId'] as String?,
      lastVerifiedAt: DateTime.now().millisecondsSinceEpoch,
    );
  } catch (_) {
    // لا يوجد خادم مُعدّ بعد، أو تعذّر الاتصال بالشبكة.
    return null;
  }
}

static int _calculateExpiry(String duration) {
final now = DateTime.now().millisecondsSinceEpoch;
switch (duration) {
case '30d': return now + 30 * 24 * 60 * 60 * 1000;
case '90d': return now + 90 * 24 * 60 * 60 * 1000;
case '180d': return now + 180 * 24 * 60 * 60 * 1000;
case '365d': return now + 365 * 24 * 60 * 60 * 1000;
case 'lifetime': return 9223372036854775807;
default: return now + 30 * 24 * 60 * 60 * 1000;
}
}

static Future<void> saveActivation(ActivationInfo info) async {
final prefs = await SharedPreferences.getInstance();
await prefs.setString(_storageKey, jsonEncode(info.toMap()));
}

static Future<ActivationInfo?> getActivation() async {
final prefs = await SharedPreferences.getInstance();
final data = prefs.getString(_storageKey);
if (data != null) {
try {
final map = jsonDecode(data) as Map<String, dynamic>;
return ActivationInfo.fromMap(map);
} catch (e) {
return null;
}
}
return null;
}

static Future<bool> isPremium() async {
  final info = await getActivation();
  if (info == null || !info.isActive) return false;
  if (info.deviceId == null) return false;
  final currentDeviceId = await DeviceIdService.getDeviceId();
  return info.deviceId == currentDeviceId;
}

static Future<bool> refreshStatusIfDue() async {
  final info = await getActivation();
  if (info == null || info.licenseId == null || info.deviceId == null) return info?.isActive ?? false;
  final last = info.lastVerifiedAt;
  final now = DateTime.now().millisecondsSinceEpoch;
  if (last != null && now - last < _statusRefreshInterval.inMilliseconds) return info.isActive;

  try {
    final deviceId = await DeviceIdService.getDeviceId();
    if (deviceId != info.deviceId) return false;
    final response = await http.post(
      _statusEndpoint,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'licenseId': info.licenseId, 'deviceId': deviceId}),
    ).timeout(const Duration(seconds: 8));
    if (response.statusCode != 200) return info.isActive;
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    final statusName = body['status'] as String?;
    if (statusName == null) return info.isActive;
    final status = ActivationStatus.values.firstWhere(
      (e) => e.name == statusName,
      orElse: () => ActivationStatus.expired,
    );
    final refreshed = ActivationInfo(
      code: info.code,
      status: status,
      expiryDate: (body['expiresAt'] as num?)?.toInt() ?? info.expiryDate,
      duration: (body['plan'] as String?) ?? info.duration,
      deviceId: deviceId,
      licenseId: info.licenseId,
      lastVerifiedAt: now,
    );
    await saveActivation(refreshed);
    return refreshed.isActive;
  } catch (_) {
    if (last == null || now - last > _offlineGracePeriod.inMilliseconds) return false;
    return info.isActive;
  }
}

static Future<String> getDeviceId() => DeviceIdService.getDeviceId();

static Future<bool> canAddCustomer(int currentCustomerCount) async {
if (await isPremium()) return true;
return currentCustomerCount < _freeCustomersLimit;
}

static Future<int> getRemainingFreeCustomers(int currentCustomerCount) async {
if (await isPremium()) return -1;
return (_freeCustomersLimit - currentCustomerCount).clamp(0, _freeCustomersLimit).toInt();
}

static Future<void> clearActivation() async {
final prefs = await SharedPreferences.getInstance();
await prefs.remove(_storageKey);
}

// إصلاح (تواصل التفعيل): رقمان للتواصل عبر واتساب يظهران كخيارين للعميل،
// بدل الرقم التجريبي الثابت الذي كان موجودًا سابقًا.
static const List<Map<String, String>> whatsAppContacts = [
  {'label': 'تواصل عبر واتساب 1', 'phone': '967775123404'},
  {'label': 'تواصل عبر واتساب 2', 'phone': '967738059109'},
];

// Backward-compatible entry point for older activation UI copies.
// Uses the first configured support contact; the canonical UI uses
// contactWhatsAppNumber() for the selected contact.
static Future<void> contactWhatsApp() async {
  await contactWhatsAppNumber(whatsAppContacts.first['phone']!);
}

static Future<void> contactWhatsAppNumber(String phone) async {
  const message = 'أرغب في الحصول على رمز تفعيل تطبيق دفتر الديون';
  final uri = Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent(message)}');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}

  static Future<void> contactEmail() async {
    const email = 'support@wasla.com';
    const subject = 'طلب رمز تفعيل تطبيق دفتر الديون';
    final uri = Uri.parse('mailto:$email?subject=${Uri.encodeComponent(subject)}');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }
}