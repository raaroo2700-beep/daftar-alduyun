import 'package:sqflite/sqflite.dart';
import 'package:wasla_debt/data/models/audit_log.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/audit_repository.dart';

class AuditService {
  static final AuditRepository _repository = AuditRepository();
  static Future<void> _write(AuditLog log, Transaction? txn) async {
    if (txn != null) {
      await _repository.insertAuditLogWithTxn(log, txn);
    } else {
      await _repository.insertAuditLog(log);
    }
  }

  static Future<void> logTransactionCreate({required DebtTransaction transaction, String? userId, String? note, Transaction? txn}) =>
      _write(AuditLog(entityType: 'transaction', entityId: transaction.id!, action: AuditAction.create, newValues: transaction.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, userId: userId, note: note ?? 'تم إنشاء المعاملة'), txn);

  static Future<void> logTransactionUpdate({required DebtTransaction oldTransaction, required DebtTransaction newTransaction, String? userId, String? note, Transaction? txn}) =>
      _write(AuditLog(entityType: 'transaction', entityId: newTransaction.id!, action: AuditAction.update, oldValues: oldTransaction.toMap(), newValues: newTransaction.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, userId: userId, note: note ?? 'تم تحديث المعاملة'), txn);

  static Future<void> logTransactionArchive({required int transactionId, required DebtTransaction oldTransaction, String? userId, String? note, Transaction? txn}) =>
      _write(AuditLog(entityType: 'transaction', entityId: transactionId, action: AuditAction.archive, oldValues: oldTransaction.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, userId: userId, note: note ?? 'تمت أرشفة المعاملة'), txn);

  static Future<void> logTransactionRestore({required int transactionId, required DebtTransaction restoredTransaction, String? userId, String? note, Transaction? txn}) =>
      _write(AuditLog(entityType: 'transaction', entityId: transactionId, action: AuditAction.restore, newValues: restoredTransaction.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, userId: userId, note: note ?? 'تمت استعادة المعاملة'), txn);

  static Future<void> logCustomerCreate({required Customer customer, Transaction? txn}) =>
      _write(AuditLog(entityType: 'customer', entityId: customer.id!, action: AuditAction.create, newValues: customer.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, note: 'تم إنشاء العميل'), txn);

  static Future<void> logCustomerUpdate({required Customer oldCustomer, required Customer newCustomer, String? userId, String? note, Transaction? txn}) =>
      _write(AuditLog(entityType: 'customer', entityId: newCustomer.id!, action: AuditAction.update, oldValues: oldCustomer.toMap(), newValues: newCustomer.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, userId: userId, note: note ?? 'تم تحديث بيانات العميل'), txn);

  static Future<void> logCustomerArchive({required Customer oldCustomer, required Customer newCustomer, Transaction? txn}) =>
      _write(AuditLog(entityType: 'customer', entityId: newCustomer.id!, action: AuditAction.archive, oldValues: oldCustomer.toMap(), newValues: newCustomer.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, note: 'تمت أرشفة العميل'), txn);

  static Future<void> logCustomerRestore({required Customer oldCustomer, required Customer newCustomer, Transaction? txn}) =>
      _write(AuditLog(entityType: 'customer', entityId: newCustomer.id!, action: AuditAction.restore, oldValues: oldCustomer.toMap(), newValues: newCustomer.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, note: 'تمت استعادة العميل'), txn);

  static Future<void> logCustomerDelete({required Customer customer, String? userId, String? note, Transaction? txn}) =>
      _write(AuditLog(entityType: 'customer', entityId: customer.id!, action: AuditAction.delete, oldValues: customer.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, userId: userId, note: note ?? 'تم حذف العميل نهائيًا'), txn);

  static Future<void> logTransfer({required int sourceTransactionId, required int destinationTransactionId, required int fromCustomerId, required int toCustomerId, required double amount, required String currency, Transaction? txn}) =>
      _write(AuditLog(entityType: 'transfer', entityId: sourceTransactionId, action: AuditAction.transfer, newValues: {'sourceTransactionId': sourceTransactionId, 'destinationTransactionId': destinationTransactionId, 'fromCustomerId': fromCustomerId, 'toCustomerId': toCustomerId, 'amount': amount, 'currency': currency}, timestamp: DateTime.now().millisecondsSinceEpoch, note: 'تحويل بين حسابي عميلين'), txn);

  static Future<void> logPaymentCreate({required Payment payment, Transaction? txn}) =>
      _write(AuditLog(entityType: 'payment', entityId: payment.id!, action: AuditAction.create, newValues: payment.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, note: 'تم إنشاء السداد'), txn);

  static Future<void> logPaymentUpdate({required Payment oldPayment, required Payment newPayment, Transaction? txn}) =>
      _write(AuditLog(entityType: 'payment', entityId: newPayment.id!, action: AuditAction.update, oldValues: oldPayment.toMap(), newValues: newPayment.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, note: 'تم تعديل السداد'), txn);

  static Future<void> logPaymentDelete({required Payment payment, Transaction? txn}) =>
      _write(AuditLog(entityType: 'payment', entityId: payment.id!, action: AuditAction.delete, oldValues: payment.toMap(), timestamp: DateTime.now().millisecondsSinceEpoch, note: 'تم حذف السداد'), txn);
}
