import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wasla_debt/core/services/attachment_service.dart';
import 'package:wasla_debt/data/repositories/backup_repository.dart';
import 'package:wasla_debt/data/models/backup_metadata.dart';

class BackupService {
  static const int maxBackupBytes = 100 * 1024 * 1024;
  static const int maxBackupAttachmentFiles = 1000;
  final BackupRepository _repository = BackupRepository();
  final AttachmentService _attachments = AttachmentService();

  // إصلاح (النسخ المحلي): المجلد الفعلي الذي تُحفظ فيه النسخ الاحتياطية.
  // يعيد مجلد العميل المخصص إن كان محفوظًا وقابلاً للكتابة فعلاً، وإلا
  // يعود تلقائيًا لمجلد بيانات التطبيق الافتراضي كما كان سابقًا. لا نثق
  // بمجرد وجود المسار المحفوظ لأن العميل قد يحذف المجلد أو ينزع صلاحية
  // الوصول إليه (بطاقة SD تُفصل، إلخ) بعد اختياره.
  Future<Directory> _resolveBackupDirectory() async {
    final prefs = await SharedPreferences.getInstance();
    final customPath = prefs.getString('backupFolderPath');
    if (customPath != null && customPath.isNotEmpty) {
      final dir = Directory(customPath);
      try {
        if (!await dir.exists()) await dir.create(recursive: true);
        final probe = File(p.join(dir.path, '.wasla_write_check'));
        await probe.writeAsBytes(const [0]);
        await probe.delete();
        return dir;
      } catch (_) {
        // المجلد المخصص لم يعد قابلاً للكتابة (حُذف/فُصل/صلاحية منعت الوصول).
        // نعود للمسار الافتراضي بدل فشل النسخة الاحتياطية بالكامل.
      }
    }
    return getApplicationDocumentsDirectory();
  }

  Future<String> createBackup() async {
    final prefs = await SharedPreferences.getInstance();
    final shared = <String, dynamic>{};
    for (final key in ['defaultCurrency', 'showTime', 'darkMode', 'maxBackups', 'autoBackup', 'backupFolderPath', 'autoBackupHour', 'autoBackupMinute']) {
      final value = prefs.get(key);
      if (value != null) shared[key] = value;
    }

    final data = await _repository.buildBackupData(sharedPreferences: shared);
    final archive = Archive();
    var attachmentCount = 0;
    var attachmentBytes = 0;
    final normalizedTransactions = <Map<String, dynamic>>[];
    final transactions = data['transactions'] as List;
    for (final raw in transactions) {
      final transaction = Map<String, dynamic>.from(raw as Map);
      final imagePath = transaction['imagePath']?.toString();
      if (imagePath == null || imagePath.isEmpty) {
        normalizedTransactions.add(transaction);
        continue;
      }
      File? source;
      late final String backupRelativePath;
      if (_attachments.isSafeRelativePath(imagePath)) {
        source = await _attachments.resolveRelativePath(imagePath);
        backupRelativePath = imagePath.replaceAll('\\', '/');
      } else {
        // Legacy absolute paths are included in the backup if they still exist;
        // the DB representation itself is not modified by backup creation.
        final candidate = File(imagePath);
        if (p.isAbsolute(candidate.path) && await candidate.exists()) {
          source = candidate;
        }
        backupRelativePath = 'attachments/${transaction['id']}/image${p.extension(imagePath)}';
      }
      if (source != null && await source.exists()) {
        if (++attachmentCount > maxBackupAttachmentFiles) throw Exception('عدد المرفقات في النسخة يتجاوز الحد المسموح');
        final bytes = await source.readAsBytes();
        if (bytes.length <= AttachmentService.maxBytes && attachmentBytes + bytes.length <= maxBackupBytes) {
          attachmentBytes += bytes.length;
          final entry = backupRelativePath;
          archive.addFile(ArchiveFile(entry, bytes.length, bytes));
          transaction['imagePath'] = entry;
        } else {
          transaction['imagePath'] = null;
        }
      } else {
        transaction['imagePath'] = null;
      }
      normalizedTransactions.add(transaction);
    }
    data['transactions'] = normalizedTransactions;
    final jsonBytes = utf8.encode(jsonEncode(data));
    archive.addFile(ArchiveFile('backup.json', jsonBytes.length, jsonBytes));

    final zipBytes = ZipEncoder().encode(archive);
    if (zipBytes == null) {
      throw Exception('تعذر إنشاء ملف ZIP');
    }
    if (zipBytes.length > maxBackupBytes) throw Exception('حجم النسخة الاحتياطية يتجاوز 100MB');
    final directory = await _resolveBackupDirectory();
    final fileName = 'wasla_backup_${data['backupDate']}.zip';
    final filePath = p.join(directory.path, fileName);
    await File(filePath).writeAsBytes(zipBytes, flush: true);

    await _repository.saveBackupMetadata(BackupMetadata(backupDate: data['backupDate'] as int, schemaVersion: 2, fileName: fileName));
    await _enforceMaxBackups();
    return filePath;
  }

  Future<void> _enforceMaxBackups() async {
    final prefs = await SharedPreferences.getInstance();
    final maxBackups = prefs.getInt('maxBackups') ?? 5;
    final all = await _repository.getAllBackups();
    if (all.length <= maxBackups) return;
    final directory = await _resolveBackupDirectory();
    for (final old in all.skip(maxBackups)) {
      final file = File(p.join(directory.path, old.fileName));
      if (await file.exists()) await file.delete();
      if (old.id != null) await _repository.deleteBackupMetadata(old.id!);
    }
  }

  // إصلاح (النسخ التلقائي بوقت محدد): كما هو موضّح في تعليق AppSettings،
  // لا يوجد تنفيذ خلفي حقيقي في Flutter بدون حزمة جدولة نظام (workmanager
  // أو ما شابه) وهي غير مضافة لهذا المشروع. لذلك هذا التحقق ما زال يعمل فقط
  // عند فتح التطبيق (كما كان)، لكنه الآن يحترم "الساعة" التي اختارها العميل:
  // لا يُنشئ نسخة تلقائية إلا إذا كان الوقت الحالي بعد الساعة المحددة، وإذا
  // لم تُؤخذ نسخة بعد اليوم (لا نكرر النسخ عدة مرات في نفس اليوم).
  Future<void> runAutoBackupIfDue() async {
    final prefs = await SharedPreferences.getInstance();
    if (!(prefs.getBool('autoBackup') ?? false)) return;

    final targetHour = prefs.getInt('autoBackupHour') ?? 2;
    final targetMinute = prefs.getInt('autoBackupMinute') ?? 0;
    final now = DateTime.now();
    final afterTargetTime = now.hour > targetHour ||
        (now.hour == targetHour && now.minute >= targetMinute);
    if (!afterTargetTime) return;

    final latest = await _repository.getLatestBackup();
    if (latest == null) {
      await createBackup();
      return;
    }
    final lastBackupDate = DateTime.fromMillisecondsSinceEpoch(latest.backupDate);
    final isSameDay = lastBackupDate.year == now.year &&
        lastBackupDate.month == now.month &&
        lastBackupDate.day == now.day;
    if (!isSameDay) await createBackup();
  }

  Future<void> restoreBackup(String filePath) async {
    final source = File(filePath);
    if (!await source.exists()) throw Exception('ملف النسخة الاحتياطية غير موجود');
    final bytes = await source.readAsBytes();
    Map<String, dynamic> data;
    Archive? archive;
    try {
      archive = ZipDecoder().decodeBytes(bytes);
      final entry = archive.findFile('backup.json');
      if (entry == null) throw Exception('ملف ZIP غير صالح: backup.json مفقود');
      data = jsonDecode(utf8.decode(entry.content as List<int>)) as Map<String, dynamic>;
    } catch (_) {
      data = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
    }
    _repository.validateBackupData(data);

    // Always create a safety snapshot before replacing the live database.
    // If the target restore is bad or the user needs to roll back, the
    // immediately preceding state is still available as a local backup.
    await createBackup();

    final prefs = await SharedPreferences.getInstance();
    final oldShared = <String, dynamic>{};
    for (final key in ['defaultCurrency', 'showTime', 'darkMode', 'maxBackups', 'autoBackup', 'backupFolderPath', 'autoBackupHour', 'autoBackupMinute']) {
      oldShared[key] = prefs.get(key);
    }

    Directory? stagedAttachments;
    if (archive != null) {
      stagedAttachments = await _stageAttachments(archive);
    }
    try {
      await _repository.restoreBackup(data);
      final shared = (data['sharedPreferences'] as Map?)?.cast<String, dynamic>();
      if (shared != null) {
        for (final entry in shared.entries) {
          final value = entry.value;
          if (value is String) {
            await prefs.setString(entry.key, value);
          } else if (value is bool) {
            await prefs.setBool(entry.key, value);
          } else if (value is int) {
            await prefs.setInt(entry.key, value);
          } else if (value is double) {
            await prefs.setDouble(entry.key, value);
          }
        }
      }
      if (stagedAttachments != null && await _hasStagedAttachmentFiles(stagedAttachments)) {
        await _replaceAttachments(stagedAttachments);
      }
    } catch (e) {
      // Database transaction already rolls back its own changes. Restore only the
      // external SharedPreferences values if they were changed before failure.
      for (final entry in oldShared.entries) {
        final value = entry.value;
        if (value == null) {
          await prefs.remove(entry.key);
        } else if (value is String) {
          await prefs.setString(entry.key, value);
        } else if (value is bool) {
          await prefs.setBool(entry.key, value);
        } else if (value is int) {
          await prefs.setInt(entry.key, value);
        } else if (value is double) {
          await prefs.setDouble(entry.key, value);
        }
      }
      rethrow;
    } finally {
      if (stagedAttachments != null && await stagedAttachments.exists()) await stagedAttachments.delete(recursive: true);
    }
  }

  Future<Directory> _stageAttachments(Archive archive) async {
    final temp = await Directory.systemTemp.createTemp('wasla_restore_attachments_');
    for (final file in archive.files) {
      if (!file.name.startsWith('attachments/')) continue;
      if (!_attachments.isSafeRelativePath(file.name)) throw Exception('مرفق بمسار غير آمن');
      final content = file.content as List<int>;
      if (content.length > AttachmentService.maxBytes) throw Exception('مرفق يتجاوز 10MB');
      if (file.name.split('/').length < 3) throw Exception('مسار مرفق غير صالح');
      final out = File(p.join(temp.path, file.name.substring('attachments/'.length)));
      await out.parent.create(recursive: true);
      await out.writeAsBytes(content, flush: true);
    }
    return temp;
  }

  Future<bool> _hasStagedAttachmentFiles(Directory staged) async {
    await for (final entity in staged.list(recursive: true)) {
      if (entity is File) return true;
    }
    return false;
  }

  Future<void> _replaceAttachments(Directory staged) async {
    final documents = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(documents.path, 'attachments'));
    final backupOld = Directory(p.join(documents.path, '.attachments_restore_backup'));
    if (await backupOld.exists()) await backupOld.delete(recursive: true);
    if (await root.exists()) await root.rename(backupOld.path);
    try {
      await root.create(recursive: true);
      await for (final entity in staged.list(recursive: true)) {
        if (entity is File) {
          final relative = p.relative(entity.path, from: staged.path);
          final target = File(p.join(root.path, relative));
          await target.parent.create(recursive: true);
          await entity.copy(target.path);
        }
      }
      if (await backupOld.exists()) await backupOld.delete(recursive: true);
    } catch (_) {
      if (await root.exists()) await root.delete(recursive: true);
      if (await backupOld.exists()) await backupOld.rename(root.path);
      rethrow;
    }
  }

  Future<String?> getLatestBackupPath() async {
    final metadata = await _repository.getLatestBackup();
    if (metadata == null) return null;
    final directory = await _resolveBackupDirectory();
    return p.join(directory.path, metadata.fileName);
  }
}
