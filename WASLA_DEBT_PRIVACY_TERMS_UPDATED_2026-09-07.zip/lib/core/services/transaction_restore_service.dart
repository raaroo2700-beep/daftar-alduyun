import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

class TransactionRestoreService {
  static final TransactionRepository _repo = TransactionRepository();

  static Future<void> restoreTransaction(int id) async {
    final db = await AppDatabase().database;
    await db.transaction((txn) async {
      final old = await _repo.getTransactionByIdWithTxn(id, txn);
      if (old == null) throw Exception('المعاملة غير موجودة');
      if (!old.isArchived) throw Exception('المعاملة نشطة بالفعل');
      if (await _repo.restoreTransactionWithTxn(id, txn) != 1) {
        throw Exception('تعذر استعادة المعاملة');
      }
      final restored = await _repo.getTransactionByIdWithTxn(id, txn);
      await AuditService.logTransactionRestore(
        transactionId: id,
        restoredTransaction: restored ?? old.copyWith(isArchived: false),
        note: 'استعادة يدوية من المعاملات المؤرشفة',
        txn: txn,
      );
    });
  }
}
