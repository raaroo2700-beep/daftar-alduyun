import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';

/// المصدر المركزي الوحيد لحساب الرصيد في التطبيق (Task P0-01، مُحدَّث
/// في P0-02 لاستقبال السداد).
///
/// المرجع: P0-01_FINAL_AUDIT.txt القسم 7 + 01_REQUIREMENTS.md القسم 4
/// + خطة P0-02 الخطوة 6.
///
/// يتعامل مع [DebtTransaction] و[Payment]. جدول settlements القديم خارج
/// نطاق هذا الصنف بالكامل ولا يزال غير مُستخدَم هنا.
///
/// التعريف المالي المعتمد:
/// - "عليه" (DebtType.debit) → يُضاف إلى totalDebit (قيمة موجبة).
/// - "له" (DebtType.credit) → يُضاف إلى totalCredit (قيمة موجبة).
/// - كل [Payment] → يُضاف إلى totalPayments (قيمة موجبة).
/// - الرصيد النهائي لكل عملة = totalDebit - totalCredit - totalPayments
///   (انظر [BalanceResult]).
///
/// كل عملة (YER/SAR/USD) رصيدها مستقل تمامًا؛ لا يوجد أي دمج أو تحويل بين
/// العملات في هذا الصنف.
///
/// [payments] معامل اختياري في كلتا الدالتين (افتراضيًا قائمة فارغة) حتى
/// لا يُكسَر أي استدعاء قديم من P0-01 لا يزال لا يمرّر سدادات (لم تُعدَّل
/// الـ Providers بعد في هذه الخطوة).
class BalanceCalculator {
  const BalanceCalculator._();

  /// حساب رصيد عميل واحد (أو أي مجموعة معاملات/سدادات خاصة بعميل) مقسّمًا
  /// حسب العملة. المتصل هو من يحدد أي معاملات وأي سدادات تخص العميل
  /// (بالفلترة قبل الاستدعاء)؛ هذه الدالة لا تعرف رقم العميل.
  static Map<Currency, BalanceResult> calculateClientBalance({
    required List<DebtTransaction> transactions,
    List<Payment> payments = const [],
  }) {
    return _calculateByCurrency(transactions, payments);
  }

  /// حساب الرصيد الإجمالي لمجموعة معاملات/سدادات (بلا تقسيم حسب عميل)
  /// مقسّمًا حسب العملة. نفس منطق [calculateClientBalance] تمامًا؛ الفرق
  /// فقط في المعاملات والسدادات المُمرَّرة من المتصل.
  static Map<Currency, BalanceResult> calculateTotalBalance({
    required List<DebtTransaction> transactions,
    List<Payment> payments = const [],
  }) {
    return _calculateByCurrency(transactions, payments);
  }

  static Map<Currency, BalanceResult> _calculateByCurrency(
    List<DebtTransaction> transactions,
    List<Payment> payments,
  ) {
    final activeTransactions =
        transactions.where((tx) => !tx.isArchived).toList();

    final byCurrency = <Currency, List<DebtTransaction>>{};
    for (final tx in activeTransactions) {
      byCurrency.putIfAbsent(tx.currency, () => []).add(tx);
    }

    final paymentsByCurrency = <Currency, List<Payment>>{};
    for (final p in payments) {
      paymentsByCurrency.putIfAbsent(p.currency, () => []).add(p);
    }

    // اتحاد العملتين حتى لا تُفقَد عملة سداد لا توجد لها معاملات (حالة
    // حدية نظرية: سداد بعملة بلا أي معاملة عليها بعد).
    final currencies = <Currency>{
      ...byCurrency.keys,
      ...paymentsByCurrency.keys,
    };

    final result = <Currency, BalanceResult>{};
    for (final currency in currencies) {
      final txList = byCurrency[currency] ?? const [];
      final payList = paymentsByCurrency[currency] ?? const [];

      double totalDebit = 0.0;
      double totalCredit = 0.0;
      double totalPaymentsReceived = 0.0;
      double totalPaymentsPaid = 0.0;

      for (final tx in txList) {
        if (tx.type == DebtType.debit) {
          totalDebit += tx.amount;
        } else {
          totalCredit += tx.amount;
        }
      }

      for (final p in payList) {
        if (p.direction == PaymentDirection.customerToBusiness) {
          totalPaymentsReceived += p.amount;
        } else {
          totalPaymentsPaid += p.amount;
        }
      }

      result[currency] = BalanceResult(
        currency: currency,
        totalDebit: totalDebit,
        totalCredit: totalCredit,
        totalPaymentsReceived: totalPaymentsReceived,
        totalPaymentsPaid: totalPaymentsPaid,
      );
    }

    return result;
  }
}
