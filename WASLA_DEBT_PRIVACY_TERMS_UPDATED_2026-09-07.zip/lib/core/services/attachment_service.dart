import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class AttachmentService {
  static const int maxBytes = 10 * 1024 * 1024;
  static const String _rootName = 'attachments';

  Future<Directory> _root() async {
    final documents = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(documents.path, _rootName));
    await root.create(recursive: true);
    return root;
  }

  Future<String> saveAttachment(int transactionId, XFile file) async {
    final source = File(file.path);
    if (!await source.exists()) throw Exception('ملف المرفق غير موجود');
    final length = await source.length();
    if (length > maxBytes) throw Exception('حجم المرفق يتجاوز 10MB');

    final root = await _root();
    final transactionDir = Directory(p.join(root.path, transactionId.toString()));
    await transactionDir.create(recursive: true);

    final extension = p.extension(file.name).toLowerCase();
    final safeExtension = extension.length <= 10 && RegExp(r'^\.[a-z0-9]+$').hasMatch(extension)
        ? extension
        : '';
    final name = 'attachment_${DateTime.now().microsecondsSinceEpoch}$safeExtension';
    final target = File(p.join(transactionDir.path, name));
    await source.copy(target.path);
    return p.join(_rootName, transactionId.toString(), name).replaceAll('\\', '/');
  }

  Future<File?> getAttachment(int transactionId) async {
    final root = await _root();
    final dir = Directory(p.join(root.path, transactionId.toString()));
    if (!await dir.exists()) return null;
    final files = await dir.list().where((e) => e is File).cast<File>().toList();
    if (files.isEmpty) return null;
    files.sort((a, b) => b.path.compareTo(a.path));
    return files.first;
  }

  Future<void> deleteAttachmentPath(String relativePath) async {
    if (!_isSafeRelativePath(relativePath)) throw Exception('مسار المرفق غير آمن');
    final file = await resolveRelativePath(relativePath);
    if (file != null && await file.exists()) await file.delete();
  }

  Future<void> deleteAttachment(int transactionId) async {
    final root = await _root();
    final dir = Directory(p.join(root.path, transactionId.toString()));
    if (await dir.exists()) await dir.delete(recursive: true);
  }

  Future<File?> resolveRelativePath(String relativePath) async {
    if (!_isSafeRelativePath(relativePath)) return null;
    final documents = await getApplicationDocumentsDirectory();
    final normalized = relativePath.replaceAll('\\', '/');
    final file = File(p.join(documents.path, normalized));
    final root = p.normalize(p.join(documents.path, _rootName));
    final candidate = p.normalize(file.path);
    if (!(candidate == root || p.isWithin(root, candidate))) return null;
    return file;
  }

  bool isSafeRelativePath(String path) => _isSafeRelativePath(path);

  bool _isSafeRelativePath(String path) {
    if (path.trim().isEmpty || p.isAbsolute(path)) return false;
    final normalized = path.replaceAll('\\', '/');
    if (!normalized.startsWith('$_rootName/')) return false;
    if (normalized.split('/').contains('..')) return false;
    return !RegExp(r'^[a-zA-Z]:').hasMatch(normalized);
  }
}
