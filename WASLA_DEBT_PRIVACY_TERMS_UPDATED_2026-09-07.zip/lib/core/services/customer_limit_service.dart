import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:sqflite/sqflite.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';

class CustomerLimitService {
  static Future<String?> transactionWarning({
    required Customer customer,
    required DebtTransaction candidate,
    required DatabaseExecutor db,
  }) async {
    final txRows = await db.query('transactions',
        where: 'customerId = ? AND isArchived = 0', whereArgs: [customer.id]);
    final paymentRows = await db.query('payments',
        where: 'customerId = ?', whereArgs: [customer.id]);
    final txs = txRows.map(DebtTransaction.fromMap).toList()..add(candidate);
    final payments = paymentRows.map(Payment.fromMap).toList();
    final balance = BalanceCalculator.calculateClientBalance(
      transactions: txs, payments: payments,
    )[candidate.currency]?.balance ?? 0;

    final debtLimit = customer.debtLimitFor(candidate.currency);
    final creditLimit = customer.creditLimitFor(candidate.currency);
    if (balance > 0 && debtLimit != null && balance > debtLimit) {
      return 'بعد حفظ العملية سيصبح رصيد العميل عليه ${MoneyFormat.amount(balance)} ${candidate.currency.name.toUpperCase()}، متجاوزًا سقف عليه (${MoneyFormat.amount(debtLimit)}). هل تريد المتابعة؟';
    }
    if (balance < 0 && creditLimit != null && balance.abs() > creditLimit) {
      return 'بعد حفظ العملية سيصبح رصيد العميل له ${MoneyFormat.amount(balance.abs())} ${candidate.currency.name.toUpperCase()}، متجاوزًا سقف له (${MoneyFormat.amount(creditLimit)}). هل تريد المتابعة؟';
    }
    return null;
  }

  /// Kept for service-level callers that explicitly want a hard validation.
  static Future<void> validateTransaction({
    required Customer customer,
    required DebtTransaction candidate,
    required Transaction txn,
  }) async {
    final warning = await transactionWarning(
      customer: customer, candidate: candidate, db: txn,
    );
    if (warning != null) throw Exception(warning);
  }
}
