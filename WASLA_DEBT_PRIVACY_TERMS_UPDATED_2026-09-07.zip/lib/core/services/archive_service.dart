import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

class ArchiveService {
  static final TransactionRepository _transactionRepo = TransactionRepository();

  static Future<void> archiveTransaction({required int transactionId, String? userId, String? note}) async {
    final db = await _transactionRepo.appDatabase.database;
    await db.transaction((txn) async {
      final oldTransaction = await _transactionRepo.getTransactionByIdWithTxn(transactionId, txn);
      if (oldTransaction == null) throw Exception('المعاملة غير موجودة');
      if (oldTransaction.isArchived) throw Exception('المعاملة مؤرشفة بالفعل');
      final changed = await _transactionRepo.archiveTransactionWithTxn(transactionId, txn);
      if (changed != 1) throw Exception('تعذر أرشفة المعاملة');
      await AuditService.logTransactionArchive(transactionId: transactionId, oldTransaction: oldTransaction, userId: userId, note: note, txn: txn);
    });
  }
}
