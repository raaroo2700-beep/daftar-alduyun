/// Consistent financial formatting: preserve up to two decimal places without
/// inventing whole-unit rounding in the UI or exported reports.
class MoneyFormat {
  static String amount(double value) {
    if (value.isNaN || value.isInfinite) return '0';
    final normalized = value.abs() < 0.0000001 ? 0 : value;
    final text = normalized.toStringAsFixed(2);
    return text.endsWith('.00')
        ? text.substring(0, text.length - 3)
        : text.endsWith('0')
            ? text.substring(0, text.length - 1)
            : text;
  }
}
