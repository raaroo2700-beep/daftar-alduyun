class MoneyValidator {
  static bool hasAtMostTwoDecimals(double value) {
    final scaled = value * 100;
    return (scaled - scaled.round()).abs() < 0.000001;
  }
}
