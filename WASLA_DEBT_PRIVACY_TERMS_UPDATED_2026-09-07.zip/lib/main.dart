import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app/theme/app_theme.dart';
import 'core/services/recurring_service.dart';
import 'core/services/backup_service.dart';
import 'core/services/activation_service.dart';
import 'features/settings/providers/settings_provider.dart';
import 'features/onboarding/onboarding_screen.dart';
import 'features/home/home_screen.dart';

void main() {
  runApp(
    const ProviderScope(
      child: MyApp(),
    ),
  );
}

// إصلاح 5.1: كانت MyApp عادية (StatelessWidget) وتستخدم دائمًا
// AppTheme.light() بلا أي شرط، فلا يُطبَّق مفتاح "الوضع الليلي" إطلاقًا
// رغم أنه يُحفَظ بنجاح في الإعدادات.
class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    return MaterialApp(
      title: 'دفتر الديون',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'SA'),
      supportedLocales: const [Locale('ar', 'SA')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: settings.darkMode ? ThemeMode.dark : ThemeMode.light,
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkOnboarding();
  }

  Future<void> _checkOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    final bool completed = prefs.getBool('onboarding_completed') ?? false;

    // إصلاح 3.1 (بند 3.3 في التقرير) و5.1: تنفيذ الجدولات المتكررة
    // المستحقة، والنسخ الاحتياطي التلقائي إن كان مفعّلاً، عند بدء التطبيق.
    // لا يوجد تنفيذ خلفي حقيقي (Flutter لا يعمل في الخلفية تلقائيًا دون
    // حزمة مثل workmanager)، لكن هذا يضمن تنفيذها على الأقل عند كل فتح.
    unawaited(RecurringService().processDueSchedules());
    unawaited(BackupService().runAutoBackupIfDue());
    unawaited(ActivationService.refreshStatusIfDue());

    if (!mounted) return;

    if (!completed) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const OnboardingScreen()),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}