
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/backup_service.dart';

class RestoreScreen extends StatefulWidget {
  const RestoreScreen({super.key});

  @override
  State<RestoreScreen> createState() => _RestoreScreenState();
}

class _RestoreScreenState extends State<RestoreScreen> {
  bool _isLoading = false;
  String? _message;

  Future<void> _restoreBackup() async {
    try {
      // اختيار الملف
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['zip', 'json'],
      );
      if (result == null) return;

      setState(() {
        _isLoading = true;
        _message = null;
      });

      final filePath = result.files.single.path!;
      await BackupService().restoreBackup(filePath);

      setState(() {
        _message = '✅ تم استرجاع البيانات بنجاح! يرجى إعادة تشغيل التطبيق.';
      });
    } catch (e) {
      setState(() {
        _message = '❌ تعذر استرجاع النسخة الاحتياطية. تأكد من أن الملف صحيح ثم حاول مرة أخرى.';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('استرجاع البيانات')),
      body: Stack(
        children: [
          Padding(
        padding: const EdgeInsets.all(AppDimensions.paddingLarge),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.restore, size: 80, color: AppColors.primary),
            const SizedBox(height: 20),
            const Text(
              'استرجاع البيانات',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'اختر ملف ZIP لاسترجاع البيانات والمرفقات. سيتم إنشاء نسخة أمان من الحالة الحالية قبل الاسترجاع (ويدعم JSON القديم)',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.hint),
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _restoreBackup,
              icon: _isLoading
                  ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
                  : const Icon(Icons.upload_file),
              label: Text(_isLoading ? 'جاري الاسترجاع...' : 'اختيار ملف'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(
                  horizontal: 40,
                  vertical: 16,
                ),
              ),
            ),
            const SizedBox(height: 20),
            if (_message != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _message!.startsWith('✅')
                      ? Colors.green.shade50
                      : Colors.red.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: _message!.startsWith('✅')
                        ? Colors.green
                        : Colors.red,
                  ),
                ),
                child: Text(
                  _message!,
                  style: TextStyle(
                    color: _message!.startsWith('✅')
                        ? Colors.green.shade900
                        : Colors.red.shade900,
                  ),
                ),
              ),
          ],
          ),
        ),
          if (_isLoading)
            Positioned.fill(
              child: AbsorbPointer(
                absorbing: true,
                child: ColoredBox(
                  color: Color(0x66000000),
                  child: Center(
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const CircularProgressIndicator(),
                            const SizedBox(height: 16),
                            Text(_isLoading ? 'جاري تنفيذ العملية، يرجى الانتظار...' : ''),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}