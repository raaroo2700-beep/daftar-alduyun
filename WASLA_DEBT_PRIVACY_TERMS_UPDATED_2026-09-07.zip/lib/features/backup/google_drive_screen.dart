import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/backup_service.dart';
import 'package:wasla_debt/core/services/google_drive_service.dart';

class GoogleDriveScreen extends StatefulWidget {
  const GoogleDriveScreen({super.key});

  @override
  State<GoogleDriveScreen> createState() => _GoogleDriveScreenState();
}

class _GoogleDriveScreenState extends State<GoogleDriveScreen> {
  bool _isLoading = false;
  GoogleSignInAccount? _currentUser;
  List<Map<String, dynamic>> _backups = [];
  bool _isSignedIn = false;

  @override
  void initState() {
    super.initState();
    _checkSignInStatus();
  }

  Future<void> _checkSignInStatus() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      _isSignedIn = GoogleDriveService.isSignedIn;
      _currentUser = GoogleDriveService.currentUser;
      if (_isSignedIn) await _loadBackups();
    } catch (_) {
      if (!mounted) return;
      _showMessage('تعذر التحقق من حساب Google.', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _signIn() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      final account = await GoogleDriveService.signIn();
      if (!mounted) return;
      if (account != null) {
        setState(() {
          _currentUser = account;
          _isSignedIn = true;
        });
        await _loadBackups();
        if (!mounted) return;
        _showMessage('تم تسجيل الدخول بنجاح');
      }
    } catch (_) {
      if (!mounted) return;
      _showMessage(
        'فشل تسجيل الدخول. تحقق من اتصال الإنترنت وحاول مرة أخرى.',
        isError: true,
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _signOut() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      await GoogleDriveService.signOut();
      if (!mounted) return;
      setState(() {
        _currentUser = null;
        _isSignedIn = false;
        _backups = [];
      });
      _showMessage('تم تسجيل الخروج');
    } catch (_) {
      if (!mounted) return;
      _showMessage('فشل تسجيل الخروج. حاول مرة أخرى.', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _loadBackups() async {
    try {
      final files = await GoogleDriveService.listBackups();
      if (!mounted) return;
      setState(() => _backups = files);
    } catch (_) {
      if (!mounted) return;
      _showMessage(
        'تعذر جلب النسخ الاحتياطية. تحقق من الاتصال والصلاحيات.',
        isError: true,
      );
    }
  }

  Future<void> _uploadBackup() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      final backupPath = await BackupService().createBackup();
      final fileName =
          'wasla_backup_${DateTime.now().millisecondsSinceEpoch}.zip';
      await GoogleDriveService.uploadFile(
        localFilePath: backupPath,
        fileName: fileName,
      );
      if (!mounted) return;
      _showMessage('تم رفع النسخة الاحتياطية بنجاح');
      await _loadBackups();
    } catch (_) {
      if (!mounted) return;
      _showMessage(
        'فشل رفع النسخة. تحقق من الاتصال ومساحة Drive.',
        isError: true,
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _restoreBackup(String fileId, String fileName) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('استعادة النسخة؟'),
        content: Text(
          'سيتم استبدال بيانات التطبيق ببيانات «$fileName». '
          'سيتم إنشاء نسخة أمان من الحالة الحالية أولًا.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('استعادة'),
          ),
        ],
      ),
    );
    if (!mounted || confirmed != true) return;

    setState(() => _isLoading = true);
    try {
      final localPath = await GoogleDriveService.downloadFile(fileId);
      await BackupService().restoreBackup(localPath);
      if (!mounted) return;
      _showMessage('تم استرجاع البيانات بنجاح! يرجى إعادة تشغيل التطبيق.');
    } catch (_) {
      if (!mounted) return;
      _showMessage(
        'فشل استرجاع النسخة. تأكد من سلامة الملف وحاول مرة أخرى.',
        isError: true,
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _deleteBackup(String fileId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: const Text('هل أنت متأكد من حذف هذه النسخة؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (!mounted || confirmed != true) return;

    try {
      await GoogleDriveService.deleteFile(fileId);
      if (!mounted) return;
      await _loadBackups();
      if (!mounted) return;
      _showMessage('تم حذف النسخة الاحتياطية');
    } catch (_) {
      if (!mounted) return;
      _showMessage('فشل حذف النسخة الاحتياطية. حاول مرة أخرى.', isError: true);
    }
  }

  void _showMessage(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? AppColors.debit : AppColors.secondary,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Google Drive')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(AppDimensions.paddingMedium),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'حساب Google',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          if (_isSignedIn && _currentUser != null)
                            Text(
                              'تم تسجيل الدخول: ${_currentUser!.displayName ?? _currentUser!.email}',
                            )
                          else
                            const Text('غير مسجل دخول'),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              if (!_isSignedIn)
                                ElevatedButton(
                                  onPressed: _signIn,
                                  child: const Text('تسجيل الدخول'),
                                )
                              else ...[
                                ElevatedButton(
                                  onPressed: _signOut,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.debit,
                                  ),
                                  child: const Text('تسجيل الخروج'),
                                ),
                                ElevatedButton(
                                  onPressed: () async {
                                    await _signOut();
                                    if (!mounted) return;
                                    await _signIn();
                                  },
                                  child: const Text('تغيير الحساب'),
                                ),
                                ElevatedButton.icon(
                                  onPressed: _uploadBackup,
                                  icon: const Icon(Icons.upload),
                                  label: const Text('رفع نسخة'),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (_isSignedIn) ...[
                    const SizedBox(height: 12),
                    Expanded(
                      child: _backups.isEmpty
                          ? const Center(child: Text('لا توجد نسخ احتياطية'))
                          : ListView.builder(
                              itemCount: _backups.length,
                              itemBuilder: (context, index) {
                                final file = _backups[index];
                                final id = file['id']?.toString();
                                final name =
                                    file['name']?.toString() ?? 'بدون اسم';
                                return Card(
                                  margin: const EdgeInsets.symmetric(vertical: 4),
                                  child: ListTile(
                                    leading: const Icon(
                                      Icons.backup,
                                      color: AppColors.primary,
                                    ),
                                    title: Text(name),
                                    subtitle: Text(
                                      file['createdTime'] != null
                                          ? 'تاريخ: ${DateTime.parse(file['createdTime'].toString()).toLocal()}'
                                          : 'تاريخ غير معروف',
                                    ),
                                    trailing: id == null
                                        ? null
                                        : Wrap(
                                            spacing: 0,
                                            children: [
                                              IconButton(
                                                tooltip: 'استعادة النسخة',
                                                icon: const Icon(
                                                  Icons.download,
                                                  color: AppColors.primary,
                                                ),
                                                onPressed: () =>
                                                    _restoreBackup(id, name),
                                              ),
                                              IconButton(
                                                tooltip: 'حذف النسخة',
                                                icon: const Icon(
                                                  Icons.delete,
                                                  color: AppColors.debit,
                                                ),
                                                onPressed: () =>
                                                    _deleteBackup(id),
                                              ),
                                            ],
                                          ),
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}
