import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/activation_service.dart';
import 'package:wasla_debt/features/help/user_guide_screen.dart';
import 'package:wasla_debt/features/legal/privacy_policy_screen.dart';
import 'package:wasla_debt/features/legal/terms_of_service_screen.dart';

/// إصلاح 8.2: كان هذا الملف فارغًا تمامًا (0 بايت)، والعنصر "حول البرنامج"
/// في القائمة الجانبية كان يعرض رسالة "قيد التطوير" فقط بدل شاشة حقيقية.
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حول البرنامج')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppDimensions.paddingLarge),
          children: [
            const Center(
              child: CircleAvatar(
                radius: 40,
                backgroundColor: AppColors.primary,
                child: Icon(Icons.menu_book, size: 40, color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            const Center(
              child: Text(
                'دفتر الديون',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'تطبيق "دفتر الديون" يساعدك على تسجيل ديونك ومستحقاتك مع '
              'العملاء بسهولة، مع دعم عدة عملات، وتصدير كشوف الحساب، '
              'والنسخ الاحتياطي والاسترجاع.',
              style: TextStyle(fontSize: 15, height: 1.6),
            ),
            const SizedBox(height: 24),
            FutureBuilder(
              future: ActivationService.isPremium(),
              builder: (context, snapshot) {
                final isActive = snapshot.data ?? false;
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    isActive ? Icons.verified : Icons.info_outline,
                    color: isActive ? Colors.green : AppColors.hint,
                  ),
                  title: Text(isActive ? 'النسخة مفعّلة' : 'النسخة المجانية'),
                );
              },
            ),
            const Divider(height: 32),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.menu_book_outlined),
              title: const Text('دليل استخدام البرنامج'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const UserGuideScreen()),
                );
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('سياسة الخصوصية'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen()),
                );
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.description_outlined),
              title: const Text('شروط الاستخدام'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const TermsOfServiceScreen()),
                );
              },
            ),
            const Divider(height: 32),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.email_outlined),
              title: Text('support@wasla.com'),
            ),
          ],
        ),
      ),
    );
  }
}
