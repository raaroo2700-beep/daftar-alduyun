import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';

class TermsOfServiceScreen extends StatelessWidget {
  const TermsOfServiceScreen({super.key});

  static const String _lastUpdated = '2026-09-07';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('شروط الاستخدام')),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingLarge),
        children: const [
          Text(
            'شروط استخدام تطبيق دفتر الديون',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 4),
          Text(
            'آخر تحديث: $_lastUpdated',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          SizedBox(height: 20),
          _TermsSection(
            title: '١. استخدام التطبيق',
            body:
                'يوفر دفتر الديون أدوات لإدارة العملاء والديون والمعاملات والمدفوعات والأرصدة والنسخ الاحتياطية. استخدام التطبيق مخصص للأغراض المشروعة ولإدارة سجلاتك التي تملك حق استخدامها.',
          ),
          _TermsSection(
            title: '٢. مسؤولية البيانات',
            body:
                'أنت مسؤول عن صحة البيانات التي تدخلها في التطبيق، بما في ذلك أسماء العملاء وأرقام الهواتف والمبالغ والمدفوعات والملاحظات والمرفقات، وعن مراجعة السجلات قبل الاعتماد عليها.',
          ),
          _TermsSection(
            title: '٣. النسخ الاحتياطي والاستعادة',
            body:
                'يوفر التطبيق وظائف للنسخ الاحتياطي والاستعادة محليًا وعبر Google Drive وفق الإصدار الحالي. يُنصح بالاحتفاظ بنسخ احتياطية منتظمة. قبل الاستعادة، يجب التأكد من أن النسخة المختارة هي النسخة المطلوبة لأن الاستعادة قد تغيّر البيانات المحلية.',
          ),
          _TermsSection(
            title: '٤. Google Drive',
            body:
                'عند استخدام Google Drive، تختار حساب Google الخاص بك وتمنح التطبيق الصلاحية المطلوبة. يستخدم التطبيق صلاحية drive.file لتنفيذ وظائف النسخ الاحتياطي التي ينشئها. أنت مسؤول عن اختيار الحساب الصحيح وحماية حساب Google الخاص بك.',
          ),
          _TermsSection(
            title: '٥. خدمات الطرف الثالث',
            body:
                'تعتمد بعض الوظائف على خدمات خارجية، ومنها Google Sign-In وGoogle Drive. قد تتأثر هذه الوظائف بتوفر الخدمات الخارجية أو تغييراتها أو انقطاع الإنترنت.',
          ),
          _TermsSection(
            title: '٦. حماية الحساب والجهاز',
            body:
                'أنت مسؤول عن حماية جهازك وحساباتك وكلمات المرور ووسائل المصادقة الخاصة بك. لا تشارك بيانات الدخول إلى حساب Google مع أي شخص.',
          ),
          _TermsSection(
            title: '٧. توفر الخدمة',
            body:
                'نبذل جهدًا للحفاظ على عمل التطبيق، ولكن لا نضمن توفر جميع الوظائف دون انقطاع أو خلوها من الأعطال في جميع الأجهزة والظروف الشبكية.',
          ),
          _TermsSection(
            title: '٨. التحديثات',
            body:
                'قد يتم تحديث التطبيق أو تعديل وظائفه لتحسين الأمان والأداء وإضافة ميزات جديدة أو التوافق مع خدمات الطرف الثالث.',
          ),
          _TermsSection(
            title: '٩. التواصل',
            body:
                'للاستفسارات المتعلقة بالتطبيق أو هذه الشروط، استخدم عنوان التواصل الرسمي المنشور في صفحة التطبيق وفي إعدادات/معلومات التطبيق.',
          ),
          _TermsSection(
            title: '١٠. القبول',
            body:
                'باستخدام التطبيق، تقر بأنك قرأت هذه الشروط وفهمتها وتوافق على استخدامها ضمن الحدود الموضحة فيها.',
          ),
        ],
      ),
    );
  }
}

class _TermsSection extends StatelessWidget {
  final String title;
  final String body;

  const _TermsSection({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const SizedBox(height: 6),
          Text(body, style: const TextStyle(height: 1.6)),
        ],
      ),
    );
  }
}
