import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';

/// سياسة الخصوصية لتطبيق دفتر الديون.
/// يجب نشر نسخة الويب من هذا المحتوى على رابط عام قبل إدخاله في Google Cloud.
class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  static const String _lastUpdated = '2026-09-07';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سياسة الخصوصية')),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingLarge),
        children: const [
          Text(
            'سياسة الخصوصية — تطبيق دفتر الديون',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 4),
          Text(
            'آخر تحديث: $_lastUpdated',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          SizedBox(height: 20),
          _PolicySection(
            title: '١. نطاق هذه السياسة',
            body:
                'توضح هذه السياسة كيفية تعامل تطبيق "دفتر الديون" مع البيانات عند استخدامه لإدارة العملاء والديون والمعاملات والمدفوعات والنسخ الاحتياطية. هذه السياسة تصف السلوك الحالي للتطبيق، وقد يتم تحديثها عند إضافة وظائف جديدة.',
          ),
          _PolicySection(
            title: '٢. البيانات التي يخزّنها التطبيق',
            body:
                'يمكن للتطبيق تخزين بيانات العملاء والمعاملات والمرفقات التي تدخلها بنفسك، مثل الأسماء وأرقام الهواتف والمبالغ والملاحظات وصور الفواتير. تُخزّن هذه البيانات محليًا داخل قاعدة بيانات التطبيق على جهازك. لا تُرسل هذه البيانات إلى خادم خاص بنا كجزء من وظائف إدارة دفتر الديون المحلية.',
          ),
          _PolicySection(
            title: '٣. النسخ الاحتياطي المحلي',
            body:
                'يمكنك إنشاء نسخة احتياطية محلية من بيانات التطبيق وحفظها في الموقع الذي تختاره على جهازك. تبقى هذه النسخة تحت سيطرتك، وأنت مسؤول عن المكان الذي تحفظها فيه وعن الاحتفاظ بنسخة آمنة منها.',
          ),
          _PolicySection(
            title: '٤. تسجيل الدخول إلى Google',
            body:
                'عند استخدام النسخ الاحتياطي على Google Drive، يتيح لك التطبيق تسجيل الدخول من خلال خدمة Google الرسمية واختيار حساب Google الذي تريد استخدامه. لا يطلب التطبيق منك إدخال كلمة مرور Google داخل التطبيق. قد يعرض التطبيق اسم الحساب أو عنوان بريده الإلكتروني لتوضيح الحساب المتصل أثناء جلسة Google Drive.',
          ),
          _PolicySection(
            title: '٥. Google Drive والنسخ الاحتياطية',
            body:
                'عند اختيارك Google Drive، ينشئ التطبيق نسخة احتياطية من بيانات التطبيق ويرفعها إلى مساحة Google Drive المرتبطة بحساب Google الذي اخترته. كما يوفر التطبيق وظائف عرض النسخ الاحتياطية وتنزيلها واستعادتها وحذفها. يجب عليك التأكد من اختيار حساب Google الصحيح قبل رفع النسخة أو استعادتها.',
          ),
          _PolicySection(
            title: '٦. صلاحية Google Drive',
            body:
                'يطلب التطبيق صلاحية Google Drive المحدودة drive.file. تُستخدم هذه الصلاحية لتنفيذ وظائف النسخ الاحتياطي التي ينشئها التطبيق، بدل طلب صلاحية الوصول الكامل إلى محتويات Google Drive. لا يطلب التطبيق صلاحية عامة لقراءة جميع ملفات Drive.',
          ),
          _PolicySection(
            title: '٧. بيانات Google',
            body:
                'يستخدم التطبيق معلومات حساب Google اللازمة لإتمام جلسة تسجيل الدخول واستخدام Google Drive، مثل الحساب الحالي ورمز الوصول الذي توفره مكتبة Google Sign-In. تُستخدم هذه المعلومات لتنفيذ عملية المصادقة وطلبات Drive ولا تُستخدم لبناء ملف إعلاني عن المستخدم.',
          ),
          _PolicySection(
            title: '٨. عدم وجود إعلانات أو تتبّع',
            body:
                'لا يعرض التطبيق إعلانات، ولا يشارك بيانات المستخدم مع شركات إعلانية أو خدمات تحليلية لأغراض إعلانية وفق الوظائف الحالية للتطبيق.',
          ),
          _PolicySection(
            title: '٩. التفعيل ومعرّف الجهاز',
            body:
                'لإدارة التفعيل، ينشئ التطبيق معرّفًا للجهاز ويرسله إلى خادم التفعيل للتحقق من صلاحية رمز التفعيل. يُستخدم هذا المعرّف لغرض إدارة الترخيص وفق وظيفة التفعيل الحالية للتطبيق.',
          ),
          _PolicySection(
            title: '١٠. مشاركة البيانات وخدمات الطرف الثالث',
            body:
                'لا نبيع بيانات المستخدم. عند استخدام Google Sign-In وGoogle Drive، يتواصل التطبيق مع خدمات Google اللازمة لتنفيذ المصادقة والنسخ الاحتياطي وفق الصلاحيات التي يمنحها المستخدم. تخضع خدمات Google كذلك لسياسة الخصوصية وشروط Google.',
          ),
          _PolicySection(
            title: '١١. حذف البيانات والنسخ الاحتياطية',
            body:
                'يمكنك حذف البيانات التي يوفر التطبيق وظائف حذف لها. يؤدي إلغاء تثبيت التطبيق إلى إزالة البيانات المحلية التي يحتفظ بها التطبيق وفق آلية تخزين النظام. النسخ الاحتياطية المحلية أو المحفوظة في Google Drive قد تبقى بعد حذف البيانات المحلية، ولذلك يجب حذفها يدويًا إذا لم تعد بحاجة إليها. كما يمكنك إدارة وصول التطبيق إلى حساب Google من إعدادات حساب Google.',
          ),
          _PolicySection(
            title: '١٢. أمن البيانات',
            body:
                'نسعى إلى حماية بيانات التطبيق واستخدام أقل قدر مناسب من صلاحيات Google Drive. ومع ذلك، لا يمكن ضمان الأمان المطلق لأي جهاز أو خدمة أو اتصال عبر الإنترنت. يجب عليك حماية جهازك وحساب Google وملفات النسخ الاحتياطية.',
          ),
          _PolicySection(
            title: '١٣. تغييرات السياسة',
            body:
                'قد نحدّث سياسة الخصوصية عند تغيير وظائف التطبيق أو متطلبات الخدمات المستخدمة. سيتم تحديث تاريخ آخر تعديل عند نشر نسخة جديدة من السياسة.',
          ),
          _PolicySection(
            title: '١٤. التواصل',
            body:
                'للاستفسارات المتعلقة بالخصوصية أو بيانات المستخدم، استخدم عنوان التواصل الرسمي المنشور في صفحة التطبيق وفي إعدادات/معلومات التطبيق.',
          ),
          _PolicySection(
            title: '١٥. خدمات Google',
            body:
                'يمكنك مراجعة سياسة خصوصية Google على: https://policies.google.com/privacy',
          ),
        ],
      ),
    );
  }
}

class _PolicySection extends StatelessWidget {
  final String title;
  final String body;

  const _PolicySection({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const SizedBox(height: 6),
          Text(body, style: const TextStyle(height: 1.6)),
        ],
      ),
    );
  }
}
