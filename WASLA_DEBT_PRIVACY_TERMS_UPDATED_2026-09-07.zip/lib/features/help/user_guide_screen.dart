import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';

/// دليل استخدام شامل للتطبيق، قسم لكل ميزة موجودة فعليًا في التطبيق.
/// يظهر كقائمة أقسام قابلة للطي (Accordion) حتى تبقى الشاشة سهلة التصفح.
class UserGuideScreen extends StatelessWidget {
  const UserGuideScreen({super.key});

  static const List<_GuideSection> _sections = [
    _GuideSection(
      icon: Icons.home_outlined,
      title: 'الشاشة الرئيسية',
      body:
          'تعرض الشاشة الرئيسية قائمة عملائك مع رصيد كل واحد منهم. من '
          'الأعلى يمكنك التبديل بين تبويبات العملات (الكل / YER / SAR / '
          'USD) لعرض أرصدة عملة معينة فقط، مع بطاقتَي "إجمالي عليك" '
          '(ما يدين به العملاء لك) و"إجمالي لك" (ما تدين به لهم). اسحب '
          'الشاشة للأسفل لتحديث القائمة.',
    ),
    _GuideSection(
      icon: Icons.add_circle_outline,
      title: 'إضافة مبلغ (معاملة جديدة)',
      body:
          'اضغط أيقونة "+" أعلى الشاشة الرئيسية أو "إضافة مبلغ" من القائمة '
          'الجانبية. اكتب اسم العميل — إن كان الاسم موجودًا مسبقًا ستظهر '
          'اقتراحات تلقائية، وإن لم يكن موجودًا يظهر خيار "إضافة عميل جديد '
          'باسم ...". حدد المبلغ والعملة ونوع الحركة (له / عليه)، ثم احفظ. '
          'إن كان المبلغ سيتجاوز حد العميل المسموح لتلك العملة، يظهر تنبيه '
          'أصفر يتيح لك المتابعة أو الإلغاء.',
    ),
    _GuideSection(
      icon: Icons.person_outline,
      title: 'تفاصيل العميل والسدادات',
      body:
          'اضغط على أي عميل من القائمة الرئيسية لعرض كل معاملاته وسداداته '
          'لكل عملة يتعامل بها. من هذه الشاشة يمكنك: إضافة سداد جديد '
          '(دفع لي / دفعت له)، تعديل أو حذف أي معاملة أو سداد سابق، '
          'أرشفة العميل، أو فتح "تحويل بين العملاء" مباشرة وهذا العميل '
          'محددًا كمصدر للتحويل.',
    ),
    _GuideSection(
      icon: Icons.swap_horiz,
      title: 'التحويل بين العملاء',
      body:
          'من القائمة الجانبية اختر "تحويل بين العملاء" لنقل مبلغ من رصيد '
          'عميل إلى آخر بنفس العملة. إن كان رصيد العميل المصدر غير كافٍ '
          'يظهر تنبيه أصفر يتيح لك تجاوزه أو الإلغاء.',
    ),
    _GuideSection(
      icon: Icons.archive_outlined,
      title: 'العملاء المؤرشفون',
      body:
          'العملاء الذين تؤرشفهم لا يظهرون في الشاشة الرئيسية لكن بياناتهم '
          'تبقى محفوظة. من "العملاء المؤرشفون" بالقائمة الجانبية يمكنك '
          'استعراضهم أو حذفهم نهائيًا (الحذف النهائي لا يمكن التراجع عنه).',
    ),
    _GuideSection(
      icon: Icons.receipt_long,
      title: 'التقارير',
      body:
          'من "التقارير" بالقائمة الجانبية تجد عدة تقارير: التقرير الشهري '
          '(إجمالي كل شهر لكل عملة)، إجمالي المبالغ لكل عميل، حركة الحساب '
          'التفصيلية، تصنيف المبالغ (له / عليه)، وتفاصيل المبالغ. كل تقرير '
          'فيه زرا تصدير كـ PDF أو Excel، ويمكنك مشاركة الملف الناتج '
          'مباشرة (واتساب، بريد، إلخ) بعد إنشائه.',
    ),
    _GuideSection(
      icon: Icons.backup,
      title: 'النسخ الاحتياطي المحلي',
      body:
          'من "حفظ نسخة احتياطية" بالقائمة الجانبية تُنشأ نسخة ZIP كاملة '
          'من بياناتك ومرفقاتك وإعداداتك على جهازك. من الإعدادات يمكنك: '
          'تحديد مجلد مخصص لحفظ النسخ بدل المجلد الافتراضي داخل التطبيق، '
          'تفعيل "نسخ احتياطي تلقائي" وتحديد الوقت اليومي الذي تفضله '
          '(يُنشأ عند أول فتح للتطبيق بعد ذلك الوقت)، وتحديد الحد الأقصى '
          'لعدد النسخ المحفوظة قبل حذف الأقدم تلقائيًا.',
    ),
    _GuideSection(
      icon: Icons.restore,
      title: 'استرجاع البيانات',
      body:
          'من "استرجاع قاعدة البيانات" بالقائمة الجانبية اختر ملف النسخة '
          'الاحتياطية (ZIP أو JSON قديم) من جهازك، وسيستبدل التطبيق '
          'بياناته الحالية بمحتوى تلك النسخة. يُنصح بإعادة تشغيل التطبيق '
          'بعد الاسترجاع.',
    ),
    _GuideSection(
      icon: Icons.cloud_upload_outlined,
      title: 'النسخ الاحتياطي على Google Drive',
      body:
          'من "Google Drive" بالقائمة الجانبية أو الإعدادات، سجّل الدخول '
          'بحساب Google الخاص بك لرفع نسخك الاحتياطية إلى مساحتك الشخصية '
          'على Drive، أو تنزيل نسخة سابقة، أو حذف نسخ قديمة من هناك. '
          'ملف النسخة يبقى داخل حسابك أنت فقط ولا يصل إلى أي طرف آخر.',
    ),
    _GuideSection(
      icon: Icons.settings_outlined,
      title: 'الإعدادات',
      body:
          'من "الإعدادات" يمكنك: اختيار العملة الافتراضية، إظهار/إخفاء '
          'الوقت في العمليات، تفعيل الوضع الليلي، ضبط عدد النسخ '
          'الاحتياطية المحفوظة ومجلدها، ضبط وقت النسخ التلقائي، ومتابعة '
          'حالة اشتراكك (مفعّل / غير مفعّل) وإدارة الدخول إلى Google Drive.',
    ),
    _GuideSection(
      icon: Icons.verified_user_outlined,
      title: 'التفعيل والاشتراك',
      body:
          'النسخة المجانية تسمح بحتى 30 عميلًا. عند الوصول لهذا الحد '
          'تظهر شاشة التفعيل، وفيها معرّف فريد لجهازك (يمكن نسخه بضغطة '
          'واحدة) يجب إرساله للدعم للحصول على رمز تفعيل خاص بهذا الجهاز. '
          'يمكنك التواصل مباشرة من نفس الشاشة عبر أحد رقمَي واتساب أو '
          'البريد الإلكتروني، ثم إدخال الرمز الذي تستلمه لتفعيل البرنامج.',
    ),
    _GuideSection(
      icon: Icons.share_outlined,
      title: 'مشاركة التطبيق',
      body:
          'من "مشاركة التطبيق" بالقائمة الجانبية يمكنك إرسال رسالة تعريفية '
          'بالتطبيق لأصدقائك عبر أي تطبيق مثبت على جهازك (واتساب، رسائل، '
          'بريد، إلخ).',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دليل استخدام البرنامج')),
      body: ListView.separated(
        padding: const EdgeInsets.all(AppDimensions.paddingMedium),
        itemCount: _sections.length,
        separatorBuilder: (_, _) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final section = _sections[index];
          return Card(
            clipBehavior: Clip.antiAlias,
            child: ExpansionTile(
              leading: Icon(section.icon, color: AppColors.primary),
              title: Text(
                section.title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(section.body, style: const TextStyle(height: 1.6)),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _GuideSection {
  final IconData icon;
  final String title;
  final String body;
  const _GuideSection({
    required this.icon,
    required this.title,
    required this.body,
  });
}
