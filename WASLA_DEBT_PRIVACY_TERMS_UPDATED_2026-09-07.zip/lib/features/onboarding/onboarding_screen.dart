import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/features/onboarding/onboarding_page.dart';
import 'package:wasla_debt/features/home/home_screen.dart';
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
final PageController _pageController = PageController();
int _currentPage = 0;

final List<Map<String, String>> _pages = [
{
'title': 'مرحباً في دفتر الديون',
'description': 'ساعد نفسك على حفظ ومتابعة ديونك بسهولة',
'image': 'assets/images/onboarding1.png',
},
{
'title': 'له وعليه',
'description': 'سجل من لك ومن عليك، مع تفاصيل كل عملية',
'image': 'assets/images/onboarding2.png',
},
{
'title': 'تقارير ونسخ احتياطية',
'description': 'احصل على تقارير مفصلة ونسخ احتياطية لبياناتك',
'image': 'assets/images/onboarding3.png',
},
];

void _goToNext() {
if (_currentPage < _pages.length - 1) {
_pageController.nextPage(
duration: const Duration(milliseconds: 300),
curve: Curves.easeInOut,
);
} else {
_completeOnboarding();
}
}

Future<void> _completeOnboarding() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool('onboarding_completed', true);
  if (mounted) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => const HomeScreen(),
      ),
    );
  }
}

@override
Widget build(BuildContext context) {
return Scaffold(
body: SafeArea(
child: Column(
children: [
Expanded(
child: PageView.builder(
controller: _pageController,
itemCount: _pages.length,
onPageChanged: (index) {
setState(() {
_currentPage = index;
});
},
itemBuilder: (context, index) {
final page = _pages[index];
return OnboardingPage(
title: page['title']!,
description: page['description']!,
image: page['image']!,
isLast: index == _pages.length - 1,
);
},
),
),
Padding(
padding: const EdgeInsets.all(AppDimensions.paddingLarge),
child: Row(
mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Row(
children: List.generate(
_pages.length,
(index) => Container(
margin: const EdgeInsets.symmetric(horizontal: 4),
width: _currentPage == index ? 24 : 8,
height: 8,
decoration: BoxDecoration(
color: _currentPage == index
? AppColors.primary
: AppColors.divider,
borderRadius: BorderRadius.circular(4),
),
),
),
),
ElevatedButton(
onPressed: _goToNext,
style: ElevatedButton.styleFrom(
backgroundColor: AppColors.primary,
foregroundColor: Colors.white,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(
      AppDimensions.radiusMedium,
    ),
  ),
  padding: const EdgeInsets.symmetric(
    horizontal: AppDimensions.paddingLarge,
    vertical: AppDimensions.paddingMedium,
  ),
),
  child: Text(
    _currentPage == _pages.length - 1
        ? 'ابدأ الآن'
        : 'التالي',
    style: const TextStyle(fontSize: 16),
  ),
),
],
),
),
],
),
),
);
}
}