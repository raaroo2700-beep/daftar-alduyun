import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';

class OnboardingPage extends StatelessWidget {
  final String title;
  final String description;
  final String image; // سنستخدم أيقونات مؤقتاً بدلاً من الصور
  final bool isLast;

  const OnboardingPage({
    super.key,
    required this.title,
    required this.description,
    required this.image,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(AppDimensions.paddingLarge),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // أيقونة مؤقتة (بدلاً من الصورة)
          Icon(
            _getIconForImage(image),
            size: 120,
            color: AppColors.primary,
          ),
          const SizedBox(height: 40),
          Text(
            title,
            style: const TextStyle(
              fontSize: AppDimensions.fontSizeExtraLarge,
              fontWeight: FontWeight.bold,
              color: AppColors.text,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Text(
            description,
            style: const TextStyle(
              fontSize: AppDimensions.fontSizeMedium,
              color: AppColors.hint,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  IconData _getIconForImage(String image) {
    switch (image) {
      case 'assets/images/onboarding1.png':
        return Icons.account_balance_wallet;
      case 'assets/images/onboarding2.png':
        return Icons.swap_horiz;
      case 'assets/images/onboarding3.png':
        return Icons.analytics;
      default:
        return Icons.star;
    }
  }
}