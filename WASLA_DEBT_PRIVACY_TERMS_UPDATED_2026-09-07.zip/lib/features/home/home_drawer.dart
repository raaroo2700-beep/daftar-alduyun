import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/features/about/about_screen.dart';
import 'package:wasla_debt/features/customers/archived_customers_screen.dart';
import 'package:wasla_debt/features/help/user_guide_screen.dart';
import 'package:wasla_debt/features/legal/privacy_policy_screen.dart';
import 'package:wasla_debt/features/reports/reports_main_screen.dart';
import 'package:wasla_debt/features/transactions/add_transaction_screen.dart';
import 'package:wasla_debt/features/transactions/transfer_transaction_screen.dart';
import 'package:wasla_debt/features/backup/backup_screen.dart';
import 'package:wasla_debt/features/backup/restore_screen.dart';
import 'package:wasla_debt/features/backup/google_drive_screen.dart';
import 'package:wasla_debt/features/settings/settings_screen.dart';
import 'package:wasla_debt/features/transactions/recurring_schedules_screen.dart';
class HomeDrawer extends StatelessWidget {
  const HomeDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: AppColors.primary),
            child: Center(
              child: Text(
                'دفتر الديون',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
          ),
          _DrawerItem(
            icon: Icons.add_circle_outline,
            title: 'إضافة مبلغ',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.archive_outlined,
            title: 'العملاء المؤرشفون',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ArchivedCustomersScreen()));
            },
          ),
          _DrawerItem(
            icon: Icons.swap_horiz,
            title: 'تحويل بين العملاء',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const TransferTransactionScreen()));
            },
          ),
          _DrawerItem(
            icon: Icons.repeat,
            title: 'الجدولات المتكررة',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const RecurringSchedulesScreen()));
            },
          ),
          _DrawerItem(
            icon: Icons.receipt_long,
            title: 'التقارير',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ReportsMainScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.backup,
            title: 'حفظ نسخة احتياطية',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const BackupScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.restore,
            title: 'استرجاع قاعدة البيانات',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RestoreScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.cloud_upload,
            title: 'Google Drive',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const GoogleDriveScreen()),
              );
            },
          ),
          const Divider(),
          _DrawerItem(
            icon: Icons.settings,
            title: 'الإعدادات',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.menu_book_outlined,
            title: 'دليل استخدام البرنامج',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const UserGuideScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.info_outline,
            title: 'حول البرنامج',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AboutScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.privacy_tip_outlined,
            title: 'سياسة الخصوصية',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen()),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.share,
            title: 'مشاركة التطبيق',
            onTap: () {
              Navigator.pop(context);
              SharePlus.instance.share(
                ShareParams(
                  text:
                      'جرّب تطبيق "دفتر الديون" لتسجيل ديونك ومستحقاتك بسهولة!',
                ),
              );
            },
          ),
          _DrawerItem(
            icon: Icons.exit_to_app,
            title: 'خروج',
            onTap: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _DrawerItem({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary),
      title: Text(title),
      onTap: onTap,
    );
  }
}