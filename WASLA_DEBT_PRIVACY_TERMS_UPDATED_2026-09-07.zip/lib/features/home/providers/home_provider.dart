import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/payment_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

enum SortOption { newest, oldest, highest, lowest }
enum FilterType { all, credit, debit }
enum FilterCurrency { all, yer, sar, usd }
enum CustomerStatusFilter { all, active, settled }

const _StateUnset _unset = _StateUnset();
class _StateUnset { const _StateUnset(); }

class HomeState {
  final List<Customer> customers;
  final List<DebtTransaction> allTransactions;
  final List<Payment> allPayments;
  final bool isLoading;
  final String? error;
  final String searchQuery;
  final SortOption sortOption;
  final FilterType filterType;
  final FilterCurrency filterCurrency;
  final CustomerStatusFilter statusFilter;

  HomeState({this.customers=const[],this.allTransactions=const[],this.allPayments=const[],this.isLoading=false,this.error,this.searchQuery='',this.sortOption=SortOption.newest,this.filterType=FilterType.all,this.filterCurrency=FilterCurrency.all,this.statusFilter=CustomerStatusFilter.all});
  HomeState copyWith({List<Customer>? customers,List<DebtTransaction>? allTransactions,List<Payment>? allPayments,bool? isLoading,Object? error = _unset,String? searchQuery,SortOption? sortOption,FilterType? filterType,FilterCurrency? filterCurrency,CustomerStatusFilter? statusFilter})=>HomeState(customers:customers??this.customers,allTransactions:allTransactions??this.allTransactions,allPayments:allPayments??this.allPayments,isLoading:isLoading??this.isLoading,error:identical(error,_unset)?this.error:error as String?,searchQuery:searchQuery??this.searchQuery,sortOption:sortOption??this.sortOption,filterType:filterType??this.filterType,filterCurrency:filterCurrency??this.filterCurrency,statusFilter:statusFilter??this.statusFilter);

  Map<Currency,BalanceResult> _balanceFor(int id) => BalanceCalculator.calculateClientBalance(transactions: allTransactions.where((t)=>t.customerId==id).toList(),payments: allPayments.where((p)=>p.customerId==id).toList());
  List<Customer> get filteredCustomers {
    var result=customers.where((customer){
      final q=searchQuery.trim().toLowerCase();
      if(q.isNotEmpty && !customer.name.toLowerCase().contains(q) && !(customer.phone?.toLowerCase().contains(q)??false) && !allTransactions.any((t)=>t.customerId==customer.id && (t.details?.toLowerCase().contains(q)??false))) return false;
      final balances=_balanceFor(customer.id!);
      if(statusFilter==CustomerStatusFilter.active && !balances.values.any((b)=>!b.isZero)) return false;
      if(statusFilter==CustomerStatusFilter.settled && balances.values.any((b)=>!b.isZero)) return false;
      if(filterType!=FilterType.all){
        final target=filterType==FilterType.credit?DebtType.credit:DebtType.debit;
        if(!_balanceFor(customer.id!).values.any((b)=>target==DebtType.debit?b.isDebtor:b.isCreditor)) return false;
      }
      if(filterCurrency!=FilterCurrency.all){
        final c=_mapFilterCurrency(filterCurrency); if(!balances.containsKey(c)) return false;
        final b=balances[c]!; if(b.isZero) return false;
      }
      return true;
    }).toList();
    result.sort((a,b){
      final at=allTransactions.where((t)=>t.customerId==a.id).toList(); final bt=allTransactions.where((t)=>t.customerId==b.id).toList();
      switch(sortOption){
        case SortOption.newest: return (bt.isEmpty?0:bt.map((t)=>t.date).reduce((x,y)=>x>y?x:y)).compareTo(at.isEmpty?0:at.map((t)=>t.date).reduce((x,y)=>x>y?x:y));
        case SortOption.oldest: return (at.isEmpty?0:at.map((t)=>t.date).reduce((x,y)=>x<y?x:y)).compareTo(bt.isEmpty?0:bt.map((t)=>t.date).reduce((x,y)=>x<y?x:y));
        case SortOption.highest: return _total(a.id!).compareTo(_total(b.id!))*-1;
        case SortOption.lowest: return _total(a.id!).compareTo(_total(b.id!));
      }
    });
    return result;
  }
  double _total(int id)=>_balanceFor(id).values.fold(0.0,(sum,b)=>sum+b.balance.abs());
  Map<Currency,BalanceResult> get globalTotals=>BalanceCalculator.calculateTotalBalance(transactions:allTransactions,payments:allPayments);
  Map<Currency,BalanceResult> getCustomerBalanceSync(int id) => _balanceFor(id);
  Currency _mapFilterCurrency(FilterCurrency f)=>switch(f){FilterCurrency.yer=>Currency.yer,FilterCurrency.sar=>Currency.sar,FilterCurrency.usd=>Currency.usd,FilterCurrency.all=>Currency.yer};
}

class HomeNotifier extends StateNotifier<HomeState>{
  final CustomerRepository _customerRepo=CustomerRepository(); final TransactionRepository _transactionRepo=TransactionRepository(); final PaymentRepository _paymentRepo=PaymentRepository();
  HomeNotifier():super(HomeState());
  Future<void> loadCustomers() async { state=state.copyWith(isLoading:true,error:null); try{final customers = await _customerRepo.getCustomers();
      final activeIds = customers.map((c) => c.id).whereType<int>().toSet();
      final allTransactions = await _transactionRepo.getAllTransactions();
      final allPayments = (await _paymentRepo.getAllPayments()).where((p) => activeIds.contains(p.customerId)).toList();
      state=state.copyWith(customers:customers,allTransactions:allTransactions.where((t) => activeIds.contains(t.customerId)).toList(),allPayments:allPayments,isLoading:false);}catch(e){state=state.copyWith(isLoading:false,error:e.toString());}}
  void setSearchQuery(String v)=>state=state.copyWith(searchQuery:v); void setSortOption(SortOption v)=>state=state.copyWith(sortOption:v); void setFilterType(FilterType v)=>state=state.copyWith(filterType:v); void setFilterCurrency(FilterCurrency v)=>state=state.copyWith(filterCurrency:v); void setStatusFilter(CustomerStatusFilter v)=>state=state.copyWith(statusFilter:v);
  Future<Map<Currency,BalanceResult>> getCustomerBalance(int id) async=>state._balanceFor(id);
  Map<Currency,BalanceResult> getCustomerBalanceSync(int id) => state._balanceFor(id);
}
final homeProvider=StateNotifierProvider<HomeNotifier,HomeState>((ref)=>HomeNotifier()..loadCustomers());
