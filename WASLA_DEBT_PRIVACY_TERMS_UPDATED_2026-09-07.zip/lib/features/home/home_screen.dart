import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/features/customers/customer_details_screen.dart';
import 'package:wasla_debt/features/customers/edit_customer_screen.dart';
import 'package:wasla_debt/features/home/providers/home_provider.dart';
import 'package:wasla_debt/features/transactions/add_transaction_screen.dart';
import 'package:wasla_debt/core/services/customer_service.dart';
import 'home_drawer.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(homeProvider);
    final notifier = ref.read(homeProvider.notifier);
    final displayed = state.filteredCustomers;
    final selectedCurrency = state.filterCurrency == FilterCurrency.all
        ? null
        : switch (state.filterCurrency) {
            FilterCurrency.yer => Currency.yer,
            FilterCurrency.sar => Currency.sar,
            FilterCurrency.usd => Currency.usd,
            FilterCurrency.all => null,
          };
    final totalOnUs = selectedCurrency == null
        ? 0.0
        : state.customers.fold<double>(0, (sum, c) {
            final b = notifier.getCustomerBalanceSync(c.id!)[selectedCurrency];
            return sum + (b != null && b.balance > 0 ? b.balance : 0);
          });
    final totalForUs = selectedCurrency == null
        ? 0.0
        : state.customers.fold<double>(0, (sum, c) {
            final b = notifier.getCustomerBalanceSync(c.id!)[selectedCurrency];
            return sum + (b != null && b.balance < 0 ? b.balance.abs() : 0);
          });
    final hasSelectedBalances = totalOnUs > 0 || totalForUs > 0;

    return Scaffold(
      drawer: const HomeDrawer(),
      appBar: AppBar(
        title: const Text('دفتر الديون'),
        leading: Builder(
          builder: (context) => IconButton(
            tooltip: 'القائمة',
            icon: const Icon(Icons.menu_rounded),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'إضافة معاملة',
            icon: const Icon(Icons.add_circle_outline_rounded),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
              );
              await notifier.loadCustomers();
            },
          ),
        ],
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.error != null
              ? Center(child: Text('تعذر تحميل البيانات\n${state.error}'))
              : RefreshIndicator(
                  onRefresh: notifier.loadCustomers,
                  child: CustomScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    slivers: [
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                        sliver: SliverToBoxAdapter(
                          child: _WelcomeHeader(customerCount: state.customers.length),
                        ),
                      ),
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                        sliver: SliverToBoxAdapter(
                          child: _CurrencyTabs(
                            selected: state.filterCurrency,
                            onChanged: notifier.setFilterCurrency,
                          ),
                        ),
                      ),
                      if (selectedCurrency != null && !hasSelectedBalances)
                        const SliverPadding(
                          padding: EdgeInsets.fromLTRB(16, 14, 16, 0),
                          sliver: SliverToBoxAdapter(
                            child: _NoCurrencyBalanceCard(),
                          ),
                        )
                      else if (selectedCurrency != null)
                        SliverPadding(
                          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                          sliver: SliverToBoxAdapter(
                            child: Row(
                              children: [
                                Expanded(child: _MetricCard(
                                  width: double.infinity,
                                  title: 'إجمالي عليك',
                                  value: totalOnUs,
                                  currency: selectedCurrency.name.toUpperCase(),
                                  icon: Icons.arrow_downward_rounded,
                                  color: AppColors.debit,
                                )),
                                const SizedBox(width: 10),
                                Expanded(child: _MetricCard(
                                  width: double.infinity,
                                  title: 'إجمالي لك',
                                  value: totalForUs,
                                  currency: selectedCurrency.name.toUpperCase(),
                                  icon: Icons.arrow_upward_rounded,
                                  color: AppColors.credit,
                                )),
                              ],
                            ),
                          ),
                        ),
                      if (selectedCurrency == null)
                        SliverPadding(
                          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                          sliver: SliverToBoxAdapter(
                            child: _BalanceOverview(
                              yer: state.globalTotals[Currency.yer],
                              sar: state.globalTotals[Currency.sar],
                              usd: state.globalTotals[Currency.usd],
                            ),
                          ),
                        ),
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
                        sliver: SliverToBoxAdapter(
                          child: Row(
                            children: [
                              Expanded(
                                child: SearchBar(
                                  leading: const Icon(Icons.search_rounded),
                                  hintText: 'ابحث عن عميل...',
                                  onChanged: notifier.setSearchQuery,
                                ),
                              ),
                              const SizedBox(width: 8),
                              _FilterButton(
                                icon: Icons.filter_alt_outlined,
                                onPressed: () => _showFilters(context, state, notifier),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SliverToBoxAdapter(
                        child: SizedBox(
                          height: 54,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                            children: CustomerStatusFilter.values.map((filter) {
                              final selected = state.statusFilter == filter;
                              final label = filter == CustomerStatusFilter.all
                                  ? 'الكل (${state.customers.length})'
                                  : filter == CustomerStatusFilter.active
                                      ? 'نشط'
                                      : 'تم السداد';
                              return Padding(
                                padding: const EdgeInsetsDirectional.only(end: 8),
                                child: ChoiceChip(
                                  label: Text(label),
                                  selected: selected,
                                  onSelected: (_) => notifier.setStatusFilter(filter),
                                  selectedColor: AppColors.primary,
                                  labelStyle: TextStyle(
                                    color: selected ? Colors.white : AppColors.textSecondary,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                      if (displayed.isEmpty)
                        SliverFillRemaining(
                          hasScrollBody: false,
                          child: _EmptyCustomers(
                            settled: state.statusFilter == CustomerStatusFilter.settled,
                            searching: state.searchQuery.trim().isNotEmpty,
                          ),
                        )
                      else
                        SliverPadding(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                          sliver: SliverList.builder(
                            itemCount: displayed.length,
                            itemBuilder: (context, index) {
                              final customer = displayed[index];
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: _CustomerCard(
                                  customer: customer,
                                  state: state,
                                  onOpen: () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => CustomerDetailsScreen(customerId: customer.id!),
                                      ),
                                    );
                                    await notifier.loadCustomers();
                                  },
                                  onEdit: () async {
                                    final changed = await Navigator.push<bool>(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => EditCustomerScreen(customer: customer),
                                      ),
                                    );
                                    if (changed == true) await notifier.loadCustomers();
                                  },
                                  onArchive: () async {
                                    try {
                                      await CustomerService.archiveCustomer(customer.id!);
                                      await notifier.loadCustomers();
                                    } catch (e) {
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
                                        );
                                      }
                                    }
                                  },
                                ),
                              );
                            },
                          ),
                        ),
                    ],
                  ),
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
          );
          await notifier.loadCustomers();
        },
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة معاملة'),
      ),
    );
  }

  void _showFilters(BuildContext context, HomeState state, HomeNotifier notifier) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('تصفية العملاء', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final option in FilterType.values)
                    ChoiceChip(
                      label: Text(option == FilterType.all ? 'الكل' : option == FilterType.credit ? 'له' : 'عليه'),
                      selected: state.filterType == option,
                      onSelected: (_) {
                        notifier.setFilterType(option);
                        Navigator.pop(context);
                      },
                      selectedColor: AppColors.primary,
                      labelStyle: TextStyle(
                        color: state.filterType == option ? Colors.white : AppColors.text,
                        fontWeight: FontWeight.w700,
                      ),
                      side: BorderSide(
                        color: state.filterType == option ? AppColors.primary : AppColors.divider,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              const Text('العملة', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: FilterCurrency.values.map((currency) {
                  final label = currency == FilterCurrency.all ? 'كل العملات' : currency.name.toUpperCase();
                  return ChoiceChip(
                    label: Text(label),
                    selected: state.filterCurrency == currency,
                    onSelected: (_) {
                      notifier.setFilterCurrency(currency);
                      Navigator.pop(context);
                    },
                    selectedColor: AppColors.primary,
                    labelStyle: TextStyle(
                      color: state.filterCurrency == currency ? Colors.white : AppColors.text,
                      fontWeight: FontWeight.w700,
                    ),
                    side: BorderSide(
                      color: state.filterCurrency == currency ? AppColors.primary : AppColors.divider,
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CurrencyTabs extends StatelessWidget {
  final FilterCurrency selected;
  final ValueChanged<FilterCurrency> onChanged;
  const _CurrencyTabs({required this.selected, required this.onChanged});
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    child: Row(children: FilterCurrency.values.map((c) {
      final label = switch (c) {
        FilterCurrency.all => 'الكل',
        FilterCurrency.yer => 'YER',
        FilterCurrency.sar => 'SAR',
        FilterCurrency.usd => 'USD',
      };
      return Padding(
        padding: const EdgeInsetsDirectional.only(end: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: selected == c,
          onSelected: (_) => onChanged(c),
          selectedColor: AppColors.primary,
          labelStyle: TextStyle(
            color: selected == c ? Colors.white : AppColors.text,
            fontWeight: FontWeight.w700,
            fontSize: 13,
          ),
          side: BorderSide(
            color: selected == c ? AppColors.primary : AppColors.divider,
          ),
        ),
      );
    }).toList()),
  );
}

class _NoCurrencyBalanceCard extends StatelessWidget {
  const _NoCurrencyBalanceCard();
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Row(children: const [
        Icon(Icons.info_outline),
        SizedBox(width: 10),
        Expanded(child: Text('لا توجد أرصدة بهذه العملة')),
      ]),
    ),
  );
}

class _WelcomeHeader extends StatelessWidget {
  final int customerCount;
  const _WelcomeHeader({required this.customerCount});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مرحبًا بك 👋', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text('$customerCount عميل • نظرة سريعة على حساباتك', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(11),
          decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .08), shape: BoxShape.circle),
          child: const Icon(Icons.account_balance_wallet_rounded, color: AppColors.primary),
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  final double width;
  final String title;
  final double value;
  final String currency;
  final IconData icon;
  final Color color;

  const _MetricCard({required this.width, required this.title, required this.value, required this.currency, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: .10),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(icon, color: color, size: 19),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      title,
                      maxLines: 1,
                      softWrap: false,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.text,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Text(
                  MoneyFormat.amount(value),
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color),
                ),
              ),
              Text(currency, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ),
    );
  }
}

class _BalanceOverview extends StatelessWidget {
  final dynamic yer;
  final dynamic sar;
  final dynamic usd;
  const _BalanceOverview({required this.yer, required this.sar, required this.usd});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('ملخص الأرصدة', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _BalanceItem('YER', yer?.balance ?? 0)),
            const SizedBox(width: 8),
            Expanded(child: _BalanceItem('SAR', sar?.balance ?? 0)),
            const SizedBox(width: 8),
            Expanded(child: _BalanceItem('USD', usd?.balance ?? 0)),
          ]),
        ]),
      ),
    );
  }
}

class _BalanceItem extends StatelessWidget {
  final String currency;
  final double balance;
  const _BalanceItem(this.currency, this.balance);

  @override
  Widget build(BuildContext context) {
    final color = balance > 0 ? AppColors.debit : balance < 0 ? AppColors.credit : AppColors.neutral;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(color: AppColors.surfaceSoft, borderRadius: BorderRadius.circular(12)),
      child: Column(children: [
        Text(currency, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11)),
        const SizedBox(height: 3),
        Directionality(textDirection: TextDirection.ltr, child: Text(MoneyFormat.amount(balance), style: TextStyle(color: color, fontWeight: FontWeight.w800))),
      ]),
    );
  }
}

class _FilterButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;
  const _FilterButton({required this.icon, required this.onPressed});
  @override
  Widget build(BuildContext context) => IconButton.filledTonal(onPressed: onPressed, icon: Icon(icon), tooltip: 'تصفية');
}

class _CustomerCard extends StatelessWidget {
  final dynamic customer;
  final HomeState state;
  final VoidCallback onOpen;
  final VoidCallback onEdit;
  final VoidCallback onArchive;
  const _CustomerCard({required this.customer, required this.state, required this.onOpen, required this.onEdit, required this.onArchive});

  @override
  Widget build(BuildContext context) {
    final balances = state.getCustomerBalanceSync(customer.id!);
    final selected = switch (state.filterCurrency) {
      FilterCurrency.yer => Currency.yer,
      FilterCurrency.sar => Currency.sar,
      FilterCurrency.usd => Currency.usd,
      FilterCurrency.all => null,
    };
    // "الكل" لا يخلط العملات حسابيًا؛ بطاقة العميل تعرض YER كعملة
    // افتراضية، بينما تبويب العملة المحدد يعرض عملته فقط.
    final balance = selected == null
        ? (balances[Currency.yer]?.balance ?? 0)
        : (balances[selected]?.balance ?? 0);
    final color = balance > 0 ? AppColors.debit : balance < 0 ? AppColors.credit : AppColors.neutral;
    final over = selected == null
        ? balances.values.any((b) =>
            (b.balance > 0 && customer.debtLimitFor(b.currency) != null &&
                b.balance > customer.debtLimitFor(b.currency)!) ||
            (b.balance < 0 && customer.creditLimitFor(b.currency) != null &&
                b.balance.abs() > customer.creditLimitFor(b.currency)!))
        : (() {
            final b = balances[selected];
            if (b == null) return false;
            final limit = b.isDebtor
                ? customer.debtLimitFor(selected)
                : customer.creditLimitFor(selected);
            return limit != null && b.balance.abs() > limit;
          })();
    return Card(
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(AppDimensions.radiusMedium),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(children: [
            CircleAvatar(
              radius: 23,
              backgroundColor: color.withValues(alpha: .10),
              child: Text(customer.name.trim().isEmpty ? '?' : customer.name.trim()[0].toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.w800)),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(child: Text(customer.name, style: const TextStyle(fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis)),
                if (over) ...[
                  const SizedBox(width: 6),
                  const Icon(Icons.warning_amber_rounded, size: 16, color: AppColors.warning),
                ],
              ]),
              const SizedBox(height: 2),
              Text(customer.phone ?? 'لا يوجد رقم', style: const TextStyle(color: AppColors.textSecondary, fontSize: 11)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Directionality(textDirection: TextDirection.ltr, child: Text(MoneyFormat.amount(balance), style: TextStyle(color: color, fontWeight: FontWeight.w800))),
              Text(balance > 0 ? 'عليه' : balance < 0 ? 'له' : 'مسدد', style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)),
            ]),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded, size: 20),
              onSelected: (value) => value == 'edit' ? onEdit() : onArchive(),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('تعديل العميل')),
                PopupMenuItem(value: 'archive', child: Text('أرشفة العميل')),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}

class _EmptyCustomers extends StatelessWidget {
  final bool settled;
  final bool searching;
  const _EmptyCustomers({required this.settled, required this.searching});

  @override
  Widget build(BuildContext context) {
    final title = searching ? 'لا توجد نتائج مطابقة' : settled ? 'لا يوجد عملاء مسددون' : 'لا يوجد عملاء حاليًا';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .07), shape: BoxShape.circle), child: const Icon(Icons.people_outline_rounded, size: 36, color: AppColors.primary)),
          const SizedBox(height: 14),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          const Text('أضف أول عميل للبدء بإدارة حساباته بسهولة.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ]),
      ),
    );
  }
}
