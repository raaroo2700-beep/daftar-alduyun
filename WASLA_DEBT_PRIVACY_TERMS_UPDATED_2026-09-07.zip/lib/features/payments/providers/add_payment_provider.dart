import 'package:wasla_debt/core/utils/money_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/payment_repository.dart';
import 'package:wasla_debt/features/settings/providers/settings_provider.dart';
import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/data/database/app_database.dart';

/// حالة شاشة إضافة سداد (Task P0-02، الخطوة 7).
///
/// المرجع: خطة P0-02 الخطوة 7.
class AddPaymentState {
  final int? customerId;
  final String customerName;
  final String amount;
  final String note;
  final DateTime date;
  final Currency currency;
  final PaymentDirection direction;
  final bool isLoading;
  final String? error;

  AddPaymentState({
    this.customerId,
    this.customerName = '',
    this.amount = '',
    this.note = '',
    required this.date,
    this.currency = Currency.yer,
    this.direction = PaymentDirection.customerToBusiness,
    this.isLoading = false,
    this.error,
  });

  AddPaymentState copyWith({
    int? customerId,
    String? customerName,
    String? amount,
    String? note,
    DateTime? date,
    Currency? currency,
    PaymentDirection? direction,
    bool? isLoading,
    String? error,
  }) {
    return AddPaymentState(
      customerId: customerId ?? this.customerId,
      customerName: customerName ?? this.customerName,
      amount: amount ?? this.amount,
      note: note ?? this.note,
      date: date ?? this.date,
      currency: currency ?? this.currency,
      direction: direction ?? this.direction,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }
}

/// المتحكّم في حالة شاشة إضافة سداد (Task P0-02، الخطوة 7).
///
/// المرجع: خطة P0-02 الخطوة 7.
///
/// على عكس [AddTransactionNotifier]، السداد لا يُنشئ عميلًا جديدًا: السداد
/// لا معنى له إلا لعميل موجود مسبقًا لديه معاملات. إن لم يُوجَد العميل
/// بالاسم المُدخَل، تُرفَض العملية برسالة خطأ بدلًا من إنشاء عميل جديد.
class AddPaymentNotifier extends StateNotifier<AddPaymentState> {
  final CustomerRepository _customerRepo = CustomerRepository();
  final PaymentRepository _paymentRepo = PaymentRepository();
  final Ref _ref;

  AddPaymentNotifier(this._ref)
      : super(AddPaymentState(
          date: DateTime.now(),
          currency: _ref.read(settingsProvider).defaultCurrency,
        ));

  void setCustomer(int? id, String name) { state = state.copyWith(customerId: id, customerName: name); }

  void updateCustomerName(String value) {
    state = state.copyWith(customerName: value);
  }

  void updateAmount(String value) {
    final filtered = value.replaceAll(RegExp(r'[^0-9.]'), '');
    state = state.copyWith(amount: filtered);
  }

  void updateNote(String value) {
    state = state.copyWith(note: value);
  }

  void updateDate(DateTime date) {
    state = state.copyWith(date: date);
  }

  void updateCurrency(Currency currency) {
    state = state.copyWith(currency: currency);
  }

  void updateDirection(PaymentDirection direction) {
    state = state.copyWith(direction: direction);
  }

  Future<bool> savePayment(BuildContext context) async {
    if (state.customerName.trim().isEmpty) {
      state = state.copyWith(error: 'يرجى إدخال اسم العميل');
      return false;
    }

    final double? amountValue = double.tryParse(state.amount);
    if (amountValue == null || amountValue <= 0 || !MoneyValidator.hasAtMostTwoDecimals(amountValue)) {
      state = state.copyWith(error: 'المبلغ يجب أن يكون أكبر من صفر وبحد أقصى منزلتين عشريتين');
      return false;
    }

    state = state.copyWith(isLoading: true, error: null);

    try {
      Customer? existingCustomer;
      if (state.customerId != null) {
        existingCustomer = await _customerRepo.getCustomerById(state.customerId!);
      } else {
        final matches = await _findCustomersByName(state.customerName.trim());
        if (matches.length == 1) {
          existingCustomer = matches.first;
        } else if (matches.length > 1 && context.mounted) {
          existingCustomer = await showDialog<Customer>(
            context: context,
            builder: (_) => SimpleDialog(
              title: const Text('يوجد أكثر من عميل بهذا الاسم'),
              children: matches.map((c) => SimpleDialogOption(
                onPressed: () => Navigator.pop(context, c),
                child: Text('${c.name}${c.phone == null ? '' : ' — ${c.phone}'}'),
              )).toList(),
            ),
          );
        }
      }
      if (existingCustomer == null) {
        state = state.copyWith(
          isLoading: false,
          error: 'العميل غير موجود',
        );
        return false;
      }

      if (existingCustomer.isArchived) {
        state = state.copyWith(isLoading: false, error: 'العميل مؤرشف. استعده أولًا قبل تسجيل سداد جديد');
        return false;
      }

      // For a fresh payment form, callers can change the direction explicitly.
      // The selected direction is preserved as part of the payment record.
      final payment = Payment(
        customerId: existingCustomer.id!,
        amount: amountValue,
        currency: state.currency,
        direction: state.direction,
        note: state.note.trim().isEmpty ? null : state.note.trim(),
        paymentDate: state.date.millisecondsSinceEpoch,
        createdAt: DateTime.now().millisecondsSinceEpoch,
        updatedAt: DateTime.now().millisecondsSinceEpoch,
      );

      final db = await AppDatabase().database;
      await db.transaction((txn) async {
        final id = await _paymentRepo.insertPaymentWithTxn(payment, txn);
        await AuditService.logPaymentCreate(payment: payment.copyWith(id: id), txn: txn);
      });

      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return false;
    }
  }

  Future<List<Customer>> _findCustomersByName(String name) async {
    final customers = await _customerRepo.getCustomers(includeArchived: true);
    final normalized = name.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
    return customers.where((c) => c.name.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ') == normalized).toList();
  }

  void reset() {
    state = AddPaymentState(
      date: DateTime.now(),
      currency: _ref.read(settingsProvider).defaultCurrency,
    );
  }
}

final addPaymentProvider =
    StateNotifierProvider<AddPaymentNotifier, AddPaymentState>((ref) {
  return AddPaymentNotifier(ref);
});
