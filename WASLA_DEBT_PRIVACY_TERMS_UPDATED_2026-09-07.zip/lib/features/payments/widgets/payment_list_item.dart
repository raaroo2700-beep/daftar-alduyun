import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/features/settings/providers/settings_provider.dart';

/// عنصر عرض سداد في القائمة (Task P0-02، الخطوة 13).
///
/// المرجع: خطة P0-02 الخطوة 13.
/// نفس تصميم [TransactionListItem] (في customer_details_screen.dart) تمامًا
/// — Card + ListTile بنفس الأبعاد ونمط التاريخ حسب إعداد "إظهار الوقت" —
/// بلا أي زر حذف أو تعديل، وبلا أي حساب رصيد.
class PaymentListItem extends ConsumerWidget {
  final Payment payment;

  const PaymentListItem({super.key, required this.payment});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // إصلاح 5.1: مفتاح "إظهار الوقت" (نفس منطق TransactionListItem).
    final showTime = ref.watch(settingsProvider).showTime;
    final datePattern = showTime ? 'yyyy-MM-dd HH:mm' : 'yyyy-MM-dd';
    final color = payment.direction == PaymentDirection.customerToBusiness ? AppColors.credit : AppColors.debit;

    return Card(
      margin: const EdgeInsets.symmetric(
        horizontal: AppDimensions.paddingMedium,
        vertical: 4,
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withValues(alpha: 0.2),
          child: Text(
            payment.direction == PaymentDirection.customerToBusiness ? 'دفع لي' : 'دفعت له',
            style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11),
          ),
        ),
        title: Text(
          '${MoneyFormat.amount(payment.amount)} ${payment.currency.name.toUpperCase()}',
          style: TextStyle(color: color, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${payment.direction == PaymentDirection.customerToBusiness ? 'دفع لي' : 'دفعت له'}${payment.note == null ? '' : ' — ${payment.note}'}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Text(
          DateFormat(datePattern, 'ar').format(
            DateTime.fromMillisecondsSinceEpoch(payment.paymentDate),
          ),
          style: const TextStyle(fontSize: 12, color: AppColors.hint),
        ),
        onTap: () {},
      ),
    );
  }
}
