import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/features/payments/providers/add_payment_provider.dart';

/// شاشة إضافة سداد (Task P0-02، الخطوة 8).
///
/// المرجع: خطة P0-02 الخطوة 8.
/// نفس بنية [AddTransactionScreen] (خطوة 4.1 القديمة)، بلا حقل صورة أو
/// تكرار تلقائي أو نوع عملية — السداد ليس له هذه الحقول أصلًا.
class AddPaymentScreen extends ConsumerStatefulWidget {
  // اسم عميل اختياري لملء الحقل تلقائيًا عند الإضافة من داخل شاشة تفاصيل
  // عميل محدد (نفس نمط AddTransactionScreen.initialCustomerName).
  final String? initialCustomerName;
  final int? initialCustomerId;

  const AddPaymentScreen({super.key, this.initialCustomerName, this.initialCustomerId});

  @override
  ConsumerState<AddPaymentScreen> createState() => _AddPaymentScreenState();
}

class _AddPaymentScreenState extends ConsumerState<AddPaymentScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _noteController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // تصفير حالة الـ provider عند فتح الشاشة (نفس منطق AddTransactionScreen):
    // الـ provider ليس autoDispose، فتصفيره وملء اسم العميل يُؤجَّلان إلى ما
    // بعد اكتمال الإطار الحالي عبر addPostFrameCallback لأنهما يُعدّلان
    // الـ provider، ولا يجوز ذلك أثناء بناء الـ widget tree.
    if (widget.initialCustomerName != null &&
        widget.initialCustomerName!.trim().isNotEmpty) {
      _nameController.text = widget.initialCustomerName!;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(addPaymentProvider.notifier).reset();
      if (widget.initialCustomerName != null &&
          widget.initialCustomerName!.trim().isNotEmpty) {
        ref
            .read(addPaymentProvider.notifier)
            .setCustomer(widget.initialCustomerId, widget.initialCustomerName!);
      }
    });
    _nameController.addListener(() {
      ref.read(addPaymentProvider.notifier).updateCustomerName(_nameController.text);
    });
    _amountController.addListener(() {
      ref.read(addPaymentProvider.notifier).updateAmount(_amountController.text);
    });
    _noteController.addListener(() {
      ref.read(addPaymentProvider.notifier).updateNote(_noteController.text);
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _amountController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(addPaymentProvider);
    final notifier = ref.read(addPaymentProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة سداد'),
        actions: [
          if (state.isLoading)
            const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              ),
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppDimensions.paddingLarge),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // اسم العميل
              TextField(
                controller: _nameController,
                readOnly: widget.initialCustomerId != null,
                decoration: const InputDecoration(
                  labelText: 'اسم العميل',
                  hintText: 'أدخل اسم العميل',
                ),
              ),
              const SizedBox(height: 16),

              // المبلغ
              TextField(
                controller: _amountController,
                decoration: const InputDecoration(
                  labelText: 'المبلغ',
                  hintText: '0.00',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),

              // العملة
              Row(
                children: [
                  Expanded(
                    child: _PaymentCurrencyButton(
                      label: 'محلي',
                      selected: state.currency == Currency.yer,
                      onTap: () => notifier.updateCurrency(Currency.yer),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _PaymentCurrencyButton(
                      label: 'دولار',
                      selected: state.currency == Currency.usd,
                      onTap: () => notifier.updateCurrency(Currency.usd),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _PaymentCurrencyButton(
                      label: 'سعودي',
                      selected: state.currency == Currency.sar,
                      onTap: () => notifier.updateCurrency(Currency.sar),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              const Text('اتجاه السداد', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: _PaymentDirectionButton(
                    label: 'دفع لي',
                    selected: state.direction == PaymentDirection.customerToBusiness,
                    onTap: () => notifier.updateDirection(PaymentDirection.customerToBusiness),
                  )),
                  const SizedBox(width: 8),
                  Expanded(child: _PaymentDirectionButton(
                    label: 'دفعت له',
                    selected: state.direction == PaymentDirection.businessToCustomer,
                    onTap: () => notifier.updateDirection(PaymentDirection.businessToCustomer),
                  )),
                ],
              ),
              const SizedBox(height: 16),

              // الملاحظات
              TextField(
                controller: _noteController,
                decoration: const InputDecoration(
                  labelText: 'الملاحظات (اختياري)',
                  hintText: 'أضف ملاحظة',
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 16),

              // التاريخ
              InkWell(
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: state.date,
                    firstDate: DateTime(2020),
                    lastDate: DateTime.now(),
                    locale: const Locale('ar', 'SA'),
                  );
                  if (!context.mounted) return;
                  if (date != null) {
                    notifier.updateDate(date);
                  }
                },
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'التاريخ',
                    border: OutlineInputBorder(),
                  ),
                  child: Text(
                    DateFormat('yyyy-MM-dd', 'ar').format(state.date),
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // زر الحفظ
              ElevatedButton(
                onPressed: state.isLoading
                    ? null
                    : () async {
                        final success = await notifier.savePayment(context);
                        if (!context.mounted) return;
                        if (success) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('تمت إضافة السداد بنجاح')),
                          );
                          Navigator.pop(context);
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(state.error ?? 'حدث خطأ')),
                          );
                        }
                      },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: Text(
                  state.isLoading ? 'جاري الحفظ...' : 'حفظ',
                  style: const TextStyle(fontSize: 18),
                ),
              ),

              if (state.error != null) ...[
                const SizedBox(height: 12),
                Text(
                  state.error!,
                  style: const TextStyle(color: Colors.red),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// زر اختيار عملة السداد (نسخة محلية من _CurrencyButton في
// add_transaction_screen.dart — لم يُستورَد لأنه صنف خاص private هناك،
// ولتفادي تعديل ذلك الملف الخارج عن نطاق هذه الخطوة).
class _PaymentCurrencyButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _PaymentCurrencyButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.surface,
          borderRadius: BorderRadius.circular(AppDimensions.radiusMedium),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.divider,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : AppColors.text,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }
}


class _PaymentDirectionButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _PaymentDirectionButton({required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
    onPressed: onTap,
    icon: Icon(selected ? Icons.check_circle : Icons.radio_button_unchecked),
    label: Text(label),
    style: OutlinedButton.styleFrom(
      backgroundColor: selected ? AppColors.primary : null,
      foregroundColor: selected ? Colors.white : null,
    ),
  );
}
