import 'package:wasla_debt/core/utils/money_validator.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/payment_service.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';

class EditPaymentScreen extends StatefulWidget {
  final Payment payment;
  const EditPaymentScreen({super.key, required this.payment});
  @override State<EditPaymentScreen> createState() => _EditPaymentScreenState();
}

class _EditPaymentScreenState extends State<EditPaymentScreen> {
  late final TextEditingController _amount;
  late final TextEditingController _note;
  late Currency _currency;
  late PaymentDirection _direction;
  late DateTime _date;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _amount = TextEditingController(text: widget.payment.amount.toString());
    _note = TextEditingController(text: widget.payment.note ?? '');
    _currency = widget.payment.currency;
    _direction = widget.payment.direction;
    _date = DateTime.fromMillisecondsSinceEpoch(widget.payment.paymentDate);
  }

  @override
  void dispose() { _amount.dispose(); _note.dispose(); super.dispose(); }

  Future<void> _save() async {
    final amount = double.tryParse(_amount.text.trim());
    if (amount == null || amount <= 0 || !MoneyValidator.hasAtMostTwoDecimals(amount)) { _msg('المبلغ يجب أن يكون أكبر من صفر وبحد أقصى منزلتين عشريتين'); return; }
    setState(() => _saving = true);
    try {
      await PaymentService.updatePayment(Payment(
        id: widget.payment.id,
        customerId: widget.payment.customerId,
        amount: amount,
        currency: _currency,
        direction: _direction,
        transactionId: widget.payment.transactionId,
        note: _note.text.trim().isEmpty ? null : _note.text.trim(),
        paymentDate: _date.millisecondsSinceEpoch,
        createdAt: widget.payment.createdAt,
        updatedAt: widget.payment.updatedAt,
      ));
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) _msg(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _msg(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تعديل السداد'), actions: [IconButton(tooltip: 'حفظ', onPressed: _saving ? null : _save, icon: const Icon(Icons.save))]),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingLarge),
        children: [
          TextField(controller: _amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المبلغ', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          Row(
            children: Currency.values.map((c) {
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: OutlinedButton(
                    onPressed: _saving ? null : () => setState(() => _currency = c),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: _currency == c ? Theme.of(context).colorScheme.primary : null,
                      foregroundColor: _currency == c ? Colors.white : null,
                    ),
                    child: Text(c.name.toUpperCase()),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          const Text('اتجاه السداد', style: TextStyle(fontWeight: FontWeight.w700)),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: _saving ? null : () => setState(() => _direction = PaymentDirection.customerToBusiness),
              style: OutlinedButton.styleFrom(
                backgroundColor: _direction == PaymentDirection.customerToBusiness ? Theme.of(context).colorScheme.primary : null,
                foregroundColor: _direction == PaymentDirection.customerToBusiness ? Colors.white : null,
              ),
              child: const Text('دفع لي'),
            )),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(
              onPressed: _saving ? null : () => setState(() => _direction = PaymentDirection.businessToCustomer),
              style: OutlinedButton.styleFrom(
                backgroundColor: _direction == PaymentDirection.businessToCustomer ? Theme.of(context).colorScheme.primary : null,
                foregroundColor: _direction == PaymentDirection.businessToCustomer ? Colors.white : null,
              ),
              child: const Text('دفعت له'),
            )),
          ]),
          const SizedBox(height: 16),
          TextField(controller: _note, maxLines: 2, decoration: const InputDecoration(labelText: 'الملاحظات', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          ListTile(title: const Text('التاريخ'), subtitle: Text(DateFormat('yyyy-MM-dd', 'ar').format(_date)), onTap: _saving ? null : () async { final d = await showDatePicker(context: context, initialDate: _date, firstDate: DateTime(2020), lastDate: DateTime.now(), locale: const Locale('ar', 'SA')); if (d != null) setState(() => _date = d); }),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save), label: Text(_saving ? 'جاري الحفظ...' : 'حفظ التعديلات')),
        ],
      ),
    );
  }
}
