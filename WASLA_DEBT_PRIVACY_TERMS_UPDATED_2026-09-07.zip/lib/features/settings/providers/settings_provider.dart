import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wasla_debt/data/models/app_settings.dart';
// ✅ أضف هذا الاستيراد لتعريف Currency
import 'package:wasla_debt/data/models/debt_transaction.dart';

class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier() : super(AppSettings()) {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final defaultCurrency = prefs.getString('defaultCurrency') ?? 'yer';
    final showTime = prefs.getBool('showTime') ?? true;
    final darkMode = prefs.getBool('darkMode') ?? false;
    final maxBackups = prefs.getInt('maxBackups') ?? 5;
    final autoBackup = prefs.getBool('autoBackup') ?? false;
    final backupFolderPath = prefs.getString('backupFolderPath');
    final autoBackupHour = prefs.getInt('autoBackupHour') ?? 2;
    final autoBackupMinute = prefs.getInt('autoBackupMinute') ?? 0;

    state = AppSettings(
      defaultCurrency: Currency.values.firstWhere(
            (e) => e.name == defaultCurrency,
        orElse: () => Currency.yer,
      ),
      showTime: showTime,
      darkMode: darkMode,
      maxBackups: maxBackups,
      autoBackup: autoBackup,
      backupFolderPath: backupFolderPath,
      autoBackupHour: autoBackupHour,
      autoBackupMinute: autoBackupMinute,
    );
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('defaultCurrency', state.defaultCurrency.name);
    await prefs.setBool('showTime', state.showTime);
    await prefs.setBool('darkMode', state.darkMode);
    await prefs.setInt('maxBackups', state.maxBackups);
    await prefs.setBool('autoBackup', state.autoBackup);
    if (state.backupFolderPath == null) {
      await prefs.remove('backupFolderPath');
    } else {
      await prefs.setString('backupFolderPath', state.backupFolderPath!);
    }
    await prefs.setInt('autoBackupHour', state.autoBackupHour);
    await prefs.setInt('autoBackupMinute', state.autoBackupMinute);
  }

  void setDefaultCurrency(Currency currency) {
    state = state.copyWith(defaultCurrency: currency);
    _saveSettings();
  }

  void toggleShowTime(bool value) {
    state = state.copyWith(showTime: value);
    _saveSettings();
  }

  void toggleDarkMode(bool value) {
    state = state.copyWith(darkMode: value);
    _saveSettings();
  }

  void setMaxBackups(int value) {
    state = state.copyWith(maxBackups: value);
    _saveSettings();
  }

  void toggleAutoBackup(bool value) {
    state = state.copyWith(autoBackup: value);
    _saveSettings();
  }

  void setBackupFolderPath(String? path) {
    if (path == null) {
      state = state.copyWith(clearBackupFolderPath: true);
    } else {
      state = state.copyWith(backupFolderPath: path);
    }
    _saveSettings();
  }

  void setAutoBackupTime(int hour, int minute) {
    state = state.copyWith(autoBackupHour: hour, autoBackupMinute: minute);
    _saveSettings();
  }
}

final settingsProvider =
StateNotifierProvider<SettingsNotifier, AppSettings>((ref) {
  return SettingsNotifier();
});