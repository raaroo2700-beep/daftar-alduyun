import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// ✅ حذف الاستيراد غير المستخدم 'app_colors.dart'
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/activation_service.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/features/settings/providers/settings_provider.dart';
import 'package:wasla_debt/features/subscription/activation_screen.dart';
import 'package:wasla_debt/features/backup/google_drive_screen.dart';
import 'package:wasla_debt/core/services/google_drive_service.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';

class SettingsScreen extends ConsumerWidget {
const SettingsScreen({super.key});

@override
Widget build(BuildContext context, WidgetRef ref) {
final settings = ref.watch(settingsProvider);
final notifier = ref.read(settingsProvider.notifier);

return Scaffold(
appBar: AppBar(
title: const Text('الإعدادات'),
),
body: ListView(
padding: const EdgeInsets.all(AppDimensions.paddingMedium),
children: [
// العملة الافتراضية
_SettingsSection(
title: 'العملة الافتراضية',
child: DropdownButtonFormField<Currency>(
  initialValue: settings.defaultCurrency, // بدلاً من value:

decoration: const InputDecoration(
border: OutlineInputBorder(),
contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
),
items: Currency.values.map((currency) {
return DropdownMenuItem(
value: currency,
child: Text(currency.name.toUpperCase()),
);
}).toList(),
onChanged: (value) {
if (value != null) {
notifier.setDefaultCurrency(value);
}
},
),
),
const SizedBox(height: 16),

// إظهار الوقت
_SettingsSection(
title: 'إظهار الوقت',
child: SwitchListTile(
value: settings.showTime,
onChanged: notifier.toggleShowTime,
title: const Text('عرض الوقت في العمليات'),
secondary: const Icon(Icons.access_time),
contentPadding: EdgeInsets.zero,
dense: true,
),
),

// الوضع الليلي
_SettingsSection(
title: 'المظهر',
child: SwitchListTile(
value: settings.darkMode,
onChanged: notifier.toggleDarkMode,
title: const Text('الوضع الليلي'),
secondary: const Icon(Icons.dark_mode),
contentPadding: EdgeInsets.zero,
dense: true,
),
),

// عدد النسخ الاحتياطية
_SettingsSection(
title: 'النسخ الاحتياطي',
child: Row(
children: [
const Text('الحد الأقصى للنسخ:'),
const SizedBox(width: 12),
Expanded(
child: DropdownButtonFormField<int>(
  initialValue: settings.maxBackups, // بدلاً من value:
decoration: const InputDecoration(
border: OutlineInputBorder(),
contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
),
items: [3, 5, 10, 20].map((value) {
return DropdownMenuItem(
value: value,
child: Text('$value'),
);
}).toList(),
onChanged: (value) {
if (value != null) {
notifier.setMaxBackups(value);
}
},
),
),
],
),
),

// النسخ الاحتياطي التلقائي
_SettingsSection(
title: '',
child: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    SwitchListTile(
      value: settings.autoBackup,
      onChanged: notifier.toggleAutoBackup,
      title: const Text('نسخ احتياطي تلقائي'),
      secondary: const Icon(Icons.autorenew),
      contentPadding: EdgeInsets.zero,
      dense: true,
    ),
    if (settings.autoBackup) ...[
      const Divider(height: 1),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.schedule),
        title: const Text('وقت النسخ التلقائي'),
        subtitle: Text(
          'بعد الساعة ${settings.autoBackupHour.toString().padLeft(2, '0')}:${settings.autoBackupMinute.toString().padLeft(2, '0')} عند فتح التطبيق',
        ),
        trailing: const Icon(Icons.edit, size: 18),
        onTap: () async {
          final picked = await showTimePicker(
            context: context,
            initialTime: TimeOfDay(
              hour: settings.autoBackupHour,
              minute: settings.autoBackupMinute,
            ),
          );
          if (picked != null) {
            notifier.setAutoBackupTime(picked.hour, picked.minute);
          }
        },
      ),
      const Padding(
        padding: EdgeInsets.only(bottom: 4),
        child: Text(
          'ملاحظة: التطبيق ينشئ النسخة عند أول فتح بعد هذا الوقت، وليس بالضبط أثناء إغلاق التطبيق.',
          style: TextStyle(fontSize: 11, color: Colors.grey),
        ),
      ),
    ],
  ],
),
),

// مجلد حفظ النسخ الاحتياطية المحلية
_SettingsSection(
  title: 'مجلد النسخ الاحتياطي المحلي',
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        settings.backupFolderPath ?? 'المسار الافتراضي (داخل مساحة التطبيق)',
        style: const TextStyle(fontSize: 13),
      ),
      const SizedBox(height: 8),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          ElevatedButton.icon(
            icon: const Icon(Icons.folder_open),
            label: const Text('اختيار مجلد'),
            onPressed: () async {
              final selected = await FilePicker.platform.getDirectoryPath();
              if (selected == null) return;
              // نتحقق فعليًا من إمكانية الكتابة قبل الحفظ، حتى لا يفشل
              // النسخ الاحتياطي لاحقًا بصمت لمجرد أن المجلد غير قابل للكتابة
              // (بعض المجلدات على أندرويد تظهر في المنتقي لكن الكتابة فيها
              // ممنوعة فعليًا بسبب قيود التخزين المحمي).
              try {
                final probe = File('$selected/.wasla_write_check');
                await probe.writeAsBytes(const [0]);
                await probe.delete();
                notifier.setBackupFolderPath(selected);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('✅ تم تحديد مجلد النسخ الاحتياطي')),
                  );
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('❌ لا يمكن الكتابة في هذا المجلد، اختر مجلدًا آخر: $e'),
                    ),
                  );
                }
              }
            },
          ),
          if (settings.backupFolderPath != null)
            OutlinedButton.icon(
              icon: const Icon(Icons.restore_page),
              label: const Text('استخدام المسار الافتراضي'),
              onPressed: () => notifier.setBackupFolderPath(null),
            ),
        ],
      ),
    ],
  ),
),

  const Divider(height: 32),

  // حالة الاشتراك
  _buildSubscriptionSection(context),

  const Divider(height: 32),

  // إعدادات Google Drive
  _buildGoogleDriveSection(context),
],
),
);
}

Widget _buildSubscriptionSection(BuildContext context) {
  return _SettingsSection(
    title: 'الاشتراك',
    child: FutureBuilder(
      future: Future.wait([ActivationService.getActivation(), ActivationService.isPremium()]),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        final results = snapshot.data;
        final info = results?[0] as ActivationInfo?;
        final premium = results?[1] as bool? ?? false;
        if (info == null || !premium) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('❌ غير مفعل', style: TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: () async {
                  // إصلاح 5.2: الزر كان بلا أي وظيفة رغم وجود ActivationScreen
                  // فعّالة بالكامل في المشروع.
                  final customerRepo = CustomerRepository();
                  final count = await customerRepo.countActiveCustomers();
                  if (!context.mounted) return;
                  await Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ActivationScreen(
                        currentCustomerCount: count,
                        onActivated: () {},
                      ),
                    ),
                  );
                },
                child: const Text('تفعيل البرنامج'),
              ),
            ],
          );
        }

        final expiry = info.expiryDate == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(info.expiryDate!);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('✅ مفعل', style: TextStyle(color: Colors.green)),
            const SizedBox(height: 4),
            Text('نوع الترخيص: ${info.duration}'),
            if (expiry != null) Text('ينتهي في: ${expiry.toLocal()}'),
            if (info.isLifetime)
            // ✅ استخدام Colors.amber بدلاً من Colors.gold (غير موجود)
              const Text('مدى الحياة 🎉', style: TextStyle(color: Colors.amber)),
          ],
        );
      },
    ),
  );
}

Widget _buildGoogleDriveSection(BuildContext context) {
  // إصلاح 5.2: نص "غير متصل" كان ثابتًا دائمًا ولا يعكس الحالة الحقيقية،
  // وأزرار "تسجيل الدخول"/"تسجيل الخروج" هنا كانت بلا وظيفة رغم وجود
  // GoogleDriveScreen كاملة الوظائف. بدل تكرار منطق تسجيل الدخول/الخروج هنا
  // مرة أخرى، نعرض الحالة الحقيقية وننقل المستخدم إلى تلك الشاشة الفعلية.
  final signedIn = GoogleDriveService.isSignedIn;
  return _SettingsSection(
    title: 'Google Drive',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(signedIn ? 'حالة التزامن: متصل' : 'حالة التزامن: غير متصل'),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const GoogleDriveScreen()),
            );
          },
          icon: const Icon(Icons.cloud),
          label: Text(signedIn ? 'إدارة Google Drive' : 'تسجيل الدخول إلى Google Drive'),
        ),
      ],
    ),
  );
}
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final Widget child;

  const _SettingsSection({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (title.isNotEmpty) ...[
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
        ],
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: child,
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}