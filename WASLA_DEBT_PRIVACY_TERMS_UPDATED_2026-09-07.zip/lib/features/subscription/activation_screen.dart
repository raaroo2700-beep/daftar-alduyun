import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/activation_service.dart';

class ActivationScreen extends StatefulWidget {
  final int currentCustomerCount;
  final VoidCallback onActivated;
  const ActivationScreen({super.key,required this.currentCustomerCount,required this.onActivated});
  @override State<ActivationScreen> createState()=>_ActivationScreenState();
}
class _ActivationScreenState extends State<ActivationScreen>{
  final _code=TextEditingController(); String? _deviceId; bool _loading=false; String? _error;
  @override void initState(){super.initState();_loadDeviceId();}
  Future<void> _loadDeviceId() async{final id=await ActivationService.getDeviceId();if(mounted)setState(()=>_deviceId=id);}
  @override void dispose(){_code.dispose();super.dispose();}
  Future<void> _activate() async {
    final code = _code.text.trim();
    if (code.isEmpty) {
      setState(() => _error = 'يرجى إدخال رمز التفعيل');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final info = await ActivationService.verifyCode(code);
      if (!mounted) return;
      if (info != null && info.isActive) {
        await ActivationService.saveActivation(info);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم تفعيل البرنامج بنجاح')),
        );
        widget.onActivated();
      } else {
        setState(() => _error = 'رمز التفعيل غير صحيح أو غير مخصص لهذا الجهاز');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذر التحقق من رمز التفعيل');
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('تفعيل البرنامج')),body:ListView(padding:const EdgeInsets.all(AppDimensions.paddingLarge),children:[const Icon(Icons.lock_outline,size:72,color:AppColors.primary),const SizedBox(height:16),const Text('لقد وصلت إلى الحد المجاني',textAlign:TextAlign.center,style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text('لديك ${widget.currentCustomerCount} من 30 عميلًا مجانيًا. أرسل معرّف الجهاز للدعم للحصول على رمز مخصص لهذا الجهاز.',textAlign:TextAlign.center),const SizedBox(height:20),if(_deviceId!=null)Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('معرّف الجهاز',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:6),SelectableText(_deviceId!,textDirection:TextDirection.ltr),Align(alignment:Alignment.centerLeft,child:IconButton(icon:const Icon(Icons.copy),onPressed: () async {
              await Clipboard.setData(ClipboardData(text: _deviceId!));
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تم نسخ معرّف الجهاز')),
              );
            }))]))),const SizedBox(height:12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ...ActivationService.whatsAppContacts.map(
                (contact) => ElevatedButton.icon(
                  onPressed: () => ActivationService.contactWhatsAppNumber(contact['phone']!),
                  icon: const Icon(Icons.chat),
                  label: Text(contact['label']!),
                ),
              ),
              ElevatedButton.icon(
                onPressed: ActivationService.contactEmail,
                icon: const Icon(Icons.email),
                label: const Text('البريد الإلكتروني'),
              ),
            ],
          ),
          const SizedBox(height:20),TextField(controller:_code,textDirection:TextDirection.ltr,decoration:InputDecoration(labelText:'رمز التفعيل',border:const OutlineInputBorder(),errorText:_error)),const SizedBox(height:16),FilledButton(onPressed:_loading?null:_activate,child:Text(_loading?'جاري التحقق...':'تفعيل البرنامج'))]));
}
