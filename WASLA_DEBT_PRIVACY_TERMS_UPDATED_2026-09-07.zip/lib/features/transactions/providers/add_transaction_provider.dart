import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/core/utils/money_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:wasla_debt/core/services/activation_service.dart';
import 'package:wasla_debt/core/services/customer_limit_service.dart';
import 'package:wasla_debt/core/services/audit_service.dart';
import 'package:wasla_debt/core/services/customer_service.dart';
import 'package:wasla_debt/core/services/attachment_service.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/recurring_schedule.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/recurring_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';
import 'package:wasla_debt/features/settings/providers/settings_provider.dart';
import 'package:wasla_debt/features/subscription/activation_screen.dart';

const _StateUnset _unset = _StateUnset();
class _StateUnset { const _StateUnset(); }

class AddTransactionState {
  final int? customerId;
  final String customerName;
  final String amount;
  final String details;
  final DateTime date;
  final String? imagePath;
  final Currency currency;
  final DebtType type;
  final bool isLoading;
  final String? error;

  AddTransactionState({this.customerId, this.customerName = '', this.amount = '', this.details = '', required this.date, this.imagePath, this.currency = Currency.yer, this.type = DebtType.credit, this.isLoading = false, this.error});

  AddTransactionState copyWith({int? customerId, String? customerName, String? amount, String? details, DateTime? date, String? imagePath, Currency? currency, DebtType? type, bool? isLoading, Object? error = _unset}) => AddTransactionState(
    customerId: customerId ?? this.customerId,
    customerName: customerName ?? this.customerName,
    amount: amount ?? this.amount,
    details: details ?? this.details,
    date: date ?? this.date,
    imagePath: imagePath ?? this.imagePath,
    currency: currency ?? this.currency,
    type: type ?? this.type,
    isLoading: isLoading ?? this.isLoading,
    error: identical(error, _unset) ? this.error : error as String?,
  );
}

class AddTransactionNotifier extends StateNotifier<AddTransactionState> {
  final CustomerRepository _customerRepo = CustomerRepository();
  final TransactionRepository _transactionRepo = TransactionRepository();
  final RecurringRepository _recurringRepo = RecurringRepository();
  final AttachmentService _attachmentService = AttachmentService();
  final Ref _ref;

  AddTransactionNotifier(this._ref) : super(AddTransactionState(date: DateTime.now(), currency: _ref.read(settingsProvider).defaultCurrency));

  void updateCustomerName(String value) => state = state.copyWith(customerName: value);
  void setCustomer(int? id, String name) => state = state.copyWith(customerId: id, customerName: name);
  void updateAmount(String value) => state = state.copyWith(amount: value.replaceAll(RegExp(r'[^0-9.]'), ''));
  void updateDetails(String value) => state = state.copyWith(details: value);
  void updateDate(DateTime date) => state = state.copyWith(date: date);
  void updateCurrency(Currency currency) => state = state.copyWith(currency: currency);
  void updateType(DebtType type) => state = state.copyWith(type: type);
  void updateImage(String? path) => state = state.copyWith(imagePath: path);

  int _calculateNextRun(RecurringInterval interval) {
    final now = DateTime.now();
    switch (interval) {
      case RecurringInterval.daily: return now.add(const Duration(days: 1)).millisecondsSinceEpoch;
      case RecurringInterval.weekly: return now.add(const Duration(days: 7)).millisecondsSinceEpoch;
      case RecurringInterval.monthly:
        final nextMonth = now.month == 12 ? DateTime(now.year + 1, 1, 1) : DateTime(now.year, now.month + 1, 1);
        final lastDay = DateTime(nextMonth.year, nextMonth.month + 1, 0).day;
        final currentLastDay = DateTime(now.year, now.month + 1, 0).day;
        final day = now.day == currentLastDay ? lastDay : (now.day > lastDay ? lastDay : now.day);
        return DateTime(nextMonth.year, nextMonth.month, day, now.hour, now.minute).millisecondsSinceEpoch;
    }
  }

  Future<bool> saveTransaction(BuildContext context, {required bool isRecurring, required RecurringInterval recurringInterval}) async {
    if (state.customerName.trim().isEmpty) { state = state.copyWith(error: 'يرجى إدخال اسم العميل'); return false; }
    if (state.amount.trim().isEmpty) { state = state.copyWith(error: 'يرجى إدخال المبلغ'); return false; }
    final amountValue = double.tryParse(state.amount);
    if (amountValue == null || amountValue <= 0 || !MoneyValidator.hasAtMostTwoDecimals(amountValue)) { state = state.copyWith(error: 'المبلغ يجب أن يكون أكبر من صفر وبحد أقصى منزلتين عشريتين'); return false; }

    state = state.copyWith(isLoading: true, error: null);
    String? savedAttachmentPath;
    try {
      final customerCount = await _customerRepo.countActiveCustomers();
      final matches = state.customerId != null
          ? <Customer>[]
          : await _findCustomersByName(state.customerName.trim(), includeArchived: true);
      Customer? existingCustomer = state.customerId == null
          ? null
          : await _customerRepo.getCustomerById(state.customerId!);
      if (existingCustomer != null) {
        // The caller supplied the immutable database identity; never resolve by display name.
      } else if (matches.length == 1) {
        existingCustomer = matches.first;
      } else if (matches.length > 1) {
        if (!context.mounted) { state = state.copyWith(isLoading: false); return false; }
        final selected = await showDialog<Customer>(
          context: context,
          builder: (_) => SimpleDialog(
            title: const Text('يوجد أكثر من عميل بهذا الاسم'),
            children: matches.map((c) => SimpleDialogOption(onPressed: () => Navigator.pop(context, c), child: Text('${c.name}${c.phone == null ? '' : ' — ${c.phone}'}'))).toList(),
          ),
        );
        if (selected == null) { state = state.copyWith(isLoading: false); return false; }
        existingCustomer = selected;
      }
      if (existingCustomer?.isArchived == true) {
        if (!context.mounted) return false;
        final restore = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('العميل مؤرشف'),
            content: const Text('يوجد عميل مؤرشف بهذا الاسم. هل تريد استعادته بدل إنشاء عميل جديد؟'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إنشاء جديد')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('استعادة العميل')),
            ],
          ),
        );
        if (restore == true) {
          final archivedId = existingCustomer!.id!;
          await CustomerService.restoreCustomer(archivedId);
          existingCustomer = await _customerRepo.getCustomerById(archivedId);
        } else {
          existingCustomer = null;
        }
      }
      if (existingCustomer == null) {
        final canAdd = await ActivationService.canAddCustomer(customerCount);
        if (!canAdd) {
          if (context.mounted) {
            await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ActivationScreen(currentCustomerCount: customerCount, onActivated: () => _retryAfterActivation(context, isRecurring, recurringInterval))));
          }
          state = state.copyWith(isLoading: false, error: 'لقد وصلت إلى الحد الأقصى للعملاء المجانيين (30 عميلاً). يرجى التفعيل.');
          return false;
        }
      }

      final sourceImagePath = state.imagePath;
      final now = DateTime.now().millisecondsSinceEpoch;
      final db = await AppDatabase().database;

      // Limit is a user-facing warning, not a hard validation. Check before
      // opening the write transaction and ask for explicit confirmation.
      if (existingCustomer != null) {
        final candidate = DebtTransaction(
          customerId: existingCustomer.id!,
          type: state.type,
          amount: amountValue,
          currency: state.currency,
          details: state.details.trim().isEmpty ? null : state.details.trim(),
          date: state.date.millisecondsSinceEpoch,
          imagePath: null,
          createdAt: now,
          updatedAt: now,
        );
        final warning = await CustomerLimitService.transactionWarning(
          customer: existingCustomer,
          candidate: candidate,
          db: db,
        );
        if (warning != null) {
          if (!context.mounted) {
            state = state.copyWith(isLoading: false);
            return false;
          }
          final proceed = await showDialog<bool>(
            context: context,
            builder: (_) => AlertDialog(
              title: Row(children: [
                Icon(Icons.warning_amber_rounded, color: AppColors.warning),
                const SizedBox(width: 8),
                const Text('تنبيه سقف الحساب'),
              ]),
              content: Text(warning),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: AppColors.warning),
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('متابعة الحفظ'),
                ),
              ],
            ),
          );
          if (proceed != true) {
            state = state.copyWith(isLoading: false);
            return false;
          }
        }
      }

      await db.transaction((txn) async {
        Customer customer;
        if (existingCustomer == null) {
          final newCustomer = Customer(name: state.customerName.trim(), createdAt: now, updatedAt: now);
          final id = await _customerRepo.insertCustomerWithTxn(newCustomer, txn);
          customer = newCustomer.copyWith(id: id);
          existingCustomer = customer;
          await AuditService.logCustomerCreate(customer: customer, txn: txn);
        } else {
          customer = existingCustomer!;
        }

        final transaction = DebtTransaction(customerId: customer.id!, type: state.type, amount: amountValue, currency: state.currency, details: state.details.trim().isEmpty ? null : state.details.trim(), date: state.date.millisecondsSinceEpoch, imagePath: null, createdAt: now, updatedAt: now);

        final transactionId = await _transactionRepo.insertTransactionWithTxn(transaction, txn);
        var storedTransaction = transaction.copyWith(id: transactionId);

        if (sourceImagePath != null && sourceImagePath.isNotEmpty) {
          final relativePath = await _attachmentService.saveAttachment(transactionId, XFile(sourceImagePath));
          savedAttachmentPath = relativePath;
          storedTransaction = storedTransaction.copyWith(imagePath: relativePath);
          final updated = await _transactionRepo.updateTransactionWithTxn(storedTransaction, txn);
          if (updated != 1) throw Exception('تعذر حفظ مرجع المرفق');
        }
        await AuditService.logTransactionCreate(transaction: storedTransaction, txn: txn);

        if (isRecurring) {
          final schedule = RecurringSchedule(customerId: customer.id!, amount: amountValue, currency: state.currency, type: state.type, details: state.details.trim().isEmpty ? null : state.details.trim(), interval: recurringInterval, nextRun: _calculateNextRun(recurringInterval), createdAt: now, updatedAt: now);
          await _recurringRepo.insertScheduleWithTxn(schedule, txn);
        }
      });

      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      // حذف المرفق الذي كُتب قبل فشل معاملة قاعدة البيانات حتى لا يبقى ملف يتيم.
      // يتم حذف الملف المحدد فقط، وليس مجلد المعاملة بالكامل.
      try {
        final candidate = savedAttachmentPath;
        if (candidate != null) await _attachmentService.deleteAttachmentPath(candidate);
      } catch (_) {}
      state = state.copyWith(isLoading: false, error: e.toString());
      return false;
    }
  }

  Future<List<Customer>> _findCustomersByName(String name, {bool includeArchived = false}) async {
    final normalized = name.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
    final customers = await _customerRepo.getCustomers(includeArchived: includeArchived);
    return customers.where((c) => c.name.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ') == normalized).toList();
  }

  Future<void> _retryAfterActivation(BuildContext context, bool isRecurring, RecurringInterval recurringInterval) async => saveTransaction(context, isRecurring: isRecurring, recurringInterval: recurringInterval);

  void reset() => state = AddTransactionState(date: DateTime.now(), currency: _ref.read(settingsProvider).defaultCurrency);
}

final addTransactionProvider = StateNotifierProvider<AddTransactionNotifier, AddTransactionState>((ref) => AddTransactionNotifier(ref));
