import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/core/utils/money_validator.dart';
import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/transaction_service.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';

class TransferTransactionScreen extends StatefulWidget {
  final int? initialCustomerId;
  const TransferTransactionScreen({super.key, this.initialCustomerId});
  @override State<TransferTransactionScreen> createState() => _TransferTransactionScreenState();
}

class _TransferTransactionScreenState extends State<TransferTransactionScreen> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  List<Customer> _customers = [];
  int? _from;
  int? _to;
  Currency _currency = Currency.yer;
  bool _loading = true;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final c = await CustomerRepository().getCustomers();
    if (mounted) {
      setState(() {
        _customers = c;
        _from = widget.initialCustomerId != null && c.any((x) => x.id == widget.initialCustomerId)
            ? widget.initialCustomerId
            : null;
        _loading = false;
      });
    }
  }
  @override void dispose() { _amount.dispose(); _note.dispose(); super.dispose(); }

  Future<void> _save() async {
    final amount = double.tryParse(_amount.text.trim());
    if (_from == null || _to == null) { _msg('اختر العميل المصدر والعميل المستلم'); return; }
    if (amount == null || amount <= 0 || !MoneyValidator.hasAtMostTwoDecimals(amount)) { _msg('المبلغ يجب أن يكون أكبر من صفر وبحد أقصى منزلتين عشريتين'); return; }
    setState(() => _loading = true);
    try {
      final warning = await TransactionService.transferWarning(
        fromCustomerId: _from!,
        amount: amount,
        currency: _currency,
      );
      if (warning != null) {
        if (!mounted) return;
        final proceed = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: Row(children: [
              Icon(Icons.warning_amber_rounded, color: AppColors.warning),
              const SizedBox(width: 8),
              const Text('تنبيه التحويل'),
            ]),
            content: Text(warning),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.warning),
                onPressed: () => Navigator.pop(context, true),
                child: const Text('متابعة التحويل'),
              ),
            ],
          ),
        );
        if (proceed != true) return;
        await TransactionService.transfer(
          fromCustomerId: _from!, toCustomerId: _to!, amount: amount,
          currency: _currency, note: _note.text, allowOverdraft: true,
        );
      } else {
        await TransactionService.transfer(
          fromCustomerId: _from!, toCustomerId: _to!, amount: amount,
          currency: _currency, note: _note.text,
        );
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) { if (mounted) _msg(e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => _loading = false); }
  }
  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override Widget build(BuildContext context) {
    if (_loading && _customers.isEmpty) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('تحويل بين العملاء')),
      body: ListView(padding: const EdgeInsets.all(AppDimensions.paddingLarge), children: [
        DropdownButtonFormField<int>(initialValue: _from, decoration: const InputDecoration(labelText: 'من العميل', border: OutlineInputBorder()), items: _customers.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: _loading ? null : (v) => setState(() => _from = v)),
        const SizedBox(height: 16),
        DropdownButtonFormField<int>(initialValue: _to, decoration: const InputDecoration(labelText: 'إلى العميل', border: OutlineInputBorder()), items: _customers.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: _loading ? null : (v) => setState(() => _to = v)),
        const SizedBox(height: 16),
        TextField(controller: _amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المبلغ', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        Row(
          children: Currency.values.map((c) {
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.all(3),
                child: OutlinedButton(
                  onPressed: _loading ? null : () => setState(() => _currency = c),
                  style: OutlinedButton.styleFrom(
                    backgroundColor: _currency == c ? Theme.of(context).colorScheme.primary : null,
                    foregroundColor: _currency == c ? Colors.white : null,
                  ),
                  child: Text(c.name.toUpperCase()),
                ),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 12),
        TextField(controller: _note, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)', border: OutlineInputBorder())),
        const SizedBox(height: 24),
        FilledButton.icon(onPressed: _loading ? null : _save, icon: const Icon(Icons.swap_horiz), label: const Text('تنفيذ التحويل')),
      ]),
    );
  }
}
