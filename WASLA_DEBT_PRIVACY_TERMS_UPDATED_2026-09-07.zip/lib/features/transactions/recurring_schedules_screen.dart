import 'package:wasla_debt/core/utils/money_validator.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/recurring_schedule.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/recurring_repository.dart';

class RecurringSchedulesScreen extends StatefulWidget {
  const RecurringSchedulesScreen({super.key});
  @override State<RecurringSchedulesScreen> createState() => _RecurringSchedulesScreenState();
}

class _RecurringSchedulesScreenState extends State<RecurringSchedulesScreen> {
  final _repo = RecurringRepository();
  final _customers = CustomerRepository();
  List<RecurringSchedule> _items = [];
  Map<int, String> _names = {};
  bool _loading = true;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final items = await _repo.getAllSchedules();
      final customers = await _customers.getCustomers(includeArchived: true);
      if (mounted) setState(() { _items = items; _names = {for (final c in customers) c.id!: c.name}; _loading = false; });
    } catch (e) {
      if (mounted) { setState(() => _loading = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', '')))); }
    }
  }

  String _interval(RecurringInterval i) => switch (i) { RecurringInterval.daily => 'يومي', RecurringInterval.weekly => 'أسبوعي', RecurringInterval.monthly => 'شهري' };
  String _type(DebtType t) => t == DebtType.credit ? 'له' : 'عليه';

  Future<void> _edit(RecurringSchedule item) async {
    final amount = TextEditingController(text: item.amount.toString());
    final details = TextEditingController(text: item.details ?? '');
    var interval = item.interval;
    final result = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
      title: const Text('تعديل الجدولة'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المبلغ')),
        const SizedBox(height: 12),
        DropdownButtonFormField<RecurringInterval>(initialValue: interval, decoration: const InputDecoration(labelText: 'التكرار'), items: RecurringInterval.values.map((v) => DropdownMenuItem(value: v, child: Text(_interval(v)))).toList(), onChanged: (v) { if (v != null) setLocal(() => interval = v); }),
        const SizedBox(height: 12),
        TextField(controller: details, maxLines: 2, decoration: const InputDecoration(labelText: 'التفاصيل')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () { final v = double.tryParse(amount.text.trim()); if (v == null || v <= 0 || !MoneyValidator.hasAtMostTwoDecimals(v)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('المبلغ يجب أن يكون أكبر من صفر وبحد أقصى منزلتين عشريتين'))); return; } Navigator.pop(context, true); }, child: const Text('حفظ'))],
    )));
    if (result != true) { amount.dispose(); details.dispose(); return; }
    final v = double.parse(amount.text.trim());
    await _repo.updateSchedule(item.copyWith(amount: v, interval: interval, details: details.text.trim().isEmpty ? null : details.text.trim(), updatedAt: DateTime.now().millisecondsSinceEpoch));
    amount.dispose(); details.dispose(); await _load();
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الجدولات المتكررة')),
    body: _loading ? const Center(child: CircularProgressIndicator()) : _items.isEmpty ? const Center(child: Text('لا توجد جدولات متكررة')) : ListView.builder(
      padding: const EdgeInsets.all(AppDimensions.paddingMedium), itemCount: _items.length, itemBuilder: (_, i) { final item = _items[i]; final color = item.type == DebtType.credit ? AppColors.credit : AppColors.debit; return Card(child: ListTile(
        leading: Icon(Icons.repeat, color: item.enabled ? color : AppColors.hint),
        title: Text('${_names[item.customerId] ?? 'عميل #${item.customerId}'} — ${MoneyFormat.amount(item.amount)} ${item.currency.name.toUpperCase()}', style: TextStyle(fontWeight: FontWeight.bold, color: item.enabled ? color : AppColors.hint)),
        subtitle: Text('${_type(item.type)} • ${_interval(item.interval)} • التالي: ${DateFormat('yyyy-MM-dd HH:mm', 'ar').format(DateTime.fromMillisecondsSinceEpoch(item.nextRun))}\n${item.details ?? ''}'), isThreeLine: true,
        trailing: PopupMenuButton<String>(tooltip: 'إجراءات الجدولة', onSelected: (v) async { if (v == 'toggle') { await _repo.toggleSchedule(item.id!, !item.enabled); await _load(); } else if (v == 'edit') { await _edit(item); } else if (v == 'delete') { final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('حذف الجدولة؟'), content: const Text('لن تُنشأ معاملات تلقائية مستقبلية من هذه الجدولة.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف'))])); if (ok == true) { await _repo.deleteSchedule(item.id!); await _load(); } } }, itemBuilder: (_) => [PopupMenuItem(value: 'toggle', child: Text(item.enabled ? 'إيقاف الجدولة' : 'تفعيل الجدولة')), const PopupMenuItem(value: 'edit', child: Text('تعديل')), const PopupMenuItem(value: 'delete', child: Text('حذف'))]),
      )); }),
  );
}
