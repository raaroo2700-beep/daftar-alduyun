import 'package:wasla_debt/core/utils/money_validator.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/transaction_service.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';

class EditTransactionScreen extends StatefulWidget {
  final DebtTransaction transaction;
  const EditTransactionScreen({super.key, required this.transaction});
  @override State<EditTransactionScreen> createState() => _EditTransactionScreenState();
}

class _EditTransactionScreenState extends State<EditTransactionScreen> {
  late final TextEditingController _amount;
  late final TextEditingController _details;
  List<Customer> _customers = [];
  late int _customerId;
  late Currency _currency;
  late DebtType _type;
  late DateTime _date;
  String? _imagePath;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    final t = widget.transaction;
    _amount = TextEditingController(text: t.amount.toString());
    _details = TextEditingController(text: t.details ?? '');
    _customerId = t.customerId; _currency = t.currency; _type = t.type; _date = DateTime.fromMillisecondsSinceEpoch(t.date);
    _loadCustomers();
  }
  Future<void> _loadCustomers() async { final c = await CustomerRepository().getCustomers(); if (mounted) setState(() { _customers = c; _loading = false; }); }
  @override void dispose() { _amount.dispose(); _details.dispose(); super.dispose(); }

  Future<void> _save() async {
    final amount = double.tryParse(_amount.text.trim());
    if (amount == null || amount <= 0 || !MoneyValidator.hasAtMostTwoDecimals(amount)) { _msg('المبلغ يجب أن يكون أكبر من صفر وبحد أقصى منزلتين عشريتين'); return; }
    setState(() => _loading = true);
    try {
      await TransactionService.updateTransaction(transaction: DebtTransaction(id: widget.transaction.id, customerId: _customerId, type: _type, amount: amount, currency: _currency, details: _details.text.trim().isEmpty ? null : _details.text.trim(), date: _date.millisecondsSinceEpoch, imagePath: widget.transaction.imagePath, createdAt: widget.transaction.createdAt, updatedAt: widget.transaction.updatedAt, isArchived: widget.transaction.isArchived), replacementImagePath: _imagePath);
      if (mounted) Navigator.pop(context, true);
    } catch (e) { if (mounted) _msg(e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => _loading = false); }
  }
  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  Widget _choice(String text, bool selected, VoidCallback onTap) => Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 3), child: OutlinedButton(onPressed: _loading ? null : onTap, style: OutlinedButton.styleFrom(backgroundColor: selected ? Theme.of(context).colorScheme.primary : null, foregroundColor: selected ? Colors.white : null), child: Text(text))));

  @override Widget build(BuildContext context) {
    if (_loading && _customers.isEmpty) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(appBar: AppBar(title: const Text('تعديل المعاملة'), actions: [IconButton(tooltip: 'حفظ', onPressed: _loading ? null : _save, icon: const Icon(Icons.save))]), body: ListView(padding: const EdgeInsets.all(AppDimensions.paddingLarge), children: [
      DropdownButtonFormField<int>(initialValue: _customerId, decoration: const InputDecoration(labelText: 'العميل', border: OutlineInputBorder()), items: _customers.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: _loading ? null : (v) { if (v != null) setState(() => _customerId = v); }),
      const SizedBox(height: 16),
      TextField(controller: _amount, enabled: !_loading, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: 'المبلغ (${_currency.name.toUpperCase()})', border: const OutlineInputBorder())),
      const SizedBox(height: 12),
      Row(children: [_choice('له', _type == DebtType.credit, () => setState(() => _type = DebtType.credit)), _choice('عليه', _type == DebtType.debit, () => setState(() => _type = DebtType.debit))]),
      const SizedBox(height: 8),
      Row(children: Currency.values.map((c) => _choice(c.name.toUpperCase(), _currency == c, () => setState(() => _currency = c))).toList()),
      const SizedBox(height: 16),
      TextField(controller: _details, enabled: !_loading, maxLines: 3, decoration: const InputDecoration(labelText: 'التفاصيل', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      ListTile(title: const Text('التاريخ'), subtitle: Text(DateFormat('yyyy-MM-dd', 'ar').format(_date)), onTap: _loading ? null : () async { final d = await showDatePicker(context: context, initialDate: _date, firstDate: DateTime(2020), lastDate: DateTime.now(), locale: const Locale('ar', 'SA')); if (d != null) setState(() => _date = d); }),
      OutlinedButton.icon(onPressed: _loading ? null : () async { final f = await ImagePicker().pickImage(source: ImageSource.gallery); if (f != null) setState(() => _imagePath = f.path); }, icon: const Icon(Icons.attach_file), label: Text(_imagePath == null ? 'استبدال المرفق' : 'تم اختيار مرفق جديد')),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: _loading ? null : _save, icon: const Icon(Icons.save), label: Text(_loading ? 'جاري الحفظ...' : 'حفظ التعديلات')),
    ]));
  }
}
