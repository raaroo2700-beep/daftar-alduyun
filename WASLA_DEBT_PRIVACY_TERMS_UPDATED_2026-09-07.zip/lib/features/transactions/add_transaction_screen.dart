import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/recurring_schedule.dart';
import 'package:wasla_debt/features/transactions/providers/add_transaction_provider.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';

class AddTransactionScreen extends ConsumerStatefulWidget {
  // إصلاح 4.1: اسم عميل اختياري لملء الحقل تلقائيًا عند الإضافة من داخل
  // شاشة تفاصيل عميل محدد.
  final String? initialCustomerName;
  final int? initialCustomerId;

  const AddTransactionScreen({super.key, this.initialCustomerName, this.initialCustomerId});

  @override
  ConsumerState<AddTransactionScreen> createState() =>
      _AddTransactionScreenState();
}

class _AddTransactionScreenState
    extends ConsumerState<AddTransactionScreen> {
final TextEditingController _amountController = TextEditingController();
final TextEditingController _detailsController = TextEditingController();

bool _isRecurring = false;
List<String> _customerNames = [];
RecurringInterval _selectedInterval = RecurringInterval.daily;

@override
void initState() {
super.initState();
CustomerRepository().getCustomers().then((customers) {
  if (mounted) setState(() => _customerNames = customers.map((c) => c.name).toList());
});
// إصلاح 3.1: تصفير حالة الـ provider عند فتح الشاشة. الـ provider ليس
// autoDispose، وdid كانت state.amount/customerName/... تحتفظ بقيم آخر
// جلسة إدخال بينما تظهر حقول النص فارغة — ما يجعل الحفظ يستخدم قيمًا
// قديمة مخفية لا يراها المستخدم.
// ملاحظة: reset() (وupdateCustomerName التابعة لها هنا) تُعدّلان الـ
// provider، ولا يجوز استدعاؤهما أثناء بناء الـ widget tree (initState
// يُنفَّذ أثناء البناء) — لذا أُجِّلتا معًا، بنفس الترتيب الأصلي
// (reset أولاً ثم updateCustomerName)، إلى ما بعد اكتمال الإطار
// الحالي عبر addPostFrameCallback. تعيين _nameController.text يبقى
// فوريًا كما كان لأنه لا يُعدّل أي provider.
WidgetsBinding.instance.addPostFrameCallback((_) {
  ref.read(addTransactionProvider.notifier).reset();
  if (widget.initialCustomerName != null && widget.initialCustomerName!.trim().isNotEmpty) {
    ref.read(addTransactionProvider.notifier).setCustomer(widget.initialCustomerId, widget.initialCustomerName!);
  }
});
_amountController.addListener(() {
ref.read(addTransactionProvider.notifier).updateAmount(_amountController.text);
});
_detailsController.addListener(() {
ref.read(addTransactionProvider.notifier).updateDetails(_detailsController.text);
});
}

@override
void dispose() {
_amountController.dispose();
_detailsController.dispose();
super.dispose();
}

@override
Widget build(BuildContext context) {
final state = ref.watch(addTransactionProvider);
final notifier = ref.read(addTransactionProvider.notifier);

return Scaffold(
appBar: AppBar(
title: const Text('إضافة مبلغ'),
actions: [
if (state.isLoading)
const Padding(
padding: EdgeInsets.all(16),
child: SizedBox(
width: 20,
height: 20,
child: CircularProgressIndicator(
strokeWidth: 2,
color: Colors.white,
),
),
),
],
),
body: Padding(
padding: const EdgeInsets.all(AppDimensions.paddingLarge),
child: SingleChildScrollView(
child: Column(
crossAxisAlignment: CrossAxisAlignment.stretch,
children: [
// اسم العميل
Autocomplete<String>(
  initialValue: TextEditingValue(text: widget.initialCustomerName ?? ''),
  optionsBuilder: (value) {
    if (widget.initialCustomerId != null) return const Iterable<String>.empty();
    final query = value.text.trim().toLowerCase();
    if (query.isEmpty) return const Iterable<String>.empty();
    final matches = _customerNames.where((name) => name.toLowerCase().contains(query)).take(8).toList();
    final exact = matches.any((name) => name.trim().toLowerCase() == query);
    if (!exact) matches.add('__new__:$query');
    return matches;
  },
  onSelected: (name) {
    notifier.updateCustomerName(name);
  },
  fieldViewBuilder: (context, controller, focusNode, onSubmitted) {
    final fixedCustomer = widget.initialCustomerId != null;
    return TextField(
      controller: controller,
      focusNode: focusNode,
      readOnly: fixedCustomer,
      decoration: const InputDecoration(
        labelText: 'اسم العميل',
        hintText: 'اكتب اسم العميل لرؤية الاقتراحات',
        suffixIcon: Icon(Icons.person_search_outlined),
      ),
      onChanged: fixedCustomer ? null : notifier.updateCustomerName,
    );
  },
  optionsViewBuilder: (context, onSelected, options) => Align(
    alignment: Alignment.topLeft,
    child: Material(
      elevation: 4,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 240, minWidth: 280),
        child: ListView.builder(
          padding: EdgeInsets.zero,
          shrinkWrap: true,
          itemCount: options.length,
          itemBuilder: (_, i) {
            final name = options.elementAt(i);
            final isNew = name.startsWith('__new__:');
            final display = isNew ? name.substring('__new__:'.length) : name;
            return ListTile(
              leading: Icon(isNew ? Icons.person_add_alt_1 : Icons.person_outline),
              title: Text(isNew ? 'إضافة عميل جديد باسم «$display»' : display),
              onTap: () => onSelected(display),
            );
          },
        ),
      ),
    ),
  ),
),
const SizedBox(height: 16),

// المبلغ
TextField(
controller: _amountController,
decoration: InputDecoration(
labelText: 'المبلغ',
hintText: '0.00',
prefixText: _currencyLabel(state.currency),
),
keyboardType: const TextInputType.numberWithOptions(decimal: true),
),
const SizedBox(height: 16),

// التفاصيل
TextField(
controller: _detailsController,
decoration: const InputDecoration(
labelText: 'التفاصيل (اختياري)',
hintText: 'أضف تفاصيل إضافية',
),
maxLines: 2,
),
const SizedBox(height: 16),

// التاريخ
Row(
children: [
Expanded(
child: InkWell(
onTap: () async {
final date = await showDatePicker(
context: context,
initialDate: state.date,
firstDate: DateTime(2020),
lastDate: DateTime.now(),
locale: const Locale('ar', 'SA'),
);
if (!context.mounted) return;
if (date != null) {
notifier.updateDate(date);
}
},
child: InputDecorator(
decoration: const InputDecoration(
labelText: 'التاريخ',
border: OutlineInputBorder(),
),
child: Text(
DateFormat('yyyy-MM-dd', 'ar').format(state.date),
style: const TextStyle(fontSize: 16),
),
),
),
),
const SizedBox(width: 12),
IconButton(
tooltip: 'إضافة صورة للمرفق',
icon: const Icon(Icons.camera_alt),
onPressed: () async {
final picker = ImagePicker();
final image = await picker.pickImage(source: ImageSource.gallery);
if (!context.mounted) return;
if (image != null) {
notifier.updateImage(image.path);
}
},
),
],
),
const SizedBox(height: 16),

// العملات
Row(
children: [
Expanded(
child: _CurrencyButton(
label: 'محلي',
currency: Currency.yer,
selected: state.currency == Currency.yer,
onTap: () => notifier.updateCurrency(Currency.yer),
),
),
const SizedBox(width: 8),
Expanded(
child: _CurrencyButton(
label: 'دولار',
currency: Currency.usd,
selected: state.currency == Currency.usd,
onTap: () => notifier.updateCurrency(Currency.usd),
),
),
const SizedBox(width: 8),
Expanded(
child: _CurrencyButton(
label: 'سعودي',
currency: Currency.sar,
selected: state.currency == Currency.sar,
onTap: () => notifier.updateCurrency(Currency.sar),
),
),
],
),
const SizedBox(height: 16),

// نوع العملية (له / عليه)
Row(
children: [
Expanded(
child: _TypeButton(
label: 'له',
type: DebtType.credit,
selected: state.type == DebtType.credit,
onTap: () => notifier.updateType(DebtType.credit),
),
),
const SizedBox(width: 8),
Expanded(
child: _TypeButton(
label: 'عليه',
type: DebtType.debit,
selected: state.type == DebtType.debit,
onTap: () => notifier.updateType(DebtType.debit),
),
),
],
),
const SizedBox(height: 24),
  // ✅ التكرار التلقائي
  Row(
    children: [
      const Text('تكرار تلقائي'),
      const SizedBox(width: 12),
      Switch(
        value: _isRecurring,
        onChanged: (val) => setState(() => _isRecurring = val),
      ),
      if (_isRecurring) ...[
        const SizedBox(width: 12),
        DropdownButton<RecurringInterval>(
          value: _selectedInterval,
          items: RecurringInterval.values.map((interval) {
            return DropdownMenuItem(
              value: interval,
              child: Text(interval.name),
            );
          }).toList(),
          onChanged: (val) {
            if (val != null) setState(() => _selectedInterval = val);
          },
        ),
      ],
    ],
  ),
  const SizedBox(height: 16),

  // زر الحفظ
  ElevatedButton(
    onPressed: state.isLoading
        ? null
        : () async {
      final success = await notifier.saveTransaction(
        context,
        isRecurring: _isRecurring,
        recurringInterval: _selectedInterval,
      );
      if (!context.mounted) return;
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تمت إضافة العملية بنجاح')),
        );
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(state.error ?? 'حدث خطأ')),
        );
      }
    },
    style: ElevatedButton.styleFrom(
      padding: const EdgeInsets.symmetric(vertical: 16),
    ),
    child: Text(
      state.isLoading ? 'جاري الحفظ...' : 'حفظ',
      style: const TextStyle(fontSize: 18),
    ),
  ),

  if (state.error != null) ...[
    const SizedBox(height: 12),
    Text(
      state.error!,
      style: const TextStyle(color: Colors.red),
      textAlign: TextAlign.center,
    ),
  ],
],
),
),
),
);
}
}

String _currencyLabel(Currency currency) {
  switch (currency) {
    case Currency.yer: return 'ر.ي ';
    case Currency.sar: return 'ر.س ';
    case Currency.usd: return '\$ ';
  }
}

// أزرار العملات
class _CurrencyButton extends StatelessWidget {
  final String label;
  final Currency currency;
  final bool selected;
  final VoidCallback onTap;

  const _CurrencyButton({
    required this.label,
    required this.currency,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.surface,
          borderRadius: BorderRadius.circular(AppDimensions.radiusMedium),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.divider,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : AppColors.text,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }
}

// أزرار له / عليه
class _TypeButton extends StatelessWidget {
final String label;
final DebtType type;
final bool selected;
final VoidCallback onTap;
const _TypeButton({
  required this.label,
  required this.type,
  required this.selected,
  required this.onTap,
});

@override
Widget build(BuildContext context) {
  final Color color = type == DebtType.credit ? AppColors.credit : AppColors.debit;
  return InkWell(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: selected ? color : Colors.transparent,
        borderRadius: BorderRadius.circular(AppDimensions.radiusMedium),
        border: Border.all(
          color: selected ? color : AppColors.divider,
        ),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : AppColors.text,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    ),
  );
}
}