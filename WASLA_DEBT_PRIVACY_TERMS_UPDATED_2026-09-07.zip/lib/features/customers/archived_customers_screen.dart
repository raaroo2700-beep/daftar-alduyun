import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/customer_service.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'edit_customer_screen.dart';

class ArchivedCustomersScreen extends StatefulWidget {
  const ArchivedCustomersScreen({super.key});

  @override
  State<ArchivedCustomersScreen> createState() => _ArchivedCustomersScreenState();
}

class _ArchivedCustomersScreenState extends State<ArchivedCustomersScreen> {
  final _repo = CustomerRepository();
  List<Customer> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() => _loading = true);
    }
    final items = await _repo.getCustomers(includeArchived: true);
    if (!mounted) return;
    setState(() {
      _items = items.where((c) => c.isArchived).toList();
      _loading = false;
    });
  }

  Future<void> _restore(Customer customer) async {
    try {
      await CustomerService.restoreCustomer(customer.id!);
      if (!mounted) return;
      await _load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر استعادة العميل: ${e.toString().replaceFirst('Exception: ', '')}')),
      );
    }
  }

  Future<void> _deletePermanently(Customer customer) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('حذف نهائي؟'),
        content: const Text(
          'سيحذف العميل وكل معاملاته وسداداته وجدولاته المتكررة ولا يمكن التراجع.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حذف نهائي'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    try {
      await CustomerService.deleteCustomer(customer.id!);
      if (!mounted) return;
      await _load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _edit(Customer customer) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditCustomerScreen(customer: customer)),
    );
    if (!mounted) return;
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('العملاء المؤرشفون')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(
                  child: Text(
                    'لا يوجد عملاء مؤرشفون',
                    style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w600),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(AppDimensions.paddingMedium),
                  itemCount: _items.length,
                  itemBuilder: (context, index) {
                    final customer = _items[index];
                    return Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        leading: CircleAvatar(
                          backgroundColor: AppColors.primary.withValues(alpha: .10),
                          child: Text(
                            customer.name.trim().isEmpty ? '?' : customer.name.trim()[0].toUpperCase(),
                            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800),
                          ),
                        ),
                        title: Text(
                          customer.name,
                          style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text(
                          customer.phone ?? 'لا يوجد رقم',
                          style: const TextStyle(color: AppColors.textSecondary),
                        ),
                        onTap: () async {
                          await _edit(customer);
                        },
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'restore') {
                              _restore(customer);
                            } else if (value == 'delete') {
                              _deletePermanently(customer);
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                              value: 'restore',
                              child: Text('استعادة العميل'),
                            ),
                            PopupMenuItem(
                              value: 'delete',
                              child: Text('حذف نهائي'),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
