import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/customer_service.dart';
import 'package:wasla_debt/core/services/export_service.dart';
import 'package:wasla_debt/core/services/payment_service.dart';
import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/features/customers/edit_customer_screen.dart';
import 'package:wasla_debt/features/customers/archived_transactions_screen.dart';
import 'package:wasla_debt/features/customers/providers/customer_details_provider.dart';
import 'package:wasla_debt/features/payments/add_payment_screen.dart';
import 'package:wasla_debt/features/payments/edit_payment_screen.dart';
import 'package:wasla_debt/features/settings/providers/settings_provider.dart';
import 'package:wasla_debt/features/transactions/add_transaction_screen.dart';
import 'package:wasla_debt/features/transactions/edit_transaction_screen.dart';
import 'package:wasla_debt/features/transactions/transfer_transaction_screen.dart';

class CustomerDetailsScreen extends ConsumerWidget {
  final int customerId;
  const CustomerDetailsScreen({super.key, required this.customerId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(customerDetailsProvider(customerId));
    final notifier = ref.read(customerDetailsProvider(customerId).notifier);
    final customer = state.customer;
    return Scaffold(
      appBar: AppBar(
        title: Text(customer?.name ?? 'العميل'),
        actions: [
          IconButton(tooltip: 'تعديل العميل', icon: const Icon(Icons.edit), onPressed: customer == null ? null : () async { final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => EditCustomerScreen(customer: customer))); if (ok == true) await notifier.loadCustomerDetails(customerId); }),
          PopupMenuButton<String>(
            onSelected: (value) async {
              try {
                if (value == 'archived_transactions') {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => ArchivedTransactionsScreen(customerId: customerId)));
                  return;
                }
                if (value == 'archive') {
                  final confirmed = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('أرشفة العميل؟'),
                      content: const Text('سيتم نقل العميل إلى العملاء المؤرشفين ولن تظهر معاملاته في القائمة الرئيسية.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('أرشفة')),
                      ],
                    ),
                  );
                  if (confirmed != true) return;
                  await CustomerService.archiveCustomer(customerId);
                  if (context.mounted) Navigator.pop(context, true);
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
                  );
                }
              }
            },
            itemBuilder: (_) => [const PopupMenuItem(value: 'archive', child: Text('أرشفة العميل')), const PopupMenuItem(value: 'archived_transactions', child: Text('المعاملات المؤرشفة'))],
          ),
          IconButton(tooltip: 'تصدير PDF', icon: const Icon(Icons.picture_as_pdf), onPressed: customer == null ? null : () async { final path = await ExportService.generatePDF(customer: customer, transactions: state.transactions, balances: state.balances, payments: state.payments); if (context.mounted) await ExportService.shareFile(path, message: 'كشف حساب ${customer.name}'); }),
          IconButton(tooltip: 'تصدير Excel', icon: const Icon(Icons.table_chart), onPressed: customer == null ? null : () async { final path = await ExportService.generateExcel(customer: customer, transactions: state.transactions, balances: state.balances, payments: state.payments); if (context.mounted) await ExportService.shareFile(path, message: 'كشف حساب ${customer.name}'); }),
          IconButton(tooltip: 'إضافة معاملة', icon: const Icon(Icons.add), onPressed: customer == null ? null : () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => AddTransactionScreen(initialCustomerName: customer.name, initialCustomerId: customer.id))); await notifier.loadCustomerDetails(customerId); }),
          IconButton(tooltip: 'إضافة سداد', icon: const Icon(Icons.payments), onPressed: customer == null ? null : () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => AddPaymentScreen(initialCustomerName: customer.name, initialCustomerId: customer.id))); await notifier.loadCustomerDetails(customerId); }),
          IconButton(
            tooltip: 'تحويل إلى عميل',
            icon: const Icon(Icons.swap_horiz),
            onPressed: customer == null ? null : () async {
              await Navigator.push(context, MaterialPageRoute(
                builder: (_) => TransferTransactionScreen(initialCustomerId: customerId),
              ));
              await notifier.loadCustomerDetails(customerId);
            },
          ),
        ],
      ),
      body: state.isLoading ? const Center(child: CircularProgressIndicator()) : state.error != null ? Center(child: Text('خطأ: ${state.error}')) : customer == null ? const Center(child: Text('العميل غير موجود')) : Column(
        children: [
          Builder(builder: (context) {
            final used = Currency.values.where((c) =>
                state.transactions.any((t) => t.currency == c) ||
                state.payments.any((p) => p.currency == c)).toList();
            if (used.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Text('لا توجد أرصدة لهذا العميل'),
              );
            }
            return Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: used.map((c) => Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: ChoiceChip(
                    label: Text(c.name.toUpperCase()),
                    selected: state.selectedCurrency == c,
                    onSelected: (_) => notifier.selectCurrency(c),
                    selectedColor: AppColors.primary,
                    labelStyle: TextStyle(
                      color: state.selectedCurrency == c ? Colors.white : AppColors.text,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                    side: BorderSide(
                      color: state.selectedCurrency == c ? AppColors.primary : AppColors.divider,
                    ),
                  ),
                )).toList()),
              ),
            );
          }),
          Builder(builder: (context) {
            final currency = state.selectedCurrency;
            final filteredTransactions = currency == null
                ? state.transactions
                : state.transactions.where((t) => t.currency == currency).toList();
            final filteredPayments = currency == null
                ? state.payments
                : state.payments.where((p) => p.currency == currency).toList();
            final balance = currency == null ? null : state.balances[currency];
            return Expanded(
              child: Column(children: [
                if (balance != null) CustomerBalanceCard(balances: {currency!: balance}),
                if (balance != null && _limitExceededForCurrency(customer, balance))
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.warningSoft,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text('تنبيه: الرصيد تجاوز السقف المحدد لهذه العملة',
                        style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.bold)),
                    ),
                  ),
                const Divider(),
                const Align(alignment: Alignment.centerRight, child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Text('المعاملات', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                )),
                Expanded(flex: 3, child: filteredTransactions.isEmpty
                  ? const Center(child: Text('لا توجد معاملات بهذه العملة'))
                  : ListView.builder(
                    itemCount: filteredTransactions.length,
                    itemBuilder: (_, i) {
                      final t = filteredTransactions[i];
                      return TransactionListItem(
                        transaction: t,
                        onEdit: () async {
                          final ok = await Navigator.push<bool>(context, MaterialPageRoute(
                            builder: (_) => EditTransactionScreen(transaction: t),
                          ));
                          if (ok == true) await notifier.loadCustomerDetails(customerId);
                        },
                        onArchive: () async {
                          final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('أرشفة المعاملة؟'), content: const Text('يمكن استعادتها لاحقًا من المعاملات المؤرشفة.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('أرشفة'))]));
                          if (ok == true) await notifier.archiveTransaction(t.id!);
                        },
                      );
                    },
                  )),
                const Divider(),
                const Align(alignment: Alignment.centerRight, child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Text('السدادات', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                )),
                Expanded(flex: 2, child: filteredPayments.isEmpty
                  ? const Center(child: Text('لا توجد سدادات بهذه العملة'))
                  : ListView.builder(
                    itemCount: filteredPayments.length,
                    itemBuilder: (_, i) {
                      final p = filteredPayments[i];
                      return PaymentTile(
                        payment: p,
                        onEdit: () async {
                          final ok = await Navigator.push<bool>(context, MaterialPageRoute(
                            builder: (_) => EditPaymentScreen(payment: p),
                          ));
                          if (ok == true) await notifier.loadCustomerDetails(customerId);
                        },
                        onDelete: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('حذف السداد؟'),
                              content: const Text('سيؤثر حذف السداد على الرصيد الحالي.'),
                              actions: [
                                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                                FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
                              ],
                            ),
                          );
                          if (ok == true) {
                            await PaymentService.deletePayment(p.id!);
                            await notifier.loadCustomerDetails(customerId);
                          }
                        },
                      );
                    },
                  )),
              ]),
            );
          }),
        ],
      ),
    );
  }

  static bool _limitExceededForCurrency(Customer customer, BalanceResult b) {
    final limit = b.isDebtor
        ? customer.debtLimitFor(b.currency)
        : customer.creditLimitFor(b.currency);
    return limit != null && b.balance.abs() > limit;
  }
}

class CustomerBalanceCard extends StatelessWidget {
  final Map<Currency, BalanceResult> balances;
  const CustomerBalanceCard({super.key, required this.balances});
  @override Widget build(BuildContext context) => Card(margin: const EdgeInsets.all(AppDimensions.paddingMedium), child: Padding(padding: const EdgeInsets.all(AppDimensions.paddingMedium), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('الرصيد', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8), Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: balances.entries.map((entry) { final c = entry.key; final amount = entry.value.balance; final color = amount > 0 ? AppColors.debit : amount < 0 ? AppColors.credit : AppColors.hint; return Column(children: [Text(c.name.toUpperCase()), Text('${MoneyFormat.amount(amount)} ${c == Currency.usd ? '\$' : c == Currency.sar ? 'ر.س' : 'ريال'}', style: TextStyle(color: color, fontWeight: FontWeight.bold))]); }).toList())])));
}

class TransactionListItem extends ConsumerWidget {
  final DebtTransaction transaction;
  final VoidCallback onEdit;
  final VoidCallback onArchive;
  const TransactionListItem({super.key, required this.transaction, required this.onEdit, required this.onArchive});
  @override Widget build(BuildContext context, WidgetRef ref) { final color = transaction.type == DebtType.credit ? AppColors.credit : AppColors.debit; final showTime = ref.watch(settingsProvider).showTime; return Card(margin: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingMedium, vertical: 4), child: ListTile(leading: CircleAvatar(backgroundColor: color.withValues(alpha: .15), child: Text(transaction.type == DebtType.credit ? 'له' : 'عليه', style: TextStyle(color: color))), title: Text('${MoneyFormat.amount(transaction.amount)} ${transaction.currency.name.toUpperCase()}', style: TextStyle(color: color, fontWeight: FontWeight.bold)), subtitle: Text(transaction.details ?? 'لا توجد تفاصيل'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text(DateFormat(showTime ? 'yyyy-MM-dd HH:mm' : 'yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(transaction.date)), style: const TextStyle(fontSize: 10)), IconButton(tooltip: 'تعديل المعاملة', icon: const Icon(Icons.edit, size: 20), onPressed: onEdit), IconButton(tooltip: 'أرشفة المعاملة', icon: const Icon(Icons.archive_outlined, color: AppColors.archive, size: 20), onPressed: onArchive)]))); }
}

class PaymentTile extends ConsumerWidget {
  final Payment payment;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const PaymentTile({super.key, required this.payment, required this.onEdit, required this.onDelete});
  @override Widget build(BuildContext context, WidgetRef ref) { final showTime = ref.watch(settingsProvider).showTime; return Card(margin: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingMedium, vertical: 4), child: ListTile(leading: Icon(payment.direction == PaymentDirection.customerToBusiness ? Icons.south_west : Icons.north_east, color: payment.direction == PaymentDirection.customerToBusiness ? AppColors.credit : AppColors.debit), title: Text('${MoneyFormat.amount(payment.amount)} ${payment.currency.name.toUpperCase()}', style: TextStyle(color: payment.direction == PaymentDirection.customerToBusiness ? AppColors.credit : AppColors.debit, fontWeight: FontWeight.bold)), subtitle: Text('${payment.direction == PaymentDirection.customerToBusiness ? 'دفع لي' : 'دفعت له'}${payment.note == null ? '' : ' — ${payment.note}'}'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text(DateFormat(showTime ? 'yyyy-MM-dd HH:mm' : 'yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(payment.paymentDate)), style: const TextStyle(fontSize: 10)), IconButton(tooltip: 'تعديل السداد', icon: const Icon(Icons.edit, size: 20), onPressed: onEdit), IconButton(tooltip: 'حذف السداد', icon: const Icon(Icons.delete_outline, color: AppColors.debit, size: 20), onPressed: onDelete)]))); }
}
