import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/transaction_restore_service.dart';
import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

class ArchivedTransactionsScreen extends StatefulWidget {
  final int customerId;
  const ArchivedTransactionsScreen({super.key, required this.customerId});

  @override
  State<ArchivedTransactionsScreen> createState() =>
      _ArchivedTransactionsScreenState();
}

class _ArchivedTransactionsScreenState
    extends State<ArchivedTransactionsScreen> {
  final _repo = TransactionRepository();
  final _customers = CustomerRepository();
  List<DebtTransaction> _items = [];
  String _title = 'المعاملات المؤرشفة';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    try {
      final customer = await _customers.getCustomerById(widget.customerId);
      final all = await _repo.getTransactionsByCustomer(
        widget.customerId,
        includeArchived: true,
      );
      if (!mounted) return;
      setState(() {
        _title = customer == null
            ? _title
            : 'المعاملات المؤرشفة — ${customer.name}';
        _items = all.where((t) => t.isArchived).toList();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      final message = e.toString().replaceFirst('Exception: ', '');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  Future<void> _restore(DebtTransaction transaction) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('استعادة المعاملة؟'),
        content: const Text(
          'ستعود المعاملة إلى سجل العميل النشط وسيؤثر ذلك على الرصيد.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('استعادة'),
          ),
        ],
      ),
    );
    if (!mounted || confirmed != true || transaction.id == null) return;

    try {
      await TransactionRestoreService.restoreTransaction(transaction.id!);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت استعادة المعاملة')),
      );
      await _load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_title)),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('لا توجد معاملات مؤرشفة'))
              : ListView.builder(
                  padding:
                      const EdgeInsets.all(AppDimensions.paddingMedium),
                  itemCount: _items.length,
                  itemBuilder: (context, i) {
                    final t = _items[i];
                    final color = t.type == DebtType.credit
                        ? AppColors.credit
                        : AppColors.debit;
                    return Card(
                      child: ListTile(
                        leading: Icon(
                          t.type == DebtType.credit
                              ? Icons.arrow_upward
                              : Icons.arrow_downward,
                          color: color,
                        ),
                        title: Text(
                          '${MoneyFormat.amount(t.amount)} ${t.currency.name.toUpperCase()}',
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          '${t.details ?? 'لا توجد تفاصيل'}\n${DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(t.date))}',
                        ),
                        isThreeLine: true,
                        trailing: FilledButton.icon(
                          onPressed: () => _restore(t),
                          icon: const Icon(Icons.restore),
                          label: const Text('استعادة'),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
