import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/customer_service.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';

class EditCustomerScreen extends StatefulWidget {
  final Customer customer;

  const EditCustomerScreen({super.key, required this.customer});

  @override
  State<EditCustomerScreen> createState() => _EditCustomerScreenState();
}

class _EditCustomerScreenState extends State<EditCustomerScreen> {
  late final TextEditingController _nameController;
  late final TextEditingController _phoneController;
  late final TextEditingController _noteController;
  late final Map<Currency, TextEditingController> _debtLimits;
  late final Map<Currency, TextEditingController> _creditLimits;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.customer.name);
    _phoneController = TextEditingController(text: widget.customer.phone ?? '');
    _noteController = TextEditingController(text: widget.customer.note ?? '');
    _debtLimits = {
      for (final c in Currency.values)
        c: TextEditingController(text: widget.customer.debtLimitFor(c)?.toString() ?? ''),
    };
    _creditLimits = {
      for (final c in Currency.values)
        c: TextEditingController(text: widget.customer.creditLimitFor(c)?.toString() ?? ''),
    };
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _noteController.dispose();
    for (final c in Currency.values) { _debtLimits[c]!.dispose(); _creditLimits[c]!.dispose(); }
    super.dispose();
  }

  Future<void> _save() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اسم العميل مطلوب')),
      );
      return;
    }

    double? parse(TextEditingController c) => c.text.trim().isEmpty ? null : double.tryParse(c.text.trim());
    final debt = {for (final c in Currency.values) c: parse(_debtLimits[c]!)};
    final credit = {for (final c in Currency.values) c: parse(_creditLimits[c]!)};
    final invalid = [...debt.values, ...credit.values].any((v) => v != null && v < 0);
    final invalidText = [..._debtLimits.values, ..._creditLimits.values]
        .any((c) => c.text.trim().isNotEmpty && parse(c) == null);
    if (invalid || invalidText) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سقوف الحساب يجب أن تكون أرقامًا موجبة أو فارغة')));
      return;
    }
    setState(() => _saving = true);
    try {
      await CustomerService.updateCustomer(
        Customer(
          id: widget.customer.id,
          name: name,
          phone: _phoneController.text.trim().isEmpty ? null : _phoneController.text.trim(),
          note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
          debtLimit: null,
          creditLimit: null,
          debtLimitYer: debt[Currency.yer],
          debtLimitSar: debt[Currency.sar],
          debtLimitUsd: debt[Currency.usd],
          creditLimitYer: credit[Currency.yer],
          creditLimitSar: credit[Currency.sar],
          creditLimitUsd: credit[Currency.usd],
          createdAt: widget.customer.createdAt,
          updatedAt: widget.customer.updatedAt,
          isArchived: widget.customer.isArchived,
        ),
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تعديل العميل: $e')),
      );
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تعديل العميل'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save_outlined),
            tooltip: 'حفظ',
            onPressed: _saving ? null : _save,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingLarge),
        children: [
          TextField(
            controller: _nameController,
            enabled: !_saving,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'اسم العميل *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _phoneController,
            enabled: !_saving,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'رقم الهاتف',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _noteController,
            enabled: !_saving,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'ملاحظات',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          const Text('سقف الحساب لكل عملة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          ...Currency.values.map((c) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(children: [
              SizedBox(width: 52, child: Text(c.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w700))),
              Expanded(child: TextField(
                controller: _debtLimits[c], enabled: !_saving,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'سقف عليه', hintText: 'بلا سقف', border: OutlineInputBorder()),
              )),
              const SizedBox(width: 8),
              Expanded(child: TextField(
                controller: _creditLimits[c], enabled: !_saving,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'سقف له', hintText: 'بلا سقف', border: OutlineInputBorder()),
              )),
            ]),
          )),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save_outlined),
            label: Text(_saving ? 'جاري الحفظ...' : 'حفظ التعديلات'),
          ),
        ],
      ),
    );
  }
}
