import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wasla_debt/core/services/archive_service.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/payment_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

/// حالة شاشة تفاصيل العميل (Task P0-01، مُحدَّثة في P0-02 الخطوة 9
/// لتضمين سدادات العميل).
const _StateUnset _unset = _StateUnset();
class _StateUnset { const _StateUnset(); }

class CustomerDetailsState {
  final Customer? customer;
  final List<DebtTransaction> transactions;
  final List<Payment> payments;
  final bool isLoading;
  final String? error;
  final Map<Currency, BalanceResult> balances;
  final Currency? selectedCurrency;

  CustomerDetailsState({
    this.customer,
    this.transactions = const [],
    this.payments = const [],
    this.isLoading = false,
    this.error,
    this.balances = const {},
    this.selectedCurrency,
  });

  CustomerDetailsState copyWith({
    Customer? customer,
    List<DebtTransaction>? transactions,
    List<Payment>? payments,
    bool? isLoading,
    Object? error = _unset,
    Map<Currency, BalanceResult>? balances,
    Currency? selectedCurrency,
  }) {
    return CustomerDetailsState(
      customer: customer ?? this.customer,
      transactions: transactions ?? this.transactions,
      payments: payments ?? this.payments,
      isLoading: isLoading ?? this.isLoading,
      error: identical(error, _unset) ? this.error : error as String?,
      balances: balances ?? this.balances,
      selectedCurrency: selectedCurrency ?? this.selectedCurrency,
    );
  }
}

class CustomerDetailsNotifier extends StateNotifier<CustomerDetailsState> {
  final CustomerRepository _customerRepo = CustomerRepository();
  final TransactionRepository _transactionRepo = TransactionRepository();
  final PaymentRepository _paymentRepo = PaymentRepository();

  CustomerDetailsNotifier() : super(CustomerDetailsState());

  Future<void> loadCustomerDetails(int customerId) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final customer = await _customerRepo.getCustomerById(customerId);
      if (customer == null) {
        state = state.copyWith(isLoading: false, error: 'العميل غير موجود');
        return;
      }

      final transactions = await _transactionRepo.getTransactionsByCustomer(customerId);
      final payments = await _paymentRepo.getPaymentsByCustomer(customerId);
      // BalanceCalculator هو المصدر الوحيد لحساب الرصيد (منطق P0-01) — لا
      // يوجد أي حساب يدوي هنا؛ السدادات تُمرَّر إليه كما هي فقط.
      final balances = BalanceCalculator.calculateClientBalance(
        transactions: transactions,
        payments: payments,
      );

      final usedCurrencies = <Currency>{
        ...transactions.map((t) => t.currency),
        ...payments.map((p) => p.currency),
      };
      final selected = usedCurrencies.contains(state.selectedCurrency)
          ? state.selectedCurrency
          : (usedCurrencies.isNotEmpty ? usedCurrencies.first : null);
      state = state.copyWith(
        customer: customer,
        transactions: transactions,
        payments: payments,
        balances: balances,
        selectedCurrency: selected,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void selectCurrency(Currency? currency) {
    state = state.copyWith(selectedCurrency: currency);
  }

  Future<void> archiveTransaction(int transactionId) async {
    try {
      await ArchiveService.archiveTransaction(
        transactionId: transactionId,
        note: 'أرشفة يدوية من قبل المستخدم',
      );
      // إعادة تحميل البيانات
      if (state.customer != null) {
        await loadCustomerDetails(state.customer!.id!);
      }
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }
}

final customerDetailsProvider = StateNotifierProvider.family
<CustomerDetailsNotifier, CustomerDetailsState, int>((ref, customerId) {
  return CustomerDetailsNotifier()..loadCustomerDetails(customerId);
});