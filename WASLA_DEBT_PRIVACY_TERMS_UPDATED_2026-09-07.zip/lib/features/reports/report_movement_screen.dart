import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/core/services/export_service.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/features/reports/providers/reports_provider.dart';

class ReportMovementScreen extends ConsumerWidget {
  const ReportMovementScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(reportsProvider);
    Future<List<List<String>>> rows() async {
      final result = <List<String>>[];
      for (final c in state.customers) {
        for (final t in state.transactions.where((x) => x.customerId == c.id)) {
          result.add([c.name, DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(t.date)), MoneyFormat.amount(t.amount), t.currency.name.toUpperCase(), t.type == DebtType.credit ? 'له' : 'عليه', t.details ?? '']);
        }
        for (final p in state.payments.where((x) => x.customerId == c.id)) {
          result.add([c.name, DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(p.paymentDate)), MoneyFormat.amount(p.amount), p.currency.name.toUpperCase(), 'سداد', p.note ?? '']);
        }
      }
      return result;
    }
    Future<void> export(bool pdf) async {
      final data = await rows();
      final path = pdf
          ? await ExportService.generateGeneralPDF(title: 'حركة الحساب', headers: const ['العميل','التاريخ','المبلغ','العملة','النوع','التفاصيل'], rows: data)
          : await ExportService.generateGeneralExcel(title: 'حركة الحساب', headers: const ['العميل','التاريخ','المبلغ','العملة','النوع','التفاصيل'], rows: data);
      if (context.mounted) await ExportService.shareFile(path, message: 'حركة الحساب');
    }
    return Scaffold(
      appBar: AppBar(title: const Text('حركة الحساب'), actions: [
        IconButton(tooltip: 'تصدير PDF', icon: const Icon(Icons.picture_as_pdf), onPressed: state.isLoading ? null : () => export(true)),
        IconButton(tooltip: 'تصدير Excel', icon: const Icon(Icons.table_chart), onPressed: state.isLoading ? null : () => export(false)),
      ]),
      body: state.isLoading ? const Center(child: CircularProgressIndicator()) : state.error != null ? Center(child: Text('خطأ: ${state.error}')) : ListView(
        children: state.customers.map((c) {
          final tx = state.transactions.where((x) => x.customerId == c.id).toList();
          final pay = state.payments.where((x) => x.customerId == c.id).toList();
          if (tx.isEmpty && pay.isEmpty) return const SizedBox.shrink();
          return ExpansionTile(
            title: Text(c.name), subtitle: Text('${tx.length} معاملة • ${pay.length} سداد'),
            children: [
              ...tx.map((t) => ListTile(leading: Icon(t.type == DebtType.credit ? Icons.arrow_upward : Icons.arrow_downward, color: t.type == DebtType.credit ? AppColors.credit : AppColors.debit), title: Text('${MoneyFormat.amount(t.amount)} ${t.currency.name.toUpperCase()}'), subtitle: Text(t.details ?? ''), trailing: Text(DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(t.date))))),
              ...pay.map((p) => ListTile(leading: const Icon(Icons.payments, color: AppColors.credit), title: Text('${MoneyFormat.amount(p.amount)} ${p.currency.name.toUpperCase()}'), subtitle: Text(p.note ?? 'سداد'), trailing: Text(DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(p.paymentDate))))),
            ],
          );
        }).toList(),
      ),
    );
  }
}
