import 'package:flutter/material.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/features/reports/report_categories_screen.dart';
import 'package:wasla_debt/features/reports/report_details_screen.dart';
import 'package:wasla_debt/features/reports/report_monthly_screen.dart';
import 'package:wasla_debt/features/reports/report_movement_screen.dart';
import 'package:wasla_debt/features/reports/report_summary_screen.dart';

class ReportsMainScreen extends StatelessWidget {
  const ReportsMainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('التقارير'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingMedium),
        children: [
          _ReportCard(
            icon: Icons.summarize,
            title: 'تقرير إجمالي المبالغ',
            subtitle: 'عرض إجمالي المبالغ لكل عميل ولكل عملة',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ReportSummaryScreen()),
              );
            },
          ),
          _ReportCard(
            icon: Icons.list_alt,
            title: 'تقرير تفاصيل المبالغ',
            subtitle: 'عرض جميع المعاملات بالتفصيل',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ReportDetailsScreen()),
              );
            },
          ),
          _ReportCard(
            icon: Icons.calendar_month,
            title: 'تقرير شهري',
            subtitle: 'عرض الإجماليات حسب الشهر',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ReportMonthlyScreen()),
              );
            },
          ),
          _ReportCard(
            icon: Icons.category,
            title: 'تقرير التصنيفات',
            subtitle: 'عرض إجماليات (له) و (عليه)',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const ReportCategoriesScreen()),
              );
            },
          ),
          _ReportCard(
            icon: Icons.trending_up,
            title: 'تقرير حركة الحساب',
            subtitle: 'عرض حركة كل عميل',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ReportMovementScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _ReportCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ReportCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(icon, size: 32, color: AppColors.primary),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}