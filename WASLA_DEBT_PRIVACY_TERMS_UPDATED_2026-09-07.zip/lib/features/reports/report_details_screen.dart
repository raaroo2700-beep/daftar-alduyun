import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/core/services/export_service.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/features/reports/providers/reports_provider.dart';

class ReportDetailsScreen extends ConsumerWidget {
  const ReportDetailsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(reportsProvider);
    final rows = <List<String>>[
      ...state.transactions.map((t) => [
            DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(t.date)),
            MoneyFormat.amount(t.amount), t.currency.name.toUpperCase(),
            t.type == DebtType.credit ? 'له' : 'عليه', t.details ?? '',
          ]),
      ...state.payments.map((p) => [
            DateFormat('yyyy-MM-dd', 'ar').format(DateTime.fromMillisecondsSinceEpoch(p.paymentDate)),
            MoneyFormat.amount(p.amount), p.currency.name.toUpperCase(), 'سداد', p.note ?? '',
          ]),
    ];
    Future<void> export(bool pdf) async {
      final path = pdf
          ? await ExportService.generateGeneralPDF(title: 'تفاصيل المبالغ', headers: const ['التاريخ','المبلغ','العملة','النوع','التفاصيل'], rows: rows)
          : await ExportService.generateGeneralExcel(title: 'تفاصيل المبالغ', headers: const ['التاريخ','المبلغ','العملة','النوع','التفاصيل'], rows: rows);
      if (context.mounted) await ExportService.shareFile(path, message: 'تفاصيل المبالغ');
    }
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل المبالغ'), actions: [
        IconButton(tooltip: 'تصدير PDF', icon: const Icon(Icons.picture_as_pdf), onPressed: state.isLoading ? null : () => export(true)),
        IconButton(tooltip: 'تصدير Excel', icon: const Icon(Icons.table_chart), onPressed: state.isLoading ? null : () => export(false)),
      ]),
      body: state.isLoading ? const Center(child: CircularProgressIndicator()) : state.error != null ? Center(child: Text('خطأ: ${state.error}')) : rows.isEmpty ? const Center(child: Text('لا توجد بيانات')) : ListView.builder(
        padding: const EdgeInsets.all(AppDimensions.paddingMedium), itemCount: rows.length,
        itemBuilder: (_, i) {
          final r = rows[i]; final isPayment = r[3] == 'سداد';
          final color = isPayment || r[3] == 'له' ? AppColors.credit : AppColors.debit;
          return Card(child: ListTile(
            leading: CircleAvatar(backgroundColor: color.withValues(alpha: .15), child: Text(isPayment ? 'س' : r[3], style: TextStyle(color: color))),
            title: Text('${r[1]} ${r[2]}', style: TextStyle(color: color, fontWeight: FontWeight.bold)),
            subtitle: Text('${r[4]} • ${r[0]}'),
          ));
        },
      ),
    );
  }
}
