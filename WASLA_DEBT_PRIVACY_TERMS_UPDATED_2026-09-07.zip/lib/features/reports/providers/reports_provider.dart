import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/payment_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

const _StateUnset _unset = _StateUnset();
class _StateUnset { const _StateUnset(); }

class ReportsState {
  final List<Customer> customers;
  final List<DebtTransaction> transactions;
  final List<Payment> payments;
  final bool isLoading;
  final String? error;

  ReportsState({
    this.customers = const [],
    this.transactions = const [],
    this.payments = const [],
    this.isLoading = false,
    this.error,
  });

  ReportsState copyWith({
    List<Customer>? customers,
    List<DebtTransaction>? transactions,
    List<Payment>? payments,
    bool? isLoading,
    Object? error = _unset,
  }) {
    return ReportsState(
      customers: customers ?? this.customers,
      transactions: transactions ?? this.transactions,
      payments: payments ?? this.payments,
      isLoading: isLoading ?? this.isLoading,
      error: identical(error, _unset) ? this.error : error as String?,
    );
  }

  // 1. إجمالي المبالغ لكل عميل
  // P0-01: أصبحت تعتمد على BalanceCalculator المركزي (BalanceResult) بدل معادلة محلية.
  // P0-02 خطوة 11: تمرير سدادات العميل بدل الاعتماد على المعاملات فقط.
  Map<int, Map<Currency, BalanceResult>> getCustomerTotals() {
    final Map<int, Map<Currency, BalanceResult>> result = {};
    for (var customer in customers) {
      final customerTransactions =
      transactions.where((t) => t.customerId == customer.id).toList();
      final customerPayments =
      payments.where((p) => p.customerId == customer.id).toList();
      result[customer.id!] = BalanceCalculator.calculateClientBalance(
        transactions: customerTransactions,
        payments: customerPayments,
      );
    }
    return result;
  }

  // الإجمالي الكلي (لكل العملات)
  // P0-01: أصبحت تعتمد على BalanceCalculator المركزي (BalanceResult) بدل معادلة محلية.
  // P0-02 خطوة 11: تمرير كل السدادات.
  Map<Currency, BalanceResult> getGlobalTotals() {
    return BalanceCalculator.calculateTotalBalance(
      transactions: transactions,
      payments: payments,
    );
  }

  // 2. تفاصيل المبالغ (كل المعاملات)
  List<DebtTransaction> getTransactionDetails() {
    final list = List<DebtTransaction>.from(transactions);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  // 3. التقرير الشهري
  // P0-01: أصبحت تعتمد على BalanceCalculator المركزي (BalanceResult) بدل معادلة محلية.
  // P0-02 خطوة 11: تجميع سدادات كل شهر وتمريرها مع معاملاته.
  Map<String, Map<Currency, BalanceResult>> getMonthlyTotals() {
    final Map<String, List<DebtTransaction>> byMonth = {};
    for (var t in transactions) {
      final date = DateTime.fromMillisecondsSinceEpoch(t.date);
      final key = '${date.year}-${date.month.toString().padLeft(2, '0')}';
      byMonth.putIfAbsent(key, () => []).add(t);
    }

    final Map<String, List<Payment>> paymentsByMonth = {};
    for (var p in payments) {
      final date = DateTime.fromMillisecondsSinceEpoch(p.paymentDate);
      final key = '${date.year}-${date.month.toString().padLeft(2, '0')}';
      paymentsByMonth.putIfAbsent(key, () => []).add(p);
    }

    // اتحاد مفاتيح الشهور حتى لا يُفقَد شهر فيه سدادات فقط بلا معاملات.
    final months = <String>{...byMonth.keys, ...paymentsByMonth.keys};

    final Map<String, Map<Currency, BalanceResult>> monthly = {};
    for (var key in months) {
      monthly[key] = BalanceCalculator.calculateTotalBalance(
        transactions: byMonth[key] ?? const [],
        payments: paymentsByMonth[key] ?? const [],
      );
    }
    return monthly;
  }

  // 4. التصنيفات (له / عليه)
  Map<DebtType, Map<Currency, double>> getCategoryTotals() {
    final Map<DebtType, Map<Currency, double>> result = {};
    for (var t in transactions) {
      result.putIfAbsent(t.type, () => {});
      result[t.type]![t.currency] =
          (result[t.type]![t.currency] ?? 0) + t.amount;
    }
    return result;
  }

  // 5. حركة الحساب (لكل عميل)
  Map<Customer, List<DebtTransaction>> getMovement() {
    final Map<Customer, List<DebtTransaction>> movement = {};
    for (var customer in customers) {
      final customerTransactions =
      transactions.where((t) => t.customerId == customer.id).toList();
      if (customerTransactions.isNotEmpty) {
        movement[customer] = customerTransactions
          ..sort((a, b) => b.date.compareTo(a.date));
      }
    }
    return movement;
  }
}

class ReportsNotifier extends StateNotifier<ReportsState> {
final CustomerRepository _customerRepo = CustomerRepository();
final TransactionRepository _transactionRepo = TransactionRepository();
final PaymentRepository _paymentRepo = PaymentRepository();

ReportsNotifier() : super(ReportsState());

Future<void> loadData() async {
  state = state.copyWith(isLoading: true, error: null);
  try {
    final customers = await _customerRepo.getCustomers();
    final activeIds = customers.map((c) => c.id).whereType<int>().toSet();
    final transactions = (await _transactionRepo.getAllTransactions(includeArchived: false)).where((t) => activeIds.contains(t.customerId)).toList();
    final payments = (await _paymentRepo.getAllPayments()).where((p) => activeIds.contains(p.customerId)).toList();
    state = state.copyWith(
      customers: customers,
      transactions: transactions,
      payments: payments,
      isLoading: false,
    );
  } catch (e) {
    state = state.copyWith(isLoading: false, error: e.toString());
  }
}
}

final reportsProvider =
StateNotifierProvider<ReportsNotifier, ReportsState>((ref) {
  return ReportsNotifier()..loadData();
});
