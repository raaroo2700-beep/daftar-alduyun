import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/features/reports/providers/reports_provider.dart';
import 'package:wasla_debt/core/services/export_service.dart';

class ReportCategoriesScreen extends ConsumerWidget {
  const ReportCategoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(reportsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('التصنيفات (له / عليه)'), actions: [IconButton(tooltip: 'تصدير PDF', icon: const Icon(Icons.picture_as_pdf), onPressed: state.isLoading ? null : () async { final rows = state.getCategoryTotals().entries.expand((e) => e.value.entries.map((v) => [e.key == DebtType.credit ? 'له' : 'عليه', v.key.name.toUpperCase(), MoneyFormat.amount(v.value)])).toList(); final p = await ExportService.generateGeneralPDF(title: 'التصنيفات', headers: const ['النوع','العملة','المبلغ'], rows: rows); if (context.mounted) await ExportService.shareFile(p, message: 'التصنيفات'); }), IconButton(tooltip: 'تصدير Excel', icon: const Icon(Icons.table_chart), onPressed: state.isLoading ? null : () async { final rows = state.getCategoryTotals().entries.expand((e) => e.value.entries.map((v) => [e.key == DebtType.credit ? 'له' : 'عليه', v.key.name.toUpperCase(), MoneyFormat.amount(v.value)])).toList(); final p = await ExportService.generateGeneralExcel(title: 'التصنيفات', headers: const ['النوع','العملة','المبلغ'], rows: rows); if (context.mounted) await ExportService.shareFile(p, message: 'التصنيفات'); })]),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.error != null
          ? Center(child: Text('خطأ: ${state.error}'))
          : state.transactions.isEmpty
          ? const Center(child: Text('لا توجد بيانات'))
          : Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: state.getCategoryTotals().entries.map((entry) {
            final type = entry.key;
            final totals = entry.value;
            final label = type == DebtType.credit ? 'له' : 'عليه';
            final color =
            type == DebtType.credit ? AppColors.credit : AppColors.debit;
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...totals.entries.map((e) => Text(
                        '${e.key.name.toUpperCase()}: ${MoneyFormat.amount(e.value)}')),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}