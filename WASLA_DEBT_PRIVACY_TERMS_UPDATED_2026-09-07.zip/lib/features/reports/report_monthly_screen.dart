import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wasla_debt/features/reports/providers/reports_provider.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart' as models;
import 'package:wasla_debt/core/services/export_service.dart';

class ReportMonthlyScreen extends ConsumerWidget {
  const ReportMonthlyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(reportsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('التقرير الشهري'), actions: [IconButton(tooltip: 'تصدير PDF', icon: const Icon(Icons.picture_as_pdf), onPressed: state.isLoading ? null : () async { final List<List<String>> rows = state.getMonthlyTotals().entries.map<List<String>>((e) => [e.key, ...models.Currency.values.map<String>((c) => MoneyFormat.amount(e.value[c]?.balance ?? 0))]).toList(); final p = await ExportService.generateGeneralPDF(title: 'التقرير الشهري', headers: const ['الشهر','YER','SAR','USD'], rows: rows); if (context.mounted) await ExportService.shareFile(p, message: 'التقرير الشهري'); }), IconButton(tooltip: 'تصدير Excel', icon: const Icon(Icons.table_chart), onPressed: state.isLoading ? null : () async { final List<List<String>> rows = state.getMonthlyTotals().entries.map<List<String>>((e) => [e.key, ...models.Currency.values.map<String>((c) => MoneyFormat.amount(e.value[c]?.balance ?? 0))]).toList(); final p = await ExportService.generateGeneralExcel(title: 'التقرير الشهري', headers: const ['الشهر','YER','SAR','USD'], rows: rows); if (context.mounted) await ExportService.shareFile(p, message: 'التقرير الشهري'); })]),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.error != null
          ? Center(child: Text('خطأ: ${state.error}'))
          : state.transactions.isEmpty && state.payments.isEmpty
          ? const Center(child: Text('لا توجد بيانات'))
          : ListView(
        padding: const EdgeInsets.all(16),
        children: state.getMonthlyTotals().entries.map((entry) {
          final month = entry.key;
          final totals = entry.value;
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: ListTile(
              title: Text(month),
              subtitle: Text(
                totals.entries
                    .map((e) =>
                '${e.key.name.toUpperCase()}: ${MoneyFormat.amount(e.value.balance)}')
                    .join(' | '),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}