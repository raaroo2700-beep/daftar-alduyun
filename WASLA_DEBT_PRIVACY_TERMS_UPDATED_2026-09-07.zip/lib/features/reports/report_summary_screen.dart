import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:wasla_debt/app/theme/app_colors.dart';
import 'package:wasla_debt/app/theme/app_dimensions.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/core/services/export_service.dart';
import 'package:wasla_debt/features/reports/providers/reports_provider.dart';

class ReportSummaryScreen extends ConsumerWidget {
const ReportSummaryScreen({super.key});

@override
Widget build(BuildContext context, WidgetRef ref) {
final state = ref.watch(reportsProvider);

return Scaffold(
appBar: AppBar(title: const Text('إجمالي المبالغ'), actions: [IconButton(tooltip: 'تصدير PDF', icon: const Icon(Icons.picture_as_pdf), onPressed: state.isLoading ? null : () async { final rows = state.customers.map((c) { final totals = state.getCustomerTotals()[c.id] ?? {}; return [c.name, ...Currency.values.map((x) => MoneyFormat.amount(totals[x]?.balance ?? 0))]; }).toList(); final p = await ExportService.generateGeneralPDF(title: 'إجمالي المبالغ', headers: const ['العميل','YER','SAR','USD'], rows: rows); if (context.mounted) await ExportService.shareFile(p, message: 'إجمالي المبالغ'); }), IconButton(tooltip: 'تصدير Excel', icon: const Icon(Icons.table_chart), onPressed: state.isLoading ? null : () async { final rows = state.customers.map((c) { final totals = state.getCustomerTotals()[c.id] ?? {}; return [c.name, ...Currency.values.map((x) => MoneyFormat.amount(totals[x]?.balance ?? 0))]; }).toList(); final p = await ExportService.generateGeneralExcel(title: 'إجمالي المبالغ', headers: const ['العميل','YER','SAR','USD'], rows: rows); if (context.mounted) await ExportService.shareFile(p, message: 'إجمالي المبالغ'); })]),
body: state.isLoading
? const Center(child: CircularProgressIndicator())
: state.error != null
? Center(child: Text('خطأ: ${state.error}'))
: state.customers.isEmpty
? const Center(child: Text('لا توجد بيانات'))
: ListView(
padding: const EdgeInsets.all(AppDimensions.paddingMedium),
children: [
// الإجمالي الكلي
Card(
child: Padding(
padding: const EdgeInsets.all(AppDimensions.paddingMedium),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
const Text('الإجمالي الكلي',
style: TextStyle(fontWeight: FontWeight.bold)),
const SizedBox(height: 8),
Row(
mainAxisAlignment: MainAxisAlignment.spaceAround,
children: state.getGlobalTotals().entries.map((e) {
return Column(
children: [
Text(e.key.name.toUpperCase()),
Text(
NumberFormat.currency(
symbol: _getSymbol(e.key),
decimalDigits: 2,
).format(e.value.balance),
style: TextStyle(
color: e.value.balance >= 0
? AppColors.credit
: AppColors.debit,
fontWeight: FontWeight.bold,
),
),
],
);
}).toList(),
),
],
),
),
),
const SizedBox(height: 16),
const Text('أرصدة العملاء',
style: TextStyle(fontWeight: FontWeight.bold)),
// ✅ التعديل هنا: حذف .toList()
...state.customers.map((customer) {
final totals = state.getCustomerTotals()[customer.id] ?? {};
return Card(
margin: const EdgeInsets.symmetric(vertical: 4),
child: ListTile(
title: Text(customer.name),
subtitle: Text(
totals.entries
.map((e) =>
'${e.key.name.toUpperCase()}: ${MoneyFormat.amount(e.value.balance)} ${_getSymbol(e.key)}')
    .join(' | '),
),
),
);
}),
],
),
);
}

String _getSymbol(Currency c) {
  switch (c) {
    case Currency.yer:
      return 'ريال';
    case Currency.sar:
      return 'ر.س';
    case Currency.usd:
      return '\$';
  }
}
}