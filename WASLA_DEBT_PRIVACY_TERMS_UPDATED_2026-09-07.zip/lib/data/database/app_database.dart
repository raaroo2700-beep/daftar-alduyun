import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'database_schema.dart';

class AppDatabase {
  static final AppDatabase _instance = AppDatabase._internal();
  static Database? _database;

  AppDatabase._internal();

  factory AppDatabase() => _instance;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'wasla_debt.db');
    return await openDatabase(
      path,
      version: 5,
      onConfigure: (db) async {
        // إصلاح 1.1: تفعيل فرض المفاتيح الخارجية (ON DELETE CASCADE وغيرها)
        // فالمخطط يعرّفها لكن SQLite لا يفرضها افتراضيًا.
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute(DatabaseSchema.createCustomersTable);
    await db.execute(DatabaseSchema.createTransactionsTable);
    await db.execute(DatabaseSchema.createSettlementsTable);
    await db.execute(DatabaseSchema.createPaymentsTable);
    await db.execute(DatabaseSchema.createSettingsTable);
    await db.execute(DatabaseSchema.createBackupMetadataTable);
    await db.execute(DatabaseSchema.createRecurringSchedulesTable);
    await db.execute(DatabaseSchema.createAuditLogsTable);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute(
        'ALTER TABLE transactions ADD COLUMN isArchived INTEGER NOT NULL DEFAULT 0',
      );
      await db.execute(DatabaseSchema.createAuditLogsTable);
    }
    if (oldVersion < 3) {
      await db.execute(DatabaseSchema.createRecurringSchedulesTable.replaceFirst('CREATE TABLE recurring_schedules', 'CREATE TABLE IF NOT EXISTS recurring_schedules'));
      await db.execute('ALTER TABLE customers ADD COLUMN debtLimit REAL');
      await db.execute('ALTER TABLE customers ADD COLUMN creditLimit REAL');
      await db.execute('''
        CREATE TABLE recurring_schedules_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          customerId INTEGER NOT NULL,
          amount REAL NOT NULL,
          currency TEXT NOT NULL CHECK(currency IN ('YER', 'SAR', 'USD')),
          type TEXT NOT NULL CHECK(type IN ('credit', 'debit')),
          details TEXT,
          interval TEXT NOT NULL CHECK(interval IN ('daily', 'weekly', 'monthly')),
          nextRun INTEGER NOT NULL,
          enabled INTEGER NOT NULL DEFAULT 1,
          createdAt INTEGER NOT NULL,
          updatedAt INTEGER NOT NULL,
          FOREIGN KEY (customerId) REFERENCES customers (id) ON DELETE CASCADE
        )
      ''');
      await db.execute('''
        INSERT INTO recurring_schedules_new
        (id, customerId, amount, currency, type, details, interval, nextRun, enabled, createdAt, updatedAt)
        SELECT id, customerId, amount, UPPER(currency), type, details, interval, nextRun, enabled, createdAt, updatedAt
        FROM recurring_schedules
      ''');
      await db.execute('DROP TABLE recurring_schedules');
      await db.execute('ALTER TABLE recurring_schedules_new RENAME TO recurring_schedules');
    }

    if (oldVersion < 5) {
      // Payment direction fixes the financial sign for payments made to
      // creditor customers. Existing payments retain the old behavior.
      await db.execute("ALTER TABLE payments ADD COLUMN direction TEXT NOT NULL DEFAULT 'customerToBusiness'");
      await db.execute('ALTER TABLE customers ADD COLUMN debtLimitYer REAL');
      await db.execute('ALTER TABLE customers ADD COLUMN debtLimitSar REAL');
      await db.execute('ALTER TABLE customers ADD COLUMN debtLimitUsd REAL');
      await db.execute('ALTER TABLE customers ADD COLUMN creditLimitYer REAL');
      await db.execute('ALTER TABLE customers ADD COLUMN creditLimitSar REAL');
      await db.execute('ALTER TABLE customers ADD COLUMN creditLimitUsd REAL');
      // Legacy limits were global. Copy them to every currency so upgrading
      // does not silently remove an existing limit.
      await db.execute('UPDATE customers SET debtLimitYer = debtLimit WHERE debtLimitYer IS NULL');
      await db.execute('UPDATE customers SET debtLimitSar = debtLimit WHERE debtLimitSar IS NULL');
      await db.execute('UPDATE customers SET debtLimitUsd = debtLimit WHERE debtLimitUsd IS NULL');
      await db.execute('UPDATE customers SET creditLimitYer = creditLimit WHERE creditLimitYer IS NULL');
      await db.execute('UPDATE customers SET creditLimitSar = creditLimit WHERE creditLimitSar IS NULL');
      await db.execute('UPDATE customers SET creditLimitUsd = creditLimit WHERE creditLimitUsd IS NULL');
    }

    if (oldVersion < 4) {
      await db.execute('''
        CREATE TABLE audit_logs_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          entityType TEXT NOT NULL,
          entityId INTEGER NOT NULL,
          action TEXT NOT NULL CHECK(action IN ('create', 'update', 'archive', 'restore', 'delete', 'transfer')),
          oldValues TEXT,
          newValues TEXT,
          timestamp INTEGER NOT NULL,
          userId TEXT,
          note TEXT
        )
      ''');
      await db.execute('''
        INSERT INTO audit_logs_new (id, entityType, entityId, action, oldValues, newValues, timestamp, userId, note)
        SELECT id, entityType, entityId, action, oldValues, newValues, timestamp, userId, note FROM audit_logs
      ''');
      await db.execute('DROP TABLE audit_logs');
      await db.execute('ALTER TABLE audit_logs_new RENAME TO audit_logs');
    }
  }
}