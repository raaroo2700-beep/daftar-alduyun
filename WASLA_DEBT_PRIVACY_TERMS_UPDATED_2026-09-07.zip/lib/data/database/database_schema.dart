class DatabaseSchema {
  static const String createCustomersTable = '''
    CREATE TABLE customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      note TEXT,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL,
      debtLimit REAL,
      creditLimit REAL,
      debtLimitYer REAL, debtLimitSar REAL, debtLimitUsd REAL,
      creditLimitYer REAL, creditLimitSar REAL, creditLimitUsd REAL,
      isArchived INTEGER NOT NULL DEFAULT 0
    )
  ''';

  static const String createTransactionsTable = '''
    CREATE TABLE transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customerId INTEGER NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('credit', 'debit')),
      amount REAL NOT NULL,
      currency TEXT NOT NULL CHECK(currency IN ('YER', 'SAR', 'USD')),
      details TEXT,
      date INTEGER NOT NULL,
      imagePath TEXT,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL,
      isArchived INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (customerId) REFERENCES customers (id) ON DELETE CASCADE
    )
  ''';

  static const String createSettlementsTable = '''
    CREATE TABLE settlements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      transactionId INTEGER NOT NULL,
      amount REAL NOT NULL,
      currency TEXT NOT NULL CHECK(currency IN ('YER', 'SAR', 'USD')),
      note TEXT,
      settledAt INTEGER NOT NULL,
      createdAt INTEGER NOT NULL,
      FOREIGN KEY (transactionId) REFERENCES transactions (id) ON DELETE CASCADE
    )
  ''';

  static const String createPaymentsTable = '''
    CREATE TABLE payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customerId INTEGER NOT NULL,
      amount REAL NOT NULL,
      currency TEXT NOT NULL CHECK(currency IN ('YER', 'SAR', 'USD')),
      direction TEXT NOT NULL CHECK(direction IN ('customerToBusiness', 'businessToCustomer')),
      transactionId INTEGER,
      note TEXT,
      paymentDate INTEGER NOT NULL,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL,
      FOREIGN KEY (customerId) REFERENCES customers (id) ON DELETE CASCADE,
      FOREIGN KEY (transactionId) REFERENCES transactions (id) ON DELETE SET NULL
    )
  ''';

  static const String createRecurringSchedulesTable = '''
  CREATE TABLE recurring_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customerId INTEGER NOT NULL,
    amount REAL NOT NULL,
    currency TEXT NOT NULL CHECK(currency IN ('YER', 'SAR', 'USD')),
    type TEXT NOT NULL CHECK(type IN ('credit', 'debit')),
    details TEXT,
    interval TEXT NOT NULL CHECK(interval IN ('daily', 'weekly', 'monthly')),
    nextRun INTEGER NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    createdAt INTEGER NOT NULL,
    updatedAt INTEGER NOT NULL,
    FOREIGN KEY (customerId) REFERENCES customers (id) ON DELETE CASCADE
  )
''';

  static const String createSettingsTable = '''
    CREATE TABLE app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  ''';

  static const String createBackupMetadataTable = '''
    CREATE TABLE backup_metadata (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      backupDate INTEGER NOT NULL,
      schemaVersion INTEGER NOT NULL,
      fileName TEXT NOT NULL
    )
  ''';

  static const String createAuditLogsTable = '''
    CREATE TABLE audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entityType TEXT NOT NULL,
      entityId INTEGER NOT NULL,
      action TEXT NOT NULL CHECK(action IN ('create', 'update', 'archive', 'restore', 'delete', 'transfer')),
      oldValues TEXT,
      newValues TEXT,
      timestamp INTEGER NOT NULL,
      userId TEXT,
      note TEXT
    )
  ''';
}