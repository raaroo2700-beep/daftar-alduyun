import 'package:wasla_debt/data/models/debt_transaction.dart';

class BalanceResult {
  final Currency currency;
  final double totalDebit;
  final double totalCredit;
  final double paymentsReceived;
  final double totalPaymentsPaid;

  const BalanceResult({
    required this.currency,
    required this.totalDebit,
    required this.totalCredit,
    double? totalPayments,
    double totalPaymentsReceived = 0.0,
    this.totalPaymentsPaid = 0.0,
  }) : paymentsReceived = totalPayments ?? totalPaymentsReceived;

  double get totalPaymentsReceived => paymentsReceived;
  double get totalPayments => paymentsReceived + totalPaymentsPaid;

  double get balance =>
      totalDebit - totalCredit - paymentsReceived + totalPaymentsPaid;

  bool get isDebtor => balance > 0;
  bool get isCreditor => balance < 0;
  bool get isZero => balance == 0;
}
