import 'dart:convert';

enum AuditAction { create, update, archive, restore, delete, transfer }

class AuditLog {
  final int? id;
  final String entityType;
  final int entityId;
  final AuditAction action;
  final Map<String, dynamic>? oldValues;
  final Map<String, dynamic>? newValues;
  final int timestamp;
  final String? userId;
  final String? note;

  AuditLog({this.id, required this.entityType, required this.entityId, required this.action, this.oldValues, this.newValues, required this.timestamp, this.userId, this.note});

  Map<String, dynamic> toMap() => {
        'id': id,
        'entityType': entityType,
        'entityId': entityId,
        'action': action.name,
        'oldValues': oldValues == null ? null : jsonEncode(oldValues),
        'newValues': newValues == null ? null : jsonEncode(newValues),
        'timestamp': timestamp,
        'userId': userId,
        'note': note,
      };

  factory AuditLog.fromMap(Map<String, dynamic> map) => AuditLog(
        id: map['id'] as int?,
        entityType: map['entityType'] as String,
        entityId: map['entityId'] as int,
        action: AuditAction.values.firstWhere((e) => e.name == map['action']),
        oldValues: map['oldValues'] == null ? null : jsonDecode(map['oldValues'] as String),
        newValues: map['newValues'] == null ? null : jsonDecode(map['newValues'] as String),
        timestamp: map['timestamp'] as int,
        userId: map['userId'] as String?,
        note: map['note'] as String?,
      );
}
