import 'package:wasla_debt/data/models/debt_transaction.dart';

enum RecurringInterval { daily, weekly, monthly }

class RecurringSchedule {
  final int? id;
  final int customerId;
  final double amount;
  final Currency currency;
  final DebtType type;
  final String? details;
  final RecurringInterval interval;
  final int nextRun;
  final bool enabled;
  final int createdAt;
  final int updatedAt;

  RecurringSchedule({
    this.id,
    required this.customerId,
    required this.amount,
    required this.currency,
    required this.type,
    this.details,
    required this.interval,
    required this.nextRun,
    this.enabled = true,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerId': customerId,
      'amount': amount,
      'currency': currency.name.toUpperCase(),
      'type': type == DebtType.credit ? 'credit' : 'debit',
      'details': details,
      'interval': interval.name,
      'nextRun': nextRun,
      'enabled': enabled ? 1 : 0,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }

  factory RecurringSchedule.fromMap(Map<String, dynamic> map) {
    return RecurringSchedule(
      id: map['id'],
      customerId: map['customerId'],
      amount: map['amount'],
      currency: Currency.values.firstWhere(
            (e) => e.name.toUpperCase() == (map['currency'] as String).toUpperCase(),
      ),
      type: map['type'] == 'credit' ? DebtType.credit : DebtType.debit,
      details: map['details'],
      interval: RecurringInterval.values.firstWhere(
            (e) => e.name == map['interval'],
      ),
      nextRun: map['nextRun'],
      enabled: map['enabled'] == 1,
      createdAt: map['createdAt'],
      updatedAt: map['updatedAt'],
    );
  }

  RecurringSchedule copyWith({
    int? id,
    int? customerId,
    double? amount,
    Currency? currency,
    DebtType? type,
    String? details,
    RecurringInterval? interval,
    int? nextRun,
    bool? enabled,
    int? createdAt,
    int? updatedAt,
  }) {
    return RecurringSchedule(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      amount: amount ?? this.amount,
      currency: currency ?? this.currency,
      type: type ?? this.type,
      details: details ?? this.details,
      interval: interval ?? this.interval,
      nextRun: nextRun ?? this.nextRun,
      enabled: enabled ?? this.enabled,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}