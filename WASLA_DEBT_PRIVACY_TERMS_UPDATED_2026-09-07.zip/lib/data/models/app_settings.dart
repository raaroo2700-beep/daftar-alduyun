import 'package:wasla_debt/data/models/debt_transaction.dart';

class AppSettings {
  final Currency defaultCurrency;
  final bool showTime;
  final bool darkMode;
  final int maxBackups;
  final bool autoBackup;
  // إصلاح (النسخ المحلي): مجلد مخصص يختاره العميل لحفظ النسخ الاحتياطية فيه.
  // null يعني استخدام المجلد الافتراضي داخل مساحة التطبيق كما كان سابقًا.
  final String? backupFolderPath;
  // إصلاح (النسخ التلقائي): الوقت اليومي الذي يريد العميل أن يتم عنده النسخ
  // التلقائي. ملاحظة مهمة: Flutter لا ينفّذ كودًا في الخلفية فعليًا دون حزمة
  // جدولة نظام مثل workmanager (غير مضافة لهذا المشروع). لذلك هذا الوقت
  // يُستخدم كـ"أقرب وقت مسموح به" يتحقق منه التطبيق عند كل فتح: إن كان الوقت
  // الحالي بعد هذه الساعة ولم يُؤخذ نسخة اليوم بعد، تُنشأ نسخة تلقائيًا فور
  // فتح التطبيق. هذا ليس تنفيذًا خلفيًا حقيقيًا في الساعة المحددة بالضبط.
  final int autoBackupHour;
  final int autoBackupMinute;

  AppSettings({
    this.defaultCurrency = Currency.yer,
    this.showTime = true,
    this.darkMode = false,
    this.maxBackups = 5,
    this.autoBackup = false,
    this.backupFolderPath,
    this.autoBackupHour = 2,
    this.autoBackupMinute = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'defaultCurrency': defaultCurrency.name,
      'showTime': showTime,
      'darkMode': darkMode,
      'maxBackups': maxBackups,
      'autoBackup': autoBackup,
      'backupFolderPath': backupFolderPath,
      'autoBackupHour': autoBackupHour,
      'autoBackupMinute': autoBackupMinute,
    };
  }

  factory AppSettings.fromMap(Map<String, dynamic> map) {
    return AppSettings(
      defaultCurrency: Currency.values.firstWhere(
            (e) => e.name == map['defaultCurrency'],
        orElse: () => Currency.yer,
      ),
      showTime: map['showTime'] ?? true,
      darkMode: map['darkMode'] ?? false,
      maxBackups: map['maxBackups'] ?? 5,
      autoBackup: map['autoBackup'] ?? false,
      backupFolderPath: map['backupFolderPath'] as String?,
      autoBackupHour: map['autoBackupHour'] ?? 2,
      autoBackupMinute: map['autoBackupMinute'] ?? 0,
    );
  }

  AppSettings copyWith({
    Currency? defaultCurrency,
    bool? showTime,
    bool? darkMode,
    int? maxBackups,
    bool? autoBackup,
    String? backupFolderPath,
    bool clearBackupFolderPath = false,
    int? autoBackupHour,
    int? autoBackupMinute,
  }) {
    return AppSettings(
      defaultCurrency: defaultCurrency ?? this.defaultCurrency,
      showTime: showTime ?? this.showTime,
      darkMode: darkMode ?? this.darkMode,
      maxBackups: maxBackups ?? this.maxBackups,
      autoBackup: autoBackup ?? this.autoBackup,
      backupFolderPath: clearBackupFolderPath
          ? null
          : (backupFolderPath ?? this.backupFolderPath),
      autoBackupHour: autoBackupHour ?? this.autoBackupHour,
      autoBackupMinute: autoBackupMinute ?? this.autoBackupMinute,
    );
  }
}