import 'debt_transaction.dart';

class Customer {
  final int? id;
  final String name;
  final String? phone;
  final String? note;
  /// Legacy global limits retained for backup/old data compatibility.
  final double? debtLimit;
  final double? creditLimit;
  final double? debtLimitYer;
  final double? debtLimitSar;
  final double? debtLimitUsd;
  final double? creditLimitYer;
  final double? creditLimitSar;
  final double? creditLimitUsd;
  final int createdAt;
  final int updatedAt;
  final bool isArchived;

  Customer({
    this.id,
    required this.name,
    this.phone,
    this.note,
    this.debtLimit,
    this.creditLimit,
    this.debtLimitYer,
    this.debtLimitSar,
    this.debtLimitUsd,
    this.creditLimitYer,
    this.creditLimitSar,
    this.creditLimitUsd,
    required this.createdAt,
    required this.updatedAt,
    this.isArchived = false,
  });

  Map<String, dynamic> toMap() => {
    'id': id, 'name': name, 'phone': phone, 'note': note,
    'debtLimit': debtLimit, 'creditLimit': creditLimit,
    'debtLimitYer': debtLimitYer, 'debtLimitSar': debtLimitSar, 'debtLimitUsd': debtLimitUsd,
    'creditLimitYer': creditLimitYer, 'creditLimitSar': creditLimitSar, 'creditLimitUsd': creditLimitUsd,
    'createdAt': createdAt, 'updatedAt': updatedAt, 'isArchived': isArchived ? 1 : 0,
  };

  static double? _num(Map<String,dynamic> m, String key) => (m[key] as num?)?.toDouble();

  factory Customer.fromMap(Map<String, dynamic> map) => Customer(
    id: map['id'] as int?,
    name: map['name'] as String,
    phone: map['phone'] as String?,
    note: map['note'] as String?,
    debtLimit: _num(map, 'debtLimit'),
    creditLimit: _num(map, 'creditLimit'),
    debtLimitYer: _num(map, 'debtLimitYer'),
    debtLimitSar: _num(map, 'debtLimitSar'),
    debtLimitUsd: _num(map, 'debtLimitUsd'),
    creditLimitYer: _num(map, 'creditLimitYer'),
    creditLimitSar: _num(map, 'creditLimitSar'),
    creditLimitUsd: _num(map, 'creditLimitUsd'),
    createdAt: map['createdAt'] as int,
    updatedAt: map['updatedAt'] as int,
    isArchived: map['isArchived'] == 1,
  );

  double? debtLimitFor(Currency currency) => switch(currency) {
    Currency.yer => debtLimitYer ?? debtLimit,
    Currency.sar => debtLimitSar ?? debtLimit,
    Currency.usd => debtLimitUsd ?? debtLimit,
  };

  double? creditLimitFor(Currency currency) => switch(currency) {
    Currency.yer => creditLimitYer ?? creditLimit,
    Currency.sar => creditLimitSar ?? creditLimit,
    Currency.usd => creditLimitUsd ?? creditLimit,
  };

  Customer copyWith({
    int? id, String? name, String? phone, String? note,
    Object? debtLimit = _unset, Object? creditLimit = _unset,
    Object? debtLimitYer = _unset, Object? debtLimitSar = _unset, Object? debtLimitUsd = _unset,
    Object? creditLimitYer = _unset, Object? creditLimitSar = _unset, Object? creditLimitUsd = _unset,
    int? createdAt, int? updatedAt, bool? isArchived,
  }) => Customer(
    id: id ?? this.id, name: name ?? this.name, phone: phone ?? this.phone, note: note ?? this.note,
    debtLimit: debtLimit == _unset ? this.debtLimit : debtLimit as double?,
    creditLimit: creditLimit == _unset ? this.creditLimit : creditLimit as double?,
    debtLimitYer: debtLimitYer == _unset ? this.debtLimitYer : debtLimitYer as double?,
    debtLimitSar: debtLimitSar == _unset ? this.debtLimitSar : debtLimitSar as double?,
    debtLimitUsd: debtLimitUsd == _unset ? this.debtLimitUsd : debtLimitUsd as double?,
    creditLimitYer: creditLimitYer == _unset ? this.creditLimitYer : creditLimitYer as double?,
    creditLimitSar: creditLimitSar == _unset ? this.creditLimitSar : creditLimitSar as double?,
    creditLimitUsd: creditLimitUsd == _unset ? this.creditLimitUsd : creditLimitUsd as double?,
    createdAt: createdAt ?? this.createdAt, updatedAt: updatedAt ?? this.updatedAt,
    isArchived: isArchived ?? this.isArchived,
  );
}

const _unset = Object();
