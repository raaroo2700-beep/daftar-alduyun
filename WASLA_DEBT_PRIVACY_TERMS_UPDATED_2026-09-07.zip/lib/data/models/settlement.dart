import 'debt_transaction.dart';
class Settlement {
  final int? id;
  final int transactionId;
  final double amount;
  final Currency currency;
  final String? note;
  final int settledAt;
  final int createdAt;

  Settlement({
    this.id,
    required this.transactionId,
    required this.amount,
    required this.currency,
    this.note,
    required this.settledAt,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'transactionId': transactionId,
      'amount': amount,
      'currency': currency.name.toUpperCase(),
      'note': note,
      'settledAt': settledAt,
      'createdAt': createdAt,
    };
  }

  factory Settlement.fromMap(Map<String, dynamic> map) {
    return Settlement(
      id: map['id'],
      transactionId: map['transactionId'],
      amount: map['amount'],
      currency: Currency.values.firstWhere(
            (e) => e.name.toUpperCase() == map['currency'],
      ),
      note: map['note'],
      settledAt: map['settledAt'],
      createdAt: map['createdAt'],
    );
  }
}