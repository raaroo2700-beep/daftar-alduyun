import 'debt_transaction.dart';

/// اتجاه السداد بالنسبة لصاحب المحل:
/// - customerToBusiness: العميل يدفع لصاحب المحل، فينخفض رصيده المدين.
/// - businessToCustomer: صاحب المحل يدفع للعميل، فينخفض رصيده الدائن (يزداد الرصيد نحو الصفر).
enum PaymentDirection { customerToBusiness, businessToCustomer }

class Payment {
  final int? id;
  final int customerId;
  final double amount;
  final Currency currency;
  final PaymentDirection direction;
  final int? transactionId;
  final String? note;
  final int paymentDate;
  final int createdAt;
  final int updatedAt;

  Payment({
    this.id,
    required this.customerId,
    required this.amount,
    required this.currency,
    this.direction = PaymentDirection.customerToBusiness,
    this.transactionId,
    this.note,
    required this.paymentDate,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'customerId': customerId,
    'amount': amount,
    'currency': currency.name.toUpperCase(),
    'direction': direction.name,
    'transactionId': transactionId,
    'note': note,
    'paymentDate': paymentDate,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
  };

  factory Payment.fromMap(Map<String, dynamic> map) {
    final rawDirection = map['direction']?.toString();
    final direction = PaymentDirection.values.firstWhere(
      (d) => d.name == rawDirection,
      orElse: () => PaymentDirection.customerToBusiness,
    );
    return Payment(
      id: map['id'] as int?,
      customerId: map['customerId'] as int,
      amount: (map['amount'] as num).toDouble(),
      currency: Currency.values.firstWhere(
        (e) => e.name.toUpperCase() == map['currency'].toString().toUpperCase(),
      ),
      direction: direction,
      transactionId: map['transactionId'] as int?,
      note: map['note'] as String?,
      paymentDate: map['paymentDate'] as int,
      createdAt: map['createdAt'] as int,
      updatedAt: map['updatedAt'] as int,
    );
  }

  Payment copyWith({
    int? id,
    int? customerId,
    double? amount,
    Currency? currency,
    PaymentDirection? direction,
    int? transactionId,
    String? note,
    int? paymentDate,
    int? createdAt,
    int? updatedAt,
  }) => Payment(
    id: id ?? this.id,
    customerId: customerId ?? this.customerId,
    amount: amount ?? this.amount,
    currency: currency ?? this.currency,
    direction: direction ?? this.direction,
    transactionId: transactionId ?? this.transactionId,
    note: note ?? this.note,
    paymentDate: paymentDate ?? this.paymentDate,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
