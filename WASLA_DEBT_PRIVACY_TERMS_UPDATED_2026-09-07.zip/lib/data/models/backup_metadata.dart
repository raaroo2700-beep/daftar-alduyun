class BackupMetadata {
  // إصلاح إضافي (اكتُشف أثناء تفعيل الإصلاح 5.1/7.5): كان id غير قابل لأن
  // يكون null، فيُرسَل دائمًا كـ 0 عند الإدراج. عمود INTEGER PRIMARY KEY
  // AUTOINCREMENT في SQLite يُفعّل الترقيم التلقائي فقط عند إدراج NULL، لا
  // القيمة 0 — أي أن ثاني عملية نسخ احتياطي كانت ستفشل بخطأ
  // "UNIQUE constraint failed" لأن id=0 مكرر مع أول سجل.
  final int? id;
  final int backupDate;
  final int schemaVersion;
  final String fileName;

  BackupMetadata({
    this.id,
    required this.backupDate,
    required this.schemaVersion,
    required this.fileName,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'backupDate': backupDate,
      'schemaVersion': schemaVersion,
      'fileName': fileName,
    };
  }

  factory BackupMetadata.fromMap(Map<String, dynamic> map) {
    return BackupMetadata(
      id: map['id'],
      backupDate: map['backupDate'],
      schemaVersion: map['schemaVersion'],
      fileName: map['fileName'],
    );
  }
}
