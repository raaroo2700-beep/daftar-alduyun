enum DebtType { credit, debit }

enum Currency { yer, sar, usd }

class DebtTransaction {
  final int? id;
  final int customerId;
  final DebtType type;
  final double amount;
  final Currency currency;
  final String? details;
  final int date;
  final String? imagePath;
  final int createdAt;
  final int updatedAt;
  final bool isArchived;

  DebtTransaction({
    this.id,
    required this.customerId,
    required this.type,
    required this.amount,
    required this.currency,
    this.details,
    required this.date,
    this.imagePath,
    required this.createdAt,
    required this.updatedAt,
    this.isArchived = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerId': customerId,
      'type': type == DebtType.credit ? 'credit' : 'debit',
      'amount': amount,
      'currency': currency.name.toUpperCase(),
      'details': details,
      'date': date,
      'imagePath': imagePath,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'isArchived': isArchived ? 1 : 0,
    };
  }

  factory DebtTransaction.fromMap(Map<String, dynamic> map) {
    return DebtTransaction(
      id: map['id'],
      customerId: map['customerId'],
      type: map['type'] == 'credit' ? DebtType.credit : DebtType.debit,
      amount: map['amount'],
      currency: Currency.values.firstWhere(
            (e) => e.name.toUpperCase() == map['currency'],
      ),
      details: map['details'],
      date: map['date'],
      imagePath: map['imagePath'],
      createdAt: map['createdAt'],
      updatedAt: map['updatedAt'],
      isArchived: map['isArchived'] == 1,
    );
  }

  DebtTransaction copyWith({
    int? id,
    int? customerId,
    DebtType? type,
    double? amount,
    Currency? currency,
    String? details,
    int? date,
    String? imagePath,
    int? createdAt,
    int? updatedAt,
    bool? isArchived,
  }) {
    return DebtTransaction(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      type: type ?? this.type,
      amount: amount ?? this.amount,
      currency: currency ?? this.currency,
      details: details ?? this.details,
      date: date ?? this.date,
      imagePath: imagePath ?? this.imagePath,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isArchived: isArchived ?? this.isArchived,
    );
  }
}