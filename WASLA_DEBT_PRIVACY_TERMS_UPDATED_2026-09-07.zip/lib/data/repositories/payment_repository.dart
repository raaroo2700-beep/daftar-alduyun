import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/payment.dart';

class PaymentRepository {
  final AppDatabase appDatabase = AppDatabase();

  Future<int> insertPayment(Payment payment) async {
    final db = await appDatabase.database;
    return db.insert('payments', payment.toMap());
  }

  Future<int> insertPaymentWithTxn(Payment payment, Transaction txn) =>
      txn.insert('payments', payment.toMap());

  Future<List<Payment>> getPaymentsByCustomer(int customerId) async {
    final db = await appDatabase.database;
    final maps = await db.query('payments', where: 'customerId = ?', whereArgs: [customerId], orderBy: 'paymentDate DESC');
    return maps.map(Payment.fromMap).toList();
  }

  Future<List<Payment>> getAllPayments() async {
    final db = await appDatabase.database;
    final maps = await db.query('payments', orderBy: 'paymentDate DESC');
    return maps.map(Payment.fromMap).toList();
  }

  Future<List<Payment>> getPaymentsByTransaction(int transactionId) async {
    final db = await appDatabase.database;
    final maps = await db.query('payments', where: 'transactionId = ?', whereArgs: [transactionId], orderBy: 'paymentDate DESC');
    return maps.map(Payment.fromMap).toList();
  }

  Future<Payment?> getPaymentById(int id) async {
    final db = await appDatabase.database;
    final maps = await db.query('payments', where: 'id = ?', whereArgs: [id]);
    return maps.isEmpty ? null : Payment.fromMap(maps.first);
  }

  Future<Payment?> getPaymentByIdWithTxn(int id, Transaction txn) async {
    final maps = await txn.query('payments', where: 'id = ?', whereArgs: [id]);
    return maps.isEmpty ? null : Payment.fromMap(maps.first);
  }

  Future<int> updatePayment(Payment payment) async {
    final db = await appDatabase.database;
    return db.update('payments', payment.toMap(), where: 'id = ?', whereArgs: [payment.id]);
  }

  Future<int> updatePaymentWithTxn(Payment payment, Transaction txn) =>
      txn.update('payments', payment.toMap(), where: 'id = ?', whereArgs: [payment.id]);

  Future<int> deletePayment(int id) async {
    final db = await appDatabase.database;
    return db.delete('payments', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deletePaymentWithTxn(int id, Transaction txn) =>
      txn.delete('payments', where: 'id = ?', whereArgs: [id]);
}
