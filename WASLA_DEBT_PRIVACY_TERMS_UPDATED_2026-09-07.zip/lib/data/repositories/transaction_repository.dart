import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/debt_transaction.dart';

class TransactionRepository {
  final AppDatabase appDatabase = AppDatabase();

  @Deprecated('Use archiveTransaction instead')
  Future<int> deleteTransaction(int id) async {
    final db = await appDatabase.database;
    return db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> archiveTransaction(int id) async {
    final db = await appDatabase.database;
    return db.update('transactions', {'isArchived': 1, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> archiveTransactionWithTxn(int id, Transaction txn) =>
      txn.update('transactions', {'isArchived': 1, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);

  Future<int> updateTransactionWithTxn(DebtTransaction transaction, Transaction txn) =>
      txn.update('transactions', transaction.toMap(), where: 'id = ?', whereArgs: [transaction.id]);

  Future<int> restoreTransactionWithTxn(int id, Transaction txn) =>
      txn.update('transactions', {'isArchived': 0, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);

  Future<int> restoreTransaction(int id) async {
    final db = await appDatabase.database;
    return db.update('transactions', {'isArchived': 0, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);
  }

  Future<DebtTransaction?> getTransactionById(int id) async {
    final db = await appDatabase.database;
    final maps = await db.query('transactions', where: 'id = ?', whereArgs: [id]);
    return maps.isEmpty ? null : DebtTransaction.fromMap(maps.first);
  }

  Future<DebtTransaction?> getTransactionByIdWithTxn(int id, Transaction txn) async {
    final maps = await txn.query('transactions', where: 'id = ?', whereArgs: [id]);
    return maps.isEmpty ? null : DebtTransaction.fromMap(maps.first);
  }

  Future<int> insertTransaction(DebtTransaction transaction) async {
    final db = await appDatabase.database;
    return db.insert('transactions', transaction.toMap());
  }

  Future<int> insertTransactionWithTxn(DebtTransaction transaction, Transaction txn) =>
      txn.insert('transactions', transaction.toMap());

  Future<List<DebtTransaction>> getAllTransactions({bool includeArchived = false}) async {
    final db = await appDatabase.database;
    final maps = await db.query('transactions', where: includeArchived ? null : 'isArchived = 0', orderBy: 'date DESC');
    return maps.map((map) => DebtTransaction.fromMap(map)).toList();
  }

  Future<List<DebtTransaction>> getTransactionsByCustomer(int customerId, {bool includeArchived = false}) async {
    final db = await appDatabase.database;
    final maps = await db.query('transactions', where: includeArchived ? 'customerId = ?' : 'customerId = ? AND isArchived = 0', whereArgs: [customerId], orderBy: 'date DESC');
    return maps.map((map) => DebtTransaction.fromMap(map)).toList();
  }

  Future<List<int>> getTransactionIdsByCustomer(int customerId) async {
    final db = await appDatabase.database;
    final rows = await db.query('transactions', columns: ['id'], where: 'customerId = ?', whereArgs: [customerId]);
    return rows.map((row) => row['id'] as int).toList();
  }
}
