import 'package:sqflite/sqflite.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/recurring_schedule.dart';

class RecurringRepository {
  final AppDatabase appDatabase = AppDatabase();

  Future<int> insertSchedule(RecurringSchedule schedule) async {
    final db = await appDatabase.database;
    return db.insert('recurring_schedules', schedule.toMap());
  }

  Future<int> insertScheduleWithTxn(RecurringSchedule schedule, Transaction txn) =>
      txn.insert('recurring_schedules', schedule.toMap());


  Future<List<RecurringSchedule>> getAllSchedules() async {
    final db = await appDatabase.database;
    final result = await db.query('recurring_schedules', orderBy: 'nextRun ASC');
    return result.map((map) => RecurringSchedule.fromMap(map)).toList();
  }

  Future<List<RecurringSchedule>> getEnabledSchedules() async {
    final db = await appDatabase.database;
    final result = await db.query('recurring_schedules', where: 'enabled = 1', orderBy: 'nextRun ASC');
    return result.map((map) => RecurringSchedule.fromMap(map)).toList();
  }

  Future<List<RecurringSchedule>> getSchedulesByCustomer(int customerId) async {
    final db = await appDatabase.database;
    final result = await db.query('recurring_schedules', where: 'customerId = ?', whereArgs: [customerId], orderBy: 'nextRun ASC');
    return result.map((map) => RecurringSchedule.fromMap(map)).toList();
  }

  Future<int> updateScheduleWithTxn(RecurringSchedule schedule, Transaction txn) =>
      txn.update('recurring_schedules', schedule.toMap(), where: 'id = ?', whereArgs: [schedule.id]);

  Future<int> updateSchedule(RecurringSchedule schedule) async {
    final db = await appDatabase.database;
    return db.update('recurring_schedules', schedule.toMap(), where: 'id = ?', whereArgs: [schedule.id]);
  }

  Future<int> deleteSchedule(int id) async {
    final db = await appDatabase.database;
    return db.delete('recurring_schedules', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> toggleSchedule(int id, bool enabled) async {
    final db = await appDatabase.database;
    return db.update('recurring_schedules', {'enabled': enabled ? 1 : 0, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);
  }
}
