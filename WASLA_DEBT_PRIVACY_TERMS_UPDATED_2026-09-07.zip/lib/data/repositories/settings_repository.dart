import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';

class SettingsRepository {
  final AppDatabase appDatabase = AppDatabase();

  Future<void> saveSetting(String key, String value) async {
    final db = await appDatabase.database;
    await db.insert(
      'app_settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<String?> getSetting(String key) async {
    final db = await appDatabase.database;
    final List<Map<String, dynamic>> result = await db.query(
      'app_settings',
      where: 'key = ?',
      whereArgs: [key],
    );
    if (result.isNotEmpty) {
      return result.first['value'] as String;
    }
    return null;
  }
}