import 'dart:io';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/backup_metadata.dart';

class BackupRepository {
  final AppDatabase appDatabase = AppDatabase();

  Future<Map<String, dynamic>> buildBackupData({Map<String, dynamic>? sharedPreferences}) async {
    final db = await appDatabase.database;
    final backupData = <String, dynamic>{
      'schemaVersion': 2,
      'backupDate': DateTime.now().millisecondsSinceEpoch,
      'customers': await db.query('customers'),
      'transactions': await db.query('transactions'),
      'settlements': await db.query('settlements'),
      'payments': await db.query('payments'),
      'recurringSchedules': await db.query('recurring_schedules'),
      'settings': await db.query('app_settings'),
      'audit_logs': await db.query('audit_logs'),
    };
    if (sharedPreferences != null) {
      backupData['sharedPreferences'] = sharedPreferences;
    }
    return backupData;
  }

  void validateBackupData(Map<String, dynamic> data) {
    final version = data['schemaVersion'];
    if (version is! int || (version != 1 && version != 2)) {
      throw Exception('إصدار النسخة الاحتياطية غير مدعوم');
    }
    const requiredLists = ['customers', 'transactions', 'settlements', 'settings'];
    for (final key in requiredLists) {
      if (data[key] is! List) throw Exception('النسخة الاحتياطية تالفة: الحقل $key غير صالح');
    }
    for (final key in ['payments', 'recurringSchedules']) {
      if (data[key] != null && data[key] is! List) {
        throw Exception('النسخة الاحتياطية تالفة: الحقل $key غير صالح');
      }
    }
    if (version >= 2 && data['audit_logs'] is! List) {
      throw Exception('النسخة الاحتياطية تالفة: audit_logs مفقود أو غير صالح');
    }
    if (data['sharedPreferences'] != null && data['sharedPreferences'] is! Map) {
      throw Exception('النسخة الاحتياطية تالفة: الإعدادات غير صالحة');
    }
    _validateNumericFields(data['customers'] as List, ['id', 'createdAt', 'updatedAt']);
    _validateNumericFields(data['transactions'] as List, ['id', 'customerId', 'amount', 'date', 'createdAt', 'updatedAt']);
    _validateNumericFields(data['settlements'] as List, ['id', 'transactionId', 'amount', 'settledAt', 'createdAt']);
    if (data['payments'] is List) _validateNumericFields(data['payments'] as List, ['id', 'customerId', 'amount', 'paymentDate', 'createdAt', 'updatedAt']);
    if (data['recurringSchedules'] is List) _validateNumericFields(data['recurringSchedules'] as List, ['id', 'customerId', 'amount', 'nextRun', 'createdAt', 'updatedAt']);
    _validateRows(data['customers'] as List, ['id', 'name', 'createdAt', 'updatedAt']);
    _validateRows(data['transactions'] as List, ['id', 'customerId', 'type', 'amount', 'currency', 'date', 'createdAt', 'updatedAt']);
    _validateRows(data['settlements'] as List, ['id', 'transactionId', 'amount', 'currency', 'settledAt', 'createdAt']);
    _validateRows(data['settings'] as List, ['key', 'value']);
    if (data['payments'] is List) _validateRows(data['payments'] as List, ['id', 'customerId', 'amount', 'currency', 'paymentDate', 'createdAt', 'updatedAt']);
    if (data['recurringSchedules'] is List) _validateRows(data['recurringSchedules'] as List, ['id', 'customerId', 'amount', 'currency', 'type', 'interval', 'nextRun', 'enabled', 'createdAt', 'updatedAt']);
    if (data['audit_logs'] is List) _validateRows(data['audit_logs'] as List, ['id', 'entityType', 'entityId', 'action', 'timestamp']);
  }

  void _validateNumericFields(List rows, List<String> fields) {
    for (final row in rows) {
      final map = Map<String, dynamic>.from(row as Map);
      for (final field in fields) {
        final value = map[field];
        if (value is! num) throw Exception('النسخة الاحتياطية تالفة: الحقل $field يجب أن يكون رقميًا');
        if (field == 'amount') {
          final amount = value.toDouble();
          if (amount <= 0 || (amount * 100 - (amount * 100).round()).abs() > 0.000001) {
            throw Exception('النسخة الاحتياطية تالفة: مبلغ غير صالح أو يحتوي على أكثر من منزلتين عشريتين');
          }
        }
      }
    }
  }

  void _validateRows(List rows, List<String> fields) {
    for (final row in rows) {
      if (row is! Map) throw Exception('النسخة الاحتياطية تالفة: سجل غير صالح');
      for (final field in fields) {
        if (!row.containsKey(field)) throw Exception('النسخة الاحتياطية تالفة: الحقل $field مفقود');
      }
    }
  }

  Future<String> saveBackup(String filePath, List<int> bytes) async {
    await File(filePath).writeAsBytes(bytes, flush: true);
    return filePath;
  }

  Future<void> restoreBackup(Map<String, dynamic> data) async {
    validateBackupData(data);
    final db = await appDatabase.database;
    await db.transaction((txn) async {
      await txn.delete('payments');
      await txn.delete('settlements');
      await txn.delete('recurring_schedules');
      await txn.delete('audit_logs');
      await txn.delete('transactions');
      await txn.delete('customers');
      await txn.delete('app_settings');

      for (final customer in data['customers'] as List) {
        await txn.insert('customers', Map<String, dynamic>.from(customer));
      }
      for (final transaction in data['transactions'] as List) {
        await txn.insert('transactions', Map<String, dynamic>.from(transaction));
      }
      for (final settlement in data['settlements'] as List) {
        await txn.insert('settlements', Map<String, dynamic>.from(settlement));
      }
      for (final setting in data['settings'] as List) {
        await txn.insert('app_settings', Map<String, dynamic>.from(setting));
      }
      for (final rawSchedule in data['recurringSchedules'] as List? ?? const []) {
        final schedule = Map<String, dynamic>.from(rawSchedule as Map);
        if (schedule['currency'] is String) {
          schedule['currency'] = (schedule['currency'] as String).toUpperCase();
        }
        await txn.insert('recurring_schedules', schedule);
      }
      for (final payment in data['payments'] as List? ?? const []) {
        await txn.insert('payments', Map<String, dynamic>.from(payment));
      }
      for (final log in data['audit_logs'] as List? ?? const []) {
        await txn.insert('audit_logs', Map<String, dynamic>.from(log));
      }
    });
  }

  Future<void> saveBackupMetadata(BackupMetadata metadata) async {
    final db = await appDatabase.database;
    await db.insert('backup_metadata', metadata.toMap());
  }

  Future<BackupMetadata?> getLatestBackup() async {
    final db = await appDatabase.database;
    final result = await db.query('backup_metadata', orderBy: 'backupDate DESC', limit: 1);
    return result.isNotEmpty ? BackupMetadata.fromMap(result.first) : null;
  }

  Future<List<BackupMetadata>> getAllBackups() async {
    final db = await appDatabase.database;
    final result = await db.query('backup_metadata', orderBy: 'backupDate DESC');
    return result.map((m) => BackupMetadata.fromMap(m)).toList();
  }

  Future<void> deleteBackupMetadata(int id) async {
    final db = await appDatabase.database;
    await db.delete('backup_metadata', where: 'id = ?', whereArgs: [id]);
  }
}
