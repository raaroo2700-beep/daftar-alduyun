import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/customer.dart';

class CustomerRepository {
  final AppDatabase appDatabase = AppDatabase();

  Future<int> insertCustomer(Customer customer) async {
    final db = await appDatabase.database;
    return db.insert('customers', customer.toMap());
  }

  Future<int> insertCustomerWithTxn(Customer customer, Transaction txn) =>
      txn.insert('customers', customer.toMap());

  Future<List<Customer>> getCustomers({bool includeArchived = false}) async {
    final db = await appDatabase.database;
    final maps = await db.query('customers', where: includeArchived ? null : 'isArchived = 0', orderBy: 'name ASC');
    return maps.map((map) => Customer.fromMap(map)).toList();
  }

  Future<Customer?> getCustomerById(int id) async {
    final db = await appDatabase.database;
    final maps = await db.query('customers', where: 'id = ?', whereArgs: [id]);
    return maps.isNotEmpty ? Customer.fromMap(maps.first) : null;
  }

  Future<int> updateCustomer(Customer customer) async {
    final db = await appDatabase.database;
    return db.update('customers', customer.toMap(), where: 'id = ?', whereArgs: [customer.id]);
  }

  Future<int> updateCustomerWithTxn(Customer customer, Transaction txn) =>
      txn.update('customers', customer.toMap(), where: 'id = ?', whereArgs: [customer.id]);

  Future<Customer?> getCustomerByIdWithTxn(int id, Transaction txn) async {
    final maps = await txn.query('customers', where: 'id = ?', whereArgs: [id]);
    return maps.isNotEmpty ? Customer.fromMap(maps.first) : null;
  }

  Future<int> archiveCustomer(int id) async {
    final db = await appDatabase.database;
    return db.update('customers', {'isArchived': 1, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);
  }


  Future<int> archiveCustomerWithTxn(int id, Transaction txn) =>
      txn.update('customers', {'isArchived': 1, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);

  Future<int> restoreCustomerWithTxn(int id, Transaction txn) =>
      txn.update('customers', {'isArchived': 0, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);

  Future<int> restoreCustomer(int id) async {
    final db = await appDatabase.database;
    return db.update('customers', {'isArchived': 0, 'updatedAt': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteCustomerPermanently(int id) async {
    final db = await appDatabase.database;
    return db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteCustomerWithTxn(int id, Transaction txn) =>
      txn.delete('customers', where: 'id = ?', whereArgs: [id]);

  Future<int> countActiveCustomers() async {
    final db = await appDatabase.database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM customers WHERE isArchived = 0');
    return result.first['count'] as int;
  }
}
