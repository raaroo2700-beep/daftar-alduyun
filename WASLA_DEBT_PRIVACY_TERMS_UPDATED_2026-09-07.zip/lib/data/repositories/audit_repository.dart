import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/audit_log.dart';

class AuditRepository {
  final AppDatabase appDatabase = AppDatabase();

  Future<int> insertAuditLog(AuditLog auditLog) async {
    final db = await appDatabase.database;
    return db.insert('audit_logs', auditLog.toMap());
  }

  Future<int> insertAuditLogWithTxn(AuditLog auditLog, Transaction txn) =>
      txn.insert('audit_logs', auditLog.toMap());

  Future<List<AuditLog>> getAuditLogsByEntity({required int entityId, required String entityType}) async {
    final db = await appDatabase.database;
    final maps = await db.query('audit_logs', where: 'entityId = ? AND entityType = ?', whereArgs: [entityId, entityType], orderBy: 'timestamp DESC');
    return maps.map((map) => AuditLog.fromMap(map)).toList();
  }

  Future<List<AuditLog>> getAuditLogsByDateRange({required int start, required int end}) async {
    final db = await appDatabase.database;
    final maps = await db.query('audit_logs', where: 'timestamp >= ? AND timestamp <= ?', whereArgs: [start, end], orderBy: 'timestamp DESC');
    return maps.map((map) => AuditLog.fromMap(map)).toList();
  }

  Future<List<AuditLog>> getAllAuditLogs() async {
    final db = await appDatabase.database;
    final maps = await db.query('audit_logs', orderBy: 'timestamp DESC');
    return maps.map((map) => AuditLog.fromMap(map)).toList();
  }

  Future<AuditLog?> getAuditLogById(int id) async {
    final db = await appDatabase.database;
    final maps = await db.query('audit_logs', where: 'id = ?', whereArgs: [id]);
    return maps.isNotEmpty ? AuditLog.fromMap(maps.first) : null;
  }
}
