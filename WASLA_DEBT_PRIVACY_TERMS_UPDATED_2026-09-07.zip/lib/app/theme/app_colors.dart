import 'package:flutter/material.dart';

/// هوية Wasla Debt البصرية: هادئة، واضحة، وموجهة للأرقام المالية.
class AppColors {
  static const Color primary = Color(0xFF173B68);
  static const Color primaryDark = Color(0xFF0F2B4D);
  static const Color secondary = Color(0xFF16B981);

  static const Color background = Color(0xFFF5F7FB);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceSoft = Color(0xFFF8FAFD);
  static const Color text = Color(0xFF172033);
  static const Color textSecondary = Color(0xFF667085);

  // المعاني المالية الثابتة في كل الشاشات.
  static const Color credit = Color(0xFF16B981); // له
  static const Color debit = Color(0xFFEF4444); // عليه
  static const Color neutral = Color(0xFF7B8798); // متعادل / مسدد

  // الأرشفة إجراء عادي، لذلك برتقالي مختلف عن Warning.
  static const Color archive = Color(0xFFF97316);
  static const Color warning = Color(0xFFD99000);
  static const Color warningSoft = Color(0xFFFFF4D6);

  static const Color divider = Color(0xFFE6EAF0);
  static const Color hint = Color(0xFF98A2B3);
}
