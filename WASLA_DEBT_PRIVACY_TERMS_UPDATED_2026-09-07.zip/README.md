
## خدمة التفعيل

يوجد Backend كامل للتفعيل داخل `backend/` باستخدام Firebase Cloud Functions + Firestore.
قبل إصدار Release يجب نشر الـBackend ووضع عنوانه عبر `ACTIVATION_API_BASE_URL` باستخدام `--dart-define`.
لا توجد أسرار أو بيانات Firebase حقيقية داخل المشروع.
