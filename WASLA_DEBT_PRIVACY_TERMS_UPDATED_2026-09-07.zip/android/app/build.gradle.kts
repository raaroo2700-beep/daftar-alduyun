import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

// إصلاح 10.1: قراءة بيانات توقيع الإصدار من android/key.properties (لا تُرفع
// إلى نظام التحكم بالإصدارات — انظر android/key.properties.example للتعليمات).
val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
val hasReleaseSigning = keystorePropertiesFile.exists()
if (hasReleaseSigning) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "com.daftar.wasla_debt"
    compileSdk = 36

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.daftar.wasla_debt"
        minSdk = flutter.minSdkVersion
        targetSdk = 36
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }

    buildTypes {
        release {
            // لا نسمح بإنتاج Release موقّع بمفتاح debug. جهّز android/key.properties
            // محليًا أو عبر CI قبل بناء أي نسخة قابلة للتوزيع.
            if (!hasReleaseSigning) {
                throw GradleException("Release signing is not configured. Create android/key.properties from key.properties.example.")
            }
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

// التنسيق الجديد لـ Kotlin Compiler Options (بديل kotlinOptions الملغاة)
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

flutter {
    source = "../.."
}
