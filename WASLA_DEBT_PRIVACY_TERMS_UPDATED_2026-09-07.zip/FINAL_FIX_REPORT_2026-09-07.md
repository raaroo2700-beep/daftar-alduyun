# Wasla Debt — Final Fix Batch

Implemented against `wasla_debt_UI_DESIGN_v2_FIXED(1).zip`, using the supplied comprehensive inspection report and design appendix.

## Implemented

1. **Payment direction / balance correctness**
   - Added `PaymentDirection.customerToBusiness` and `PaymentDirection.businessToCustomer`.
   - Added a `direction` column to `payments` with migration to DB version 5.
   - Existing payments migrate as `customerToBusiness` to preserve their previous behavior.
   - `BalanceCalculator` now computes incoming and outgoing payments separately.
   - A payment made to a creditor reduces the creditor balance instead of increasing the debt.
   - Add/Edit Payment screens expose `دفع لي` / `دفعت له`.

2. **Per-currency customer limits**
   - Added YER/SAR/USD debt and credit limit fields.
   - DB migration copies legacy global limits to each currency so an upgrade does not silently remove an existing limit.
   - Customer edit screen now edits six currency-specific limits.
   - Limit checks in transaction, recurring, home and customer-details code use the selected transaction currency.

3. **Limit warnings instead of hard blocking for new transactions**
   - Transaction creation checks the projected balance before the DB write transaction.
   - Amber confirmation dialog offers `متابعة الحفظ` or `إلغاء`.

4. **Transfer warning / override**
   - Added a pre-check for insufficient source balance.
   - Amber confirmation dialog offers `متابعة التحويل` or `إلغاء`.
   - Transfer service supports an explicit `allowOverdraft` only after user confirmation.

5. **Currency tabs**
   - Home: `الكل / YER / SAR / USD` tabs are directly below the welcome header.
   - Selected currency filters customer list and summary cards.
   - Home uses `إجمالي عليك` / `إجمالي لك`.
   - If the selected currency has no balances, the two summary cards are replaced by `لا توجد أرصدة بهذه العملة`.
   - Customer details shows only currencies actually used by that customer and filters balance, transactions and payments accordingly.

6. **Customer transfer entry point**
   - Transfer screen accepts `initialCustomerId`.
   - Customer details now opens transfer directly with the current customer as source.

7. **Delete flow**
   - Active customer details no longer performs archive + permanent delete behind one confirmation.
   - Active details exposes archiving only; permanent deletion remains guarded by the service/archive flow.

8. **Customer name autocomplete**
   - Add Transaction now provides live customer-name suggestions.
   - When no exact suggestion exists, it exposes an explicit `إضافة عميل جديد باسم ...` option.
   - Existing exact-name / archived-customer matching logic remains in the provider.

9. **Backup/restore UX**
   - Added a blocking progress overlay during backup/restore so long ZIP/attachment operations visibly show that work is in progress.

10. **Recurring schedule isolation**
    - A failing recurring schedule no longer aborts processing of all other due schedules.
    - Limit-triggered recurring schedules are disabled after the failure so they do not repeatedly fail on every run.

11. **Tests updated**
    - Updated payment balance tests for direction-aware behavior.
    - Added payment-direction model round-trip coverage.

## Verification note

The execution environment used for this patch does not contain the Flutter/Dart SDK, so `flutter analyze` and `flutter test` could not be executed here. The modified Dart files were checked for balanced delimiters and the known report issues were patched directly. Run on the development machine:

```text
flutter pub get
flutter analyze
flutter test
```
