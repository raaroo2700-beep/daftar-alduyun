import 'dart:convert';
import 'package:archive/archive.dart';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:wasla_debt/core/services/activation_service.dart';
import 'package:wasla_debt/core/services/archive_service.dart';
import 'package:wasla_debt/core/services/backup_service.dart';
import 'package:wasla_debt/core/services/attachment_service.dart';
import 'package:image_picker/image_picker.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/repositories/audit_repository.dart';
import 'package:wasla_debt/data/repositories/backup_repository.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';
import 'package:path/path.dart' as p;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory dbDir;

  setUpAll(() async {
    databaseFactory = databaseFactoryFfi;
    dbDir = await Directory.systemTemp.createTemp('wasla_p0_04_07_');
    await databaseFactory.setDatabasesPath(dbDir.path);
    SharedPreferences.setMockInitialValues({
      'defaultCurrency': 'yer',
      'showTime': true,
      'darkMode': false,
      'maxBackups': 5,
      'autoBackup': false,
    });
    const channel = MethodChannel('plugins.flutter.io/path_provider');
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
      if (call.method == 'getApplicationDocumentsDirectory') {
        return dbDir.path;
      }
      if (call.method == 'getTemporaryDirectory') {
        return dbDir.path;
      }
      return null;
    });
  });

  tearDownAll(() async {
    try {
      await (await AppDatabase().database).close();
    } catch (_) {}
    if (await dbDir.exists()) {
      await dbDir.delete(recursive: true);
    }
    const channel = MethodChannel('plugins.flutter.io/path_provider');
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  test('P0-04 archive + audit is atomic', () async {
    final customerRepo = CustomerRepository();
    final transactionRepo = TransactionRepository();
    final now = DateTime.now().millisecondsSinceEpoch;
    final customerId = await customerRepo.insertCustomer(Customer(name: 'P0', createdAt: now, updatedAt: now));
    final id = await transactionRepo.insertTransaction(DebtTransaction(customerId: customerId, type: DebtType.credit, amount: 10, currency: Currency.yer, date: now, createdAt: now, updatedAt: now));
    await ArchiveService.archiveTransaction(transactionId: id);
    final tx = await transactionRepo.getTransactionById(id);
    final logs = await AuditRepository().getAuditLogsByEntity(entityId: id, entityType: 'transaction');
    expect(tx!.isArchived, isTrue);
    expect(logs, hasLength(1));
  });

  test('P0-04 transaction rolls back on failure', () async {
    final db = await AppDatabase().database;
    final customerRepo = CustomerRepository();
    final now = DateTime.now().millisecondsSinceEpoch;
    final before = await customerRepo.countActiveCustomers();
    expect(() async => db.transaction((txn) async {
      await txn.insert('customers', Customer(name: 'rollback', createdAt: now, updatedAt: now).toMap());
      throw Exception('forced failure');
    }), throwsException);
    expect(await customerRepo.countActiveCustomers(), before);
  });

  test('P0-05 backup schema v2 contains audit logs and archived rows', () async {
    final data = await (BackupService()).createBackup();
    final file = File(data);
    expect(await file.exists(), isTrue);
    final bytes = await file.readAsBytes();
    expect(bytes.length, greaterThan(0));
    final archive = ZipDecoder().decodeBytes(bytes);
    final backupJson = archive.findFile('backup.json');
    expect(backupJson, isNotNull);
    final json = jsonDecode(utf8.decode(backupJson!.content as List<int>)) as Map<String, dynamic>;
    expect(json['schemaVersion'], 2);
    expect(json['audit_logs'], isA<List>());
  });


  test('P0-06 attachment save enforces 10MB and uses relative references', () async {
    final dir = await Directory.systemTemp.createTemp('wasla_attachment_test_');
    final small = File('${dir.path}/photo.jpg');
    await small.writeAsBytes(List<int>.filled(32, 7));
    final service = AttachmentService();
    final relative = await service.saveAttachment(991234, XFile(small.path));
    expect(relative.startsWith('attachments/991234/'), isTrue);
    expect(p.basename(relative), isNot(contains('/')));
    expect(p.isAbsolute(relative), isFalse);
    final restored = await service.getAttachment(991234);
    expect(restored, isNotNull);
    await service.deleteAttachment(991234);

    final large = File('${dir.path}/large.bin');
    await large.writeAsBytes(List<int>.filled(10 * 1024 * 1024 + 1, 1));
    expect(() => service.saveAttachment(991235, XFile(large.path)), throwsException);
    await dir.delete(recursive: true);
  });

  test('P0-07 lifetime activation never expires', () async {
    final info = await ActivationService.verifyCode('WASLA-LIFE-9012-MNOP');
    expect(info, isNotNull);
    expect(info!.isLifetime, isTrue);
    expect(info.isActive, isTrue);
  });

  test('P0-05 legacy schema v1 is accepted when audit logs are absent', () async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final legacy = <String, dynamic>{
      'schemaVersion': 1,
      'backupDate': now,
      'customers': [], 'transactions': [], 'settlements': [], 'settings': [],
      'payments': [], 'recurringSchedules': [],
    };
    expect(() => BackupRepository().validateBackupData(legacy), returnsNormally);
  });
}

