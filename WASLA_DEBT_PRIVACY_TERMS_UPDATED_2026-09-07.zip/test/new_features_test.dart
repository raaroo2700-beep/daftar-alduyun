import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:wasla_debt/core/services/customer_service.dart';
import 'package:wasla_debt/core/services/recurring_service.dart';
import 'package:wasla_debt/core/services/transaction_service.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/payment_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

void main() {
  late Directory dir;
  setUpAll(() async {
    databaseFactory = databaseFactoryFfi;
    dir = await Directory.systemTemp.createTemp('wasla_new_features_');
    await databaseFactory.setDatabasesPath(dir.path);
  });
  tearDownAll(() async {
    try { await (await AppDatabase().database).close(); } catch (_) {}
    if (await dir.exists()) await dir.delete(recursive: true);
  });

  test('customer archive and restore preserve financial history', () async {
    final repo = CustomerRepository();
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = await repo.insertCustomer(Customer(name: 'أرشفة $now', createdAt: now, updatedAt: now));
    await CustomerService.archiveCustomer(id);
    expect((await repo.getCustomers()).any((c) => c.id == id), false);
    await CustomerService.restoreCustomer(id);
    expect((await repo.getCustomers()).any((c) => c.id == id), true);
  });

  test('transaction update is audited', () async {
    final cr = CustomerRepository(); final tr = TransactionRepository();
    final now = DateTime.now().millisecondsSinceEpoch;
    final customerId = await cr.insertCustomer(Customer(name: 'تعديل $now', createdAt: now, updatedAt: now));
    final id = await tr.insertTransaction(DebtTransaction(customerId: customerId, type: DebtType.debit, amount: 100, currency: Currency.yer, date: now, createdAt: now, updatedAt: now));
    final old = await tr.getTransactionById(id);
    await TransactionService.updateTransaction(transaction: old!.copyWith(amount: 150));
    expect((await tr.getTransactionById(id))!.amount, 150);
    final logs = await (await AppDatabase().database).query('audit_logs', where: 'entityType = ? AND entityId = ?', whereArgs: ['transaction', id]);
    expect(logs.any((x) => x['action'] == 'update'), true);
  });

  test('transfer creates balanced linked entries atomically', () async {
    final cr = CustomerRepository(); final tr = TransactionRepository();
    final now = DateTime.now().millisecondsSinceEpoch;
    final a = await cr.insertCustomer(Customer(name: 'مصدر $now', createdAt: now, updatedAt: now));
    final b = await cr.insertCustomer(Customer(name: 'مستلم $now', createdAt: now, updatedAt: now));
    await tr.insertTransaction(DebtTransaction(customerId: a, type: DebtType.debit, amount: 500, currency: Currency.yer, date: now, createdAt: now, updatedAt: now));
    await TransactionService.transfer(fromCustomerId: a, toCustomerId: b, amount: 200, currency: Currency.yer);
    expect((await tr.getTransactionsByCustomer(a)).where((t) => t.type == DebtType.credit && t.amount == 200).isNotEmpty, true);
    expect((await tr.getTransactionsByCustomer(b)).where((t) => t.type == DebtType.debit && t.amount == 200).isNotEmpty, true);
  });

  test('recurring service catches up missed periods', () async {
    final cr = CustomerRepository(); final tr = TransactionRepository();
    final now = DateTime.now();
    final customerId = await cr.insertCustomer(Customer(name: 'متكرر ${now.microsecondsSinceEpoch}', createdAt: now.millisecondsSinceEpoch, updatedAt: now.millisecondsSinceEpoch));
    final db = await AppDatabase().database;
    final start = now.subtract(const Duration(days: 3)).millisecondsSinceEpoch;
    await db.insert('recurring_schedules', {'customerId': customerId, 'amount': 10.0, 'currency': 'YER', 'type': 'debit', 'details': 'اختبار', 'interval': 'daily', 'nextRun': start, 'enabled': 1, 'createdAt': now.millisecondsSinceEpoch, 'updatedAt': now.millisecondsSinceEpoch});
    await RecurringService().processDueSchedules();
    expect((await tr.getTransactionsByCustomer(customerId)).length, 4);
  });

  test('payment repository still works with new customer schema', () async {
    final cr = CustomerRepository(); final pr = PaymentRepository();
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = await cr.insertCustomer(Customer(name: 'سداد $now', createdAt: now, updatedAt: now));
    await pr.insertPayment(Payment(customerId: id, amount: 50, currency: Currency.yer, paymentDate: now, createdAt: now, updatedAt: now));
    expect((await pr.getPaymentsByCustomer(id)).length, 1);
  });
}
