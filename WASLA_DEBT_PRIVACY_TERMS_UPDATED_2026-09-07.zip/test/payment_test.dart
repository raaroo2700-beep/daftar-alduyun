import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/payment_repository.dart';
import 'package:wasla_debt/data/repositories/transaction_repository.dart';

/// اختبارات P0-02 — الخطوة 16: Payment Model و PaymentRepository فقط.
///
/// يغطي هذا الملف:
/// - Payment Model: الإنشاء، toMap()، fromMap()، copyWith()، وحفظ/استرجاع Currency.
/// - PaymentRepository: جميع دوال CRUD (insert/get/update/delete).
///
/// ⚠️ لا يغطي هذا الملف منطق BalanceCalculator مع السدادات — ذلك مخصص
/// للخطوة 17 (test/services/balance/balance_calculator_with_payments_test.dart)
/// وخارج نطاق هذا الملف بالكامل.
void main() {
  group('Payment Model', () {
    test('إنشاء Payment بكل الحقول', () {
      final payment = Payment(
        id: 1,
        customerId: 10,
        amount: 250.5,
        currency: Currency.sar,
        transactionId: 99,
        note: 'دفعة أولى',
        paymentDate: 1000,
        createdAt: 2000,
        updatedAt: 3000,
      );

      expect(payment.id, 1);
      expect(payment.customerId, 10);
      expect(payment.amount, 250.5);
      expect(payment.currency, Currency.sar);
      expect(payment.direction, PaymentDirection.customerToBusiness);
      expect(payment.transactionId, 99);
      expect(payment.note, 'دفعة أولى');
      expect(payment.paymentDate, 1000);
      expect(payment.createdAt, 2000);
      expect(payment.updatedAt, 3000);
    });

    test('إنشاء Payment بدون الحقول الاختيارية (id, transactionId, note)', () {
      final payment = Payment(
        customerId: 5,
        amount: 100,
        currency: Currency.yer,
        paymentDate: 111,
        createdAt: 222,
        updatedAt: 333,
      );

      expect(payment.id, isNull);
      expect(payment.transactionId, isNull);
      expect(payment.note, isNull);
      expect(payment.customerId, 5);
      expect(payment.amount, 100);
      expect(payment.currency, Currency.yer);
    });

    test('toMap() يحوّل جميع الحقول بشكل صحيح', () {
      final payment = Payment(
        id: 7,
        customerId: 3,
        amount: 500,
        currency: Currency.usd,
        transactionId: 42,
        note: 'ملاحظة اختبار',
        paymentDate: 1700000000000,
        createdAt: 1700000001000,
        updatedAt: 1700000002000,
      );

      final map = payment.toMap();

      expect(map['id'], 7);
      expect(map['customerId'], 3);
      expect(map['amount'], 500);
      expect(map['currency'], 'USD');
      expect(map['transactionId'], 42);
      expect(map['note'], 'ملاحظة اختبار');
      expect(map['paymentDate'], 1700000000000);
      expect(map['createdAt'], 1700000001000);
      expect(map['updatedAt'], 1700000002000);
    });

    test('toMap() يحوّل الحقول الاختيارية غير المعبّأة إلى null', () {
      final payment = Payment(
        customerId: 3,
        amount: 500,
        currency: Currency.usd,
        paymentDate: 1,
        createdAt: 2,
        updatedAt: 3,
      );

      final map = payment.toMap();

      expect(map['id'], isNull);
      expect(map['transactionId'], isNull);
      expect(map['note'], isNull);
    });

    test('fromMap() يعيد بناء Payment مطابق للبيانات المُدخلة', () {
      final map = {
        'id': 15,
        'customerId': 8,
        'amount': 320.75,
        'currency': 'YER',
        'transactionId': 21,
        'note': 'سداد جزئي',
        'paymentDate': 4000,
        'createdAt': 5000,
        'updatedAt': 6000,
      };

      final payment = Payment.fromMap(map);

      expect(payment.id, 15);
      expect(payment.customerId, 8);
      expect(payment.amount, 320.75);
      expect(payment.currency, Currency.yer);
      expect(payment.transactionId, 21);
      expect(payment.note, 'سداد جزئي');
      expect(payment.paymentDate, 4000);
      expect(payment.createdAt, 5000);
      expect(payment.updatedAt, 6000);
    });

    test('toMap() ثم fromMap() يحافظان على نفس البيانات (round trip)', () {
      final original = Payment(
        id: 2,
        customerId: 4,
        amount: 999.99,
        currency: Currency.sar,
        transactionId: 6,
        note: 'اختبار round trip',
        paymentDate: 111,
        createdAt: 222,
        updatedAt: 333,
      );

      final rebuilt = Payment.fromMap(original.toMap());

      expect(rebuilt.id, original.id);
      expect(rebuilt.customerId, original.customerId);
      expect(rebuilt.amount, original.amount);
      expect(rebuilt.currency, original.currency);
      expect(rebuilt.transactionId, original.transactionId);
      expect(rebuilt.note, original.note);
      expect(rebuilt.paymentDate, original.paymentDate);
      expect(rebuilt.createdAt, original.createdAt);
      expect(rebuilt.updatedAt, original.updatedAt);
    });

    for (final currency in Currency.values) {
      test('Currency (${currency.name}) يُحفظ ويُسترجَع بشكل صحيح عبر toMap/fromMap', () {
        final payment = Payment(
          customerId: 1,
          amount: 10,
          currency: currency,
          paymentDate: 1,
          createdAt: 1,
          updatedAt: 1,
        );

        final rebuilt = Payment.fromMap(payment.toMap());
        expect(rebuilt.currency, currency);
      });
    }

    test('copyWith() بدون معاملات يعيد نفس القيم تماماً', () {
      final payment = Payment(
        id: 1,
        customerId: 2,
        amount: 3,
        currency: Currency.yer,
        transactionId: 4,
        note: 'ملاحظة',
        paymentDate: 5,
        createdAt: 6,
        updatedAt: 7,
      );

      final copy = payment.copyWith();

      expect(copy.id, payment.id);
      expect(copy.customerId, payment.customerId);
      expect(copy.amount, payment.amount);
      expect(copy.currency, payment.currency);
      expect(copy.transactionId, payment.transactionId);
      expect(copy.note, payment.note);
      expect(copy.paymentDate, payment.paymentDate);
      expect(copy.createdAt, payment.createdAt);
      expect(copy.updatedAt, payment.updatedAt);
    });

    test('copyWith() يحدّث الحقول المحدَّدة فقط ويُبقي باقي الحقول كما هي', () {
      final payment = Payment(
        id: 1,
        customerId: 2,
        amount: 100,
        currency: Currency.yer,
        transactionId: 4,
        note: 'قديم',
        paymentDate: 5,
        createdAt: 6,
        updatedAt: 7,
      );

      final updated = payment.copyWith(
        amount: 250,
        currency: Currency.usd,
        note: 'جديد',
      );

      // الحقول المحدَّثة
      expect(updated.amount, 250);
      expect(updated.currency, Currency.usd);
      expect(updated.note, 'جديد');

      // باقي الحقول يجب أن تبقى دون تغيير
      expect(updated.id, payment.id);
      expect(updated.customerId, payment.customerId);
      expect(updated.transactionId, payment.transactionId);
      expect(updated.paymentDate, payment.paymentDate);
      expect(updated.createdAt, payment.createdAt);
      expect(updated.updatedAt, payment.updatedAt);
    });
  });

  test('اتجاه السداد يُحفظ ويُسترجع ويُغيّر الرصيد حسب الاتجاه', () {
    final payment = Payment(
      customerId: 1,
      amount: 20,
      currency: Currency.yer,
      direction: PaymentDirection.businessToCustomer,
      paymentDate: 1,
      createdAt: 1,
      updatedAt: 1,
    );
    final rebuilt = Payment.fromMap(payment.toMap());
    expect(rebuilt.direction, PaymentDirection.businessToCustomer);
  });

  group('PaymentRepository (CRUD)', () {
    // إصلاح اختبار فقط: كل ملف اختبار كان يعتمد على المسار الافتراضي
    // لـ getDatabasesPath() في sqflite_common_ffi، وهو نفس المسار الفعلي
    // على القرص لكل ملفات الاختبار. عند تشغيل flutter test عدة ملفات
    // بالتوازي (payment_test.dart و recurring_test.dart معًا)، كانت جميعها
    // تفتح نفس ملف قاعدة البيانات الحقيقي في نفس الوقت → "database is
    // locked". الحل هنا: توجيه هذا الملف إلى مجلد مؤقت خاص به وحده عبر
    // databaseFactory.setDatabasesPath، بدون أي تغيير في lib/app_database.dart.
    late Directory tempDbDir;

    setUpAll(() async {
      databaseFactory = databaseFactoryFfi;
      tempDbDir = await Directory.systemTemp.createTemp('wasla_debt_payment_test_');
      await databaseFactory.setDatabasesPath(tempDbDir.path);
    });

    tearDownAll(() async {
      // إغلاق الاتصال الحقيقي بقاعدة البيانات بعد انتهاء كل اختبارات هذا
      // الملف (وليس بعد كل اختبار منفرد، لأن AppDatabase كائن Singleton
      // يُعاد استخدامه عبر جميع اختبارات هذا الملف عمدًا — إغلاقه بين كل
      // اختبار ومنفرد كان سيكسر الاختبارات التالية في نفس الملف).
      final db = await AppDatabase().database;
      await db.close();
      await tempDbDir.delete(recursive: true);
    });

    late CustomerRepository customerRepo;
    late PaymentRepository paymentRepo;
    late TransactionRepository transactionRepo;
    late int customerId;

    // ننشئ عميلاً جديداً قبل كل اختبار لعزل بيانات كل اختبار عن الآخر،
    // لأن قاعدة البيانات هنا حقيقية (sqflite_common_ffi) ولا تُصفَّر تلقائياً
    // بين الاختبارات (نفس سلوك database_test.dart الحالي في المشروع).
    setUp(() async {
      customerRepo = CustomerRepository();
      paymentRepo = PaymentRepository();
      transactionRepo = TransactionRepository();

      final now = DateTime.now().millisecondsSinceEpoch;
      customerId = await customerRepo.insertCustomer(
        Customer(
          name: 'عميل اختبار السداد $now',
          createdAt: now,
          updatedAt: now,
        ),
      );
    });

    Payment buildPayment({int? transactionId, String? note}) {
      final now = DateTime.now().millisecondsSinceEpoch;
      return Payment(
        customerId: customerId,
        amount: 150,
        currency: Currency.yer,
        transactionId: transactionId,
        note: note ?? 'دفعة اختبار',
        paymentDate: now,
        createdAt: now,
        updatedAt: now,
      );
    }

    test('insertPayment() يُدرج السداد ويُعيد id أكبر من صفر', () async {
      final id = await paymentRepo.insertPayment(buildPayment());
      expect(id, greaterThan(0));
    });

    test('getPaymentById() يُعيد السداد الصحيح بعد إدراجه', () async {
      final id = await paymentRepo.insertPayment(
        buildPayment(note: 'ملاحظة getPaymentById'),
      );

      final payment = await paymentRepo.getPaymentById(id);

      expect(payment, isNotNull);
      expect(payment!.id, id);
      expect(payment.customerId, customerId);
      expect(payment.note, 'ملاحظة getPaymentById');
    });

    test('getPaymentById() يُعيد null لمعرّف غير موجود', () async {
      final payment = await paymentRepo.getPaymentById(999999999);
      expect(payment, isNull);
    });

    test('getPaymentsByCustomer() يُعيد سدادات هذا العميل فقط', () async {
      await paymentRepo.insertPayment(buildPayment(note: 'دفعة 1'));
      await paymentRepo.insertPayment(buildPayment(note: 'دفعة 2'));

      // عميل آخر منفصل تماماً — سداداته يجب ألا تظهر في نتيجة العميل الأول
      final now = DateTime.now().millisecondsSinceEpoch;
      final otherCustomerId = await customerRepo.insertCustomer(
        Customer(name: 'عميل آخر $now', createdAt: now, updatedAt: now),
      );
      await paymentRepo.insertPayment(
        Payment(
          customerId: otherCustomerId,
          amount: 50,
          currency: Currency.yer,
          paymentDate: now,
          createdAt: now,
          updatedAt: now,
        ),
      );

      final payments = await paymentRepo.getPaymentsByCustomer(customerId);

      expect(payments.length, 2);
      expect(payments.every((p) => p.customerId == customerId), isTrue);
    });

    test('getAllPayments() يحتوي على السدادات المُدرَجة حديثاً', () async {
      final id = await paymentRepo.insertPayment(
        buildPayment(note: 'ملاحظة getAllPayments'),
      );

      final all = await paymentRepo.getAllPayments();

      expect(all.any((p) => p.id == id), isTrue);
    });

    test('getPaymentsByTransaction() يُعيد سدادات هذه المعاملة فقط', () async {
      final now = DateTime.now().millisecondsSinceEpoch;
      final transactionId = await transactionRepo.insertTransaction(
        DebtTransaction(
          customerId: customerId,
          type: DebtType.debit,
          amount: 300,
          currency: Currency.yer,
          date: now,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await paymentRepo.insertPayment(
        buildPayment(transactionId: transactionId, note: 'سداد مرتبط بمعاملة'),
      );
      // سداد غير مرتبط بأي معاملة — يجب ألا يظهر في نتيجة getPaymentsByTransaction
      await paymentRepo.insertPayment(buildPayment());

      final payments =
          await paymentRepo.getPaymentsByTransaction(transactionId);

      expect(payments.length, 1);
      expect(payments.first.transactionId, transactionId);
    });

    test('updatePayment() يحدّث بيانات السداد بنجاح', () async {
      final id = await paymentRepo.insertPayment(
        buildPayment(note: 'قبل التحديث'),
      );
      final original = await paymentRepo.getPaymentById(id);

      final updatedPayment = original!.copyWith(
        amount: 777,
        note: 'بعد التحديث',
      );
      final result = await paymentRepo.updatePayment(updatedPayment);
      expect(result, 1);

      final fetched = await paymentRepo.getPaymentById(id);
      expect(fetched!.amount, 777);
      expect(fetched.note, 'بعد التحديث');
    });

    test('deletePayment() يحذف السداد نهائياً', () async {
      final id = await paymentRepo.insertPayment(buildPayment());

      final result = await paymentRepo.deletePayment(id);
      expect(result, 1);

      final fetched = await paymentRepo.getPaymentById(id);
      expect(fetched, isNull);
    });
  });
}
