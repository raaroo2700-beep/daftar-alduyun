import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart'; // ✅ أضف هذا
import 'package:wasla_debt/data/models/recurring_schedule.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/repositories/recurring_repository.dart';

void main() {
  // إصلاح اختبار فقط: توجيه قاعدة بيانات هذا الملف إلى مجلد مؤقت خاص به
  // (بدل المسار الافتراضي المشترك مع باقي ملفات الاختبار) لمنع "database
  // is locked" عند تشغيل flutter test لعدة ملفات بالتوازي (هذا الملف
  // و payment_test.dart وغيرهما، وكلها كانت تفتح نفس ملف قاعدة البيانات
  // الفعلي في آنٍ واحد).
  late Directory tempDbDir;

  setUpAll(() async {
    databaseFactory = databaseFactoryFfi;
    tempDbDir = await Directory.systemTemp.createTemp('wasla_debt_recurring_test_');
    await databaseFactory.setDatabasesPath(tempDbDir.path);
  });

  tearDownAll(() async {
    final db = await AppDatabase().database;
    await db.close();
    await tempDbDir.delete(recursive: true);
  });

  test('CRUD recurring schedule', () async {
    final repo = RecurringRepository();

    // إصلاح اختبار فقط: recurring_schedules.customerId عليه FOREIGN KEY
    // على customers(id) وقاعدة البيانات تُفعِّل PRAGMA foreign_keys = ON،
    // فيجب إدراج عميل حقيقي أولاً بدل استخدام customerId: 1 الوهمي غير
    // الموجود فعليًا في الجدول.
    final customerRepo = CustomerRepository();
    final now = DateTime.now().millisecondsSinceEpoch;
    final customerId = await customerRepo.insertCustomer(
      Customer(
        name: 'عميل اختبار الجدولة المتكررة $now',
        createdAt: now,
        updatedAt: now,
      ),
    );

    final schedule = RecurringSchedule(
      customerId: customerId,
      amount: 100,
      currency: Currency.yer,
      type: DebtType.credit,
      interval: RecurringInterval.daily,
      nextRun: DateTime.now().millisecondsSinceEpoch + 86400000,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      updatedAt: DateTime.now().millisecondsSinceEpoch,
    );

    final id = await repo.insertSchedule(schedule);
    expect(id, greaterThan(0));

    final list = await repo.getEnabledSchedules();
    expect(list.isNotEmpty, true);

    await repo.toggleSchedule(id, false);
    final disabled = await repo.getEnabledSchedules();
    expect(disabled.any((s) => s.id == id), false);

    await repo.deleteSchedule(id);
  });
}