import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:wasla_debt/data/database/app_database.dart';
import 'package:wasla_debt/main.dart';

void main() {
  late Directory tempDbDir;

  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});

    // إصلاح اختبار فقط: SplashScreen في lib/main.dart يستدعي فعليًا
    // RecurringService و BackupService عند الإقلاع، وكلاهما يفتح
    // AppDatabase (sqflite) داخليًا. بدون تعيين databaseFactory هنا يفشل
    // الاختبار بخطأ "Bad state: databaseFactory not initialized". كما في
    // payment_test.dart و recurring_test.dart، نوجّه قاعدة بيانات هذا
    // الملف إلى مجلد مؤقت خاص به لمنع "database is locked" الناتج عن
    // مشاركة نفس مسار قاعدة البيانات الافتراضي مع ملفات اختبار أخرى قد
    // تعمل بالتوازي.
    databaseFactory = databaseFactoryFfi;
    tempDbDir = await Directory.systemTemp.createTemp('wasla_debt_widget_test_');
    await databaseFactory.setDatabasesPath(tempDbDir.path);
  });

  tearDownAll(() async {
    final db = await AppDatabase().database;
    await db.close();
    await tempDbDir.delete(recursive: true);
  });

  testWidgets('App shows welcome message', (WidgetTester tester) async {
    // إصلاح اختبار فقط: MyApp هي ConsumerWidget (تستخدم
    // ref.watch(settingsProvider))، فيجب تغليفها بـ ProviderScope تمامًا
    // كما يفعل main() الفعلي في lib/main.dart، وإلا يفشل pumpWidget فورًا
    // بخطأ "No ProviderScope found".
    await tester.pumpWidget(
      const ProviderScope(
        child: MyApp(),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('مرحباً في دفتر الديون'), findsOneWidget);
  });
}