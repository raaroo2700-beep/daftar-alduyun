import 'package:flutter_test/flutter_test.dart';
import 'package:wasla_debt/core/utils/money_format.dart';
import 'package:wasla_debt/core/utils/money_validator.dart';

void main() {
  test('money formatting never rounds 100.50 to 101', () {
    expect(MoneyFormat.amount(100.50), '100.5');
    expect(MoneyFormat.amount(100), '100');
    expect(MoneyFormat.amount(0.25), '0.25');
    expect(MoneyFormat.amount(-12.75), '-12.75');
  });

  test('money validator accepts at most two decimal places', () {
    expect(MoneyValidator.hasAtMostTwoDecimals(100), isTrue);
    expect(MoneyValidator.hasAtMostTwoDecimals(100.5), isTrue);
    expect(MoneyValidator.hasAtMostTwoDecimals(100.55), isTrue);
    expect(MoneyValidator.hasAtMostTwoDecimals(100.555), isFalse);
  });
}
