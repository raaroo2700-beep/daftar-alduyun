import 'package:flutter_test/flutter_test.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';

/// اختبارات Task P0-01 — BalanceCalculator / BalanceResult فقط.
///
/// المرجع: P0-01_FINAL_AUDIT.txt القسم 12 (قائمة الاختبارات المطلوبة
/// حرفيًا) + 01_REQUIREMENTS.md القسم 4.
///
/// التعريف المعتمد:
/// - "عليه" (DebtType.debit) → totalDebit (موجب).
/// - "له" (DebtType.credit) → totalCredit (موجب).
/// - balance = totalDebit - totalCredit.
///
/// ⚠️ هذه الاختبارات لا تختبر السداد (Settlement) بأي شكل — ذلك خارج نطاق
/// P0-01 بالكامل ومخصص لـ P0-02. المعاملات هنا كلها من نوع DebtTransaction
/// (عليه/له) فقط.
void main() {
  int ts = 0;
  int nextTs() => ++ts;

  DebtTransaction tx({
    required DebtType type,
    required double amount,
    Currency currency = Currency.yer,
    int customerId = 1,
  }) {
    final t = nextTs();
    return DebtTransaction(
      customerId: customerId,
      type: type,
      amount: amount,
      currency: currency,
      date: t,
      createdAt: t,
      updatedAt: t,
    );
  }

  group('BalanceCalculator.calculateClientBalance — حالات P0-01_FINAL_AUDIT.txt القسم 12', () {
    test('عميل عليه 100 فقط → totalDebit=100, totalCredit=0, balance=100', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.debit, amount: 100)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 100);
      expect(r.totalCredit, 0);
      expect(r.balance, 100);
      expect(r.isDebtor, isTrue);
    });

    test('عميل له 100 فقط → totalDebit=0, totalCredit=100, balance=-100', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.credit, amount: 100)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 0);
      expect(r.totalCredit, 100);
      expect(r.balance, -100);
      expect(r.isCreditor, isTrue);
    });

    test('عميل عليه 100 وله 50 → totalDebit=100, totalCredit=50, balance=50', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [
          tx(type: DebtType.debit, amount: 100),
          tx(type: DebtType.credit, amount: 50),
        ],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 100);
      expect(r.totalCredit, 50);
      expect(r.balance, 50);
    });

    test('عميل عليه 200 وله 300 → balance=-100 (صاحب الدفتر مدين للعميل)', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [
          tx(type: DebtType.debit, amount: 200),
          tx(type: DebtType.credit, amount: 300),
        ],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 200);
      expect(r.totalCredit, 300);
      expect(r.balance, -100);
      expect(r.isCreditor, isTrue);
    });

    test('عميل عليه YER وله SAR → عملات منفصلة', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [
          tx(type: DebtType.debit, amount: 100, currency: Currency.yer),
          tx(type: DebtType.credit, amount: 40, currency: Currency.sar),
        ],
      );

      final yer = result[Currency.yer]!;
      expect(yer.totalDebit, 100);
      expect(yer.totalCredit, 0);
      expect(yer.balance, 100);

      final sar = result[Currency.sar]!;
      expect(sar.totalDebit, 0);
      expect(sar.totalCredit, 40);
      expect(sar.balance, -40);

      // لا يوجد أي دمج بين العملتين في مفتاح واحد.
      expect(result.length, 2);
    });

    test('بدون معاملات → Map فارغ', () {
      final result = BalanceCalculator.calculateClientBalance(transactions: const []);
      expect(result, isEmpty);
    });

    test('معاملات متعددة بنفس العملة → مجموع صحيح', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [
          tx(type: DebtType.debit, amount: 100),
          tx(type: DebtType.debit, amount: 25),
          tx(type: DebtType.credit, amount: 10),
          tx(type: DebtType.credit, amount: 5),
        ],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 125); // 100 + 25
      expect(r.totalCredit, 15); // 10 + 5
      expect(r.balance, 110); // 125 - 15
    });
  });

  group('BalanceCalculator.calculateTotalBalance — نفس المنطق على مجموعة معاملات عامة', () {
    test('يُعطي نفس نتيجة calculateClientBalance لنفس المدخلات', () {
      final transactions = [
        tx(type: DebtType.debit, amount: 300, currency: Currency.usd),
        tx(type: DebtType.credit, amount: 120, currency: Currency.usd),
      ];

      final client = BalanceCalculator.calculateClientBalance(transactions: transactions);
      final total = BalanceCalculator.calculateTotalBalance(transactions: transactions);

      expect(total[Currency.usd]!.balance, client[Currency.usd]!.balance);
      expect(total[Currency.usd]!.totalDebit, 300);
      expect(total[Currency.usd]!.totalCredit, 120);
      expect(total[Currency.usd]!.balance, 180);
    });

    test('بدون معاملات → Map فارغ', () {
      final result = BalanceCalculator.calculateTotalBalance(transactions: const []);
      expect(result, isEmpty);
    });
  });

  group('BalanceResult — الحالات الحدية للنموذج نفسه', () {
    test('balance = totalDebit - totalCredit يُحسب تلقائيًا في المُنشئ', () {
      const r = BalanceResult(
        currency: Currency.yer,
        totalDebit: 70,
        totalCredit: 20,
      );
      expect(r.balance, 50);
      expect(r.isDebtor, isTrue);
      expect(r.isCreditor, isFalse);
      expect(r.isZero, isFalse);
    });

    test('balance = 0 عند تساوي totalDebit وtotalCredit', () {
      const r = BalanceResult(
        currency: Currency.yer,
        totalDebit: 40,
        totalCredit: 40,
      );
      expect(r.balance, 0);
      expect(r.isZero, isTrue);
      expect(r.isDebtor, isFalse);
      expect(r.isCreditor, isFalse);
    });
  });
}
