import 'package:flutter_test/flutter_test.dart';
import 'package:wasla_debt/core/services/balance_calculator.dart';
import 'package:wasla_debt/data/models/balance_result.dart';
import 'package:wasla_debt/data/models/debt_transaction.dart';
import 'package:wasla_debt/data/models/payment.dart';

/// اختبارات P0-02 — الخطوة 17 (الأخيرة): BalanceCalculator مع السداد.
///
/// المرجع: خطة P0-02 الخطوة 17 + خطة P0-02 الخطوة 6 (منطق BalanceCalculator
/// نفسه، المُنفَّذ مسبقًا) + P0-01_FINAL_AUDIT.txt القسم 12 (أسلوب الاختبارات).
///
/// التعريف المعتمد (كما في lib/data/models/balance_result.dart):
/// - "عليه" (DebtType.debit) → totalDebit (موجب).
/// - "له" (DebtType.credit) → totalCredit (موجب).
/// - كل Payment → totalPayments (موجب).
/// - balance = totalDebit - totalCredit - totalPayments.
///
/// ⚠️ هذا الملف يختبر BalanceCalculator فقط (Model محض، بدون قاعدة بيانات)،
/// ولا يكرر أي اختبار من test/services/balance_calculator_test.dart (P0-01،
/// بلا سداد إطلاقًا) ولا من test/payment_test.dart (Model/Repository الخطوة 16).
void main() {
  int ts = 0;
  int nextTs() => ++ts;

  DebtTransaction tx({
    required DebtType type,
    required double amount,
    Currency currency = Currency.yer,
    int customerId = 1,
  }) {
    final t = nextTs();
    return DebtTransaction(
      customerId: customerId,
      type: type,
      amount: amount,
      currency: currency,
      date: t,
      createdAt: t,
      updatedAt: t,
    );
  }

  Payment pay({
    required double amount,
    Currency currency = Currency.yer,
    int customerId = 1,
    PaymentDirection direction = PaymentDirection.customerToBusiness,
  }) {
    final t = nextTs();
    return Payment(
      customerId: customerId,
      amount: amount,
      currency: currency,
      direction: direction,
      paymentDate: t,
      createdAt: t,
      updatedAt: t,
    );
  }

  group('BalanceCalculator.calculateClientBalance — مع السداد (P0-02 الخطوة 17)', () {
    test('عليه 100 بدون أي سداد → totalPayments=0, balance=100 (بدون تغيير عن P0-01)', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.debit, amount: 100)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 100);
      expect(r.totalCredit, 0);
      expect(r.totalPayments, 0);
      expect(r.balance, 100);
      expect(r.isDebtor, isTrue);
    });

    test('عليه 100 وسداد كامل 100 → balance=0 (متعادل)', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.debit, amount: 100)],
        payments: [pay(amount: 100)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 100);
      expect(r.totalPayments, 100);
      expect(r.balance, 0);
      expect(r.isZero, isTrue);
    });

    test('عليه 100 وسداد جزئي 40 → balance=60 (لا يزال مدينًا)', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.debit, amount: 100)],
        payments: [pay(amount: 40)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 100);
      expect(r.totalPayments, 40);
      expect(r.balance, 60);
      expect(r.isDebtor, isTrue);
    });

    test('عليه 100 وسداد زائد 150 → balance=-50 (صاحب الدفتر مدين للعميل)', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.debit, amount: 100)],
        payments: [pay(amount: 150)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalDebit, 100);
      expect(r.totalPayments, 150);
      expect(r.balance, -50);
      expect(r.isCreditor, isTrue);
    });

    test('له 100 (credit) ودفع 20 للعميل → balance=-80 (الدفع يقلل الدين له)', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.credit, amount: 100)],
        payments: [pay(amount: 20, direction: PaymentDirection.businessToCustomer)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalCredit, 100);
      expect(r.totalPayments, 20);
      expect(r.totalPaymentsPaid, 20);
      expect(r.balance, -80);
      expect(r.isCreditor, isTrue);
    });

    test('عدة سدادات بنفس العملة → تُجمَع بشكل صحيح في totalPayments', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.debit, amount: 200)],
        payments: [
          pay(amount: 30),
          pay(amount: 20),
          pay(amount: 10),
        ],
      );
      final r = result[Currency.yer]!;
      expect(r.totalPayments, 60); // 30 + 20 + 10
      expect(r.balance, 140); // 200 - 60
    });

    test('سدادات بعملات مختلفة → كل عملة تُحسب بشكل مستقل تمامًا', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [
          tx(type: DebtType.debit, amount: 100, currency: Currency.yer),
          tx(type: DebtType.debit, amount: 50, currency: Currency.sar),
        ],
        payments: [
          pay(amount: 30, currency: Currency.yer),
          pay(amount: 50, currency: Currency.sar),
        ],
      );

      final yer = result[Currency.yer]!;
      expect(yer.totalDebit, 100);
      expect(yer.totalPayments, 30);
      expect(yer.balance, 70);

      final sar = result[Currency.sar]!;
      expect(sar.totalDebit, 50);
      expect(sar.totalPayments, 50);
      expect(sar.balance, 0);
      expect(sar.isZero, isTrue);

      // لا يوجد أي دمج أو تسرّب بين العملتين
      expect(result.length, 2);
    });

    test('سداد بعملة لا توجد لها أي معاملات إطلاقًا → تظهر العملة في النتيجة بالسالب', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: const [],
        payments: [pay(amount: 75, currency: Currency.usd)],
      );

      expect(result.containsKey(Currency.usd), isTrue);
      final usd = result[Currency.usd]!;
      expect(usd.totalDebit, 0);
      expect(usd.totalCredit, 0);
      expect(usd.totalPayments, 75);
      expect(usd.balance, -75);
      expect(usd.isCreditor, isTrue);
    });

    test('بدون معاملات وبدون سدادات → Map فارغ', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: const [],
        payments: const [],
      );
      expect(result, isEmpty);
    });

    test('عدم تمرير payments إطلاقًا (استدعاء قديم من P0-01) → لا ينكسر، totalPayments=0', () {
      final result = BalanceCalculator.calculateClientBalance(
        transactions: [tx(type: DebtType.debit, amount: 100)],
      );
      final r = result[Currency.yer]!;
      expect(r.totalPayments, 0);
      expect(r.balance, 100);
    });
  });

  group('BalanceCalculator.calculateTotalBalance — نفس منطق السداد على مجموعة عامة', () {
    test('يُعطي نفس نتيجة calculateClientBalance عند تمرير نفس المعاملات والسدادات', () {
      final transactions = [
        tx(type: DebtType.debit, amount: 300, currency: Currency.usd),
      ];
      final payments = [pay(amount: 100, currency: Currency.usd)];

      final client = BalanceCalculator.calculateClientBalance(
        transactions: transactions,
        payments: payments,
      );
      final total = BalanceCalculator.calculateTotalBalance(
        transactions: transactions,
        payments: payments,
      );

      expect(total[Currency.usd]!.balance, client[Currency.usd]!.balance);
      expect(total[Currency.usd]!.totalPayments, 100);
      expect(total[Currency.usd]!.balance, 200); // 300 - 0 - 100
    });
  });

  group('BalanceResult — الحالات الحدية لحقل totalPayments نفسه', () {
    test('totalPayments الافتراضي = 0.0 عند عدم تمريره', () {
      const r = BalanceResult(
        currency: Currency.yer,
        totalDebit: 70,
        totalCredit: 20,
      );
      expect(r.totalPayments, 0);
      expect(r.balance, 50); // 70 - 20 - 0 (بدون تغيير عن P0-01)
    });

    test('balance = totalDebit - totalCredit - totalPayments يُحسب تلقائيًا في المُنشئ', () {
      const r = BalanceResult(
        currency: Currency.yer,
        totalDebit: 100,
        totalCredit: 30,
        totalPayments: 20,
      );
      expect(r.balance, 50); // 100 - 30 - 20
      expect(r.isDebtor, isTrue);
    });
  });
}
