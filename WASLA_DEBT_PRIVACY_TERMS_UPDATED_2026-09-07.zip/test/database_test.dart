import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:wasla_debt/data/models/customer.dart';
import 'package:wasla_debt/data/repositories/customer_repository.dart';
import 'package:wasla_debt/data/database/app_database.dart';

void main() {
  // تهيئة databaseFactory قبل أي اختبار
  late Directory dbDir;

  setUpAll(() async {
    databaseFactory = databaseFactoryFfi;
    dbDir = await Directory.systemTemp.createTemp('wasla_database_test_');
    await databaseFactory.setDatabasesPath(dbDir.path);
  });

  tearDownAll(() async {
    try {
      await (await AppDatabase().database).close();
    } catch (_) {}
    if (await dbDir.exists()) {
      await dbDir.delete(recursive: true);
    }
  });

  test('CRUD customer test', () async {
    final repo = CustomerRepository();
    final customer = Customer(
      name: 'أحمد محمد',
      phone: '123456789',
      note: 'عميل جديد',
      createdAt: DateTime.now().millisecondsSinceEpoch,
      updatedAt: DateTime.now().millisecondsSinceEpoch,
    );

    int id = await repo.insertCustomer(customer);
    expect(id, greaterThan(0));

    final customers = await repo.getCustomers();
    expect(customers.isNotEmpty, true);

    final updated = customers.first.copyWith(name: 'أحمد علي');
    int updateResult = await repo.updateCustomer(updated);
    expect(updateResult, 1);

    int archiveResult = await repo.archiveCustomer(id);
    expect(archiveResult, 1);

    int deleteResult = await repo.deleteCustomerPermanently(id);
    expect(deleteResult, 1);
  });
}
