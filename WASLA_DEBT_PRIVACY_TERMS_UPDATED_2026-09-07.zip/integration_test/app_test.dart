import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:integration_test/integration_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:wasla_debt/main.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // إصلاحات اختبار فقط، بنفس أسلوب باقي ملفات test/ الحالية في المشروع
  // (test/widget_test.dart و test/database_test.dart)، بدون أي تغيير في UI
  // أو في lib/:
  // 1) SharedPreferences.setMockInitialValues: SplashScreen يستدعي
  //    SharedPreferences.getInstance() فعليًا عند بدء التطبيق (للتحقق من
  //    onboarding_completed)، وبدون هذا الـ mock يفشل عبر قناة منصّة غير
  //    متاحة في بيئة الاختبار.
  // 2) databaseFactoryFfi: SplashScreen يستدعي أيضًا RecurringService
  //    و BackupService واللذان يستخدمان AppDatabase (sqflite) داخليًا؛
  //    بدون تحويل databaseFactory إلى النسخة القائمة على FFI يفشل الوصول
  //    لقاعدة البيانات الحقيقية في بيئة الاختبار (لا يوجد جهاز فعلي).
  setUpAll(() {
    SharedPreferences.setMockInitialValues({});
    databaseFactory = databaseFactoryFfi;
  });

  testWidgets('Full app flow test', (tester) async {
    // إصلاح اختبار فقط: MyApp هي ConsumerWidget، فيجب تغليفها بـ
    // ProviderScope تمامًا كما يفعل main() الفعلي في lib/main.dart.
    await tester.pumpWidget(
      const ProviderScope(
        child: MyApp(),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('مرحباً في دفتر الديون'), findsOneWidget);
  });
}