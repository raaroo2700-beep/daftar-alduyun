# Task Report

ID: P0-01
Name: تثبيت منطق الرصيد (Balance Calculator مركزي)
Status: **P0-01 = NOT APPROVED** (بانتظار مراجعة تشغيل فعلي للاختبارات في بيئة تملك Flutter SDK — هذه الجولة معالجة لملاحظات المراجعة المستقلة الأولى فقط)

## Goal

إنشاء مصدر مركزي واحد لحساب الرصيد النهائي، توحيد معنى "عليه/له" وفق
`01_REQUIREMENTS.md`، فصل العملات، وربط `customer_details_provider.dart`
و`home_provider.dart` و`reports_provider.dart` بهذا المصدر بدل الحسابات
المحلية المكررة. لا شيء آخر ضمن هذه المهمة.

## هذه الجولة (تعديل بعد ملاحظات مراجعة مستقلة)

المراجعة المستقلة الأولى أعادت P0-01 بحالة **NOT APPROVED** وطلبت 3 أشياء
فقط، وهذا ما نُفِّذ هنا:

1. **التحقق من مركزية BalanceCalculator** — تم إعادة فحص كامل شجرة `lib/`
   بحثًا عن أي معادلة بديلة للرصيد النهائي. النتيجة: **لا توجد أي معادلة
   بديلة**. كل استخدام آخر لـ `DebtType.credit/debit` في المشروع هو إما:
   ربط زر بواجهة الإدخال، تسمية نصية ("له"/"عليه") أو لون عرض لمعاملة
   مفردة، فلترة (`FilterType`)، أو تسلسل بيانات (`toMap`/`fromMap`) —
   وليس أيًا منها حساب رصيد نهائي. لم يتغيّر أي كود في هذا البند (فحص
   فقط، بلا تعديل).
2. **مراجعة أسماء الاختبارات** — أعيدت كتابة `test/balance_calculator_test.dart`
   بالكامل: أُزيلت كل الأسماء التي تدّعي "سداد جزئي/كامل/زائد" (لأن
   `DebtType.credit` ليست Settlement)، واستُبدلت بأسماء تصف الحساب فعليًا
   فقط (مثل "100 عليه + 40 له = +60")، مع ملاحظة صريحة أعلى الملف توضّح
   أن هذه ليست اختبارات سداد وأن السداد الحقيقي في P0-02.
3. **اختبارات مركزية إضافية** — أُضيفت 8 اختبارات جديدة (تجميع عدة
   معاملات لنفس العملة، استقلال العملات المتعددة بشكل أوسع، تجميع مستقل
   لعميلين مختلفين ولمفتاح نصي عبر `calculateGroupedBalances`، وحالتا
   قائمة فارغة لكلتا الدالتين). التفاصيل الكاملة تحت "Tests Added".

**لم يُلمَس أي كود إنتاجي (production code) في هذه الجولة** — التعديل
الوحيد هو إعادة كتابة ملف الاختبار `test/balance_calculator_test.dart`.
الملفات الأربعة الأخرى (`balance_calculator.dart`,
`customer_details_provider.dart`, `home_provider.dart`,
`reports_provider.dart`) كما هي من الجولة السابقة دون أي تغيير إضافي.

## Changed Files (إجمالي منذ بداية P0-01)

| الملف | نوع التغيير | الجولة |
|---|---|---|
| `lib/core/balance/balance_calculator.dart` | جديد | الأولى |
| `lib/features/customers/providers/customer_details_provider.dart` | تعديل | الأولى |
| `lib/features/home/providers/home_provider.dart` | تعديل | الأولى |
| `lib/features/reports/providers/reports_provider.dart` | تعديل | الأولى |
| `test/balance_calculator_test.dart` | جديد (الأولى) ثم **أُعيدت كتابته بالكامل** (هذه الجولة) | الأولى + هذه |

لا ملفات أخرى تغيّرت في أي من الجولتين.

## Implementation (ملخص، دون تكرار تفاصيل الجولة الأولى)

- `BalanceCalculator.signedAmount`: `DebtType.debit` ("عليه") = `+amount`,
  `DebtType.credit` ("له") = `-amount`. هذا هو التعريف الوحيد المعتمد في
  كامل المشروع لحساب القيمة الموقّعة لأي معاملة.
- `BalanceCalculator.calculateBalances(List<DebtTransaction>)`: رصيد لكل
  عملة على حدة (`Map<Currency, double>`), بلا أي دمج بين العملات.
- `BalanceCalculator.calculateGroupedBalances<K>(...)`: نفس المنطق مجمّعًا
  حسب مفتاح تعسفي (عميل، شهر...)، تستخدمه `reports_provider.dart` حصريًا.
- الاستخدام الفعلي مؤكَّد الآن في 3 أماكن فقط ولا مكان رابع:
  `customer_details_provider.loadCustomerDetails`,
  `home_provider.{globalTotals, getCustomerBalance}`,
  `reports_provider.{getGlobalTotals, getCustomerTotals, getMonthlyTotals}`.

## Tests Added

ملف واحد: `test/balance_calculator_test.dart` — **17 حالة اختبار** موزعة
على 6 مجموعات:

1. `BalanceCalculator.signedAmount — debit موجب، credit سالب` (2 حالة)
2. `BalanceCalculator.calculateBalances — الحالات الأساسية والحدية من 05_FIRST_TASK.md` (6 حالات: كل حالات الاختبار الرسمية حرفيًا، بأسماء لا تدّعي "سداد")
3. `BalanceCalculator.calculateBalances — تجميع أكثر من معاملة لنفس العملة` (2 حالة جديدة)
4. `BalanceCalculator.calculateBalances — استقلال العملات (لا اختلاط)` (3 حالات، إحداها جديدة: "معاملات بعملات متعددة لا تُنتج رقمًا موحّدًا")
5. `BalanceCalculator.calculateGroupedBalances — تجميع مستقل (يُستخدم في التقارير)` (2 حالة جديدة: عملاء متعددون، ومفتاح نصي)
6. `BalanceCalculator — الحالات الحدية` (2 حالة: قائمة فارغة لكلتا الدالتين)

## Tests Run

**Tests NOT RUN — Flutter SDK unavailable.**

بيئة التنفيذ لا تحتوي Flutter SDK مثبَّتًا، ولا يوجد اتصال شبكة لتثبيته أو
لجلب `pub` packages (تم التحقق فعليًا: طلبات HTTP الصادرة تُرفض من وسيط
الشبكة برأس `x-deny-reason: host_not_allowed`؛ `which flutter` و`which dart`
لا يُعيدان أي نتيجة). لذلك:

- **flutter analyze:** NOT RUN.
- **flutter test:** NOT RUN. **لم يُدَّعَ نجاح أي اختبار.**
- **build:** NOT RUN.

**ما تم فعليًا بدل ذلك (مراجعة يدوية، وليست بديلًا عن التشغيل الحقيقي):**
تتبُّع كل حالة من الـ17 يدويًا سطرًا بسطر مقابل منطق `BalanceCalculator`
(الجدول أدناه)، والتحقق من توازن الأقواس/الأقواس المعقوفة في كل ملف
(صفر اختلاف في الجميع)، وفحص كل استيراد يدويًا للتأكد من صحة المسارات
وتوافر الرموز المستوردة (`DebtTransaction`, `DebtType`, `Currency` من
`debt_transaction.dart`; `BalanceCalculator` من `balance_calculator.dart`).
هذا **لا يغني إطلاقًا** عن تشغيل `flutter test` فعليًا، ولا يُعتبر دليل PASS.

### تتبّع يدوي لكل حالة (17/17)

| # | الاسم | الحساب اليدوي | متوقَّع | مطابق منطقيًا؟ |
|---|---|---|---|---|
| 1 | عليه موجبة | debit(100) | +100 | ✅ |
| 2 | له سالبة | credit(100) | -100 | ✅ |
| 3 | 100 عليه | debit100 | +100 | ✅ |
| 4 | 100 له | credit100 | -100 | ✅ |
| 5 | 100 عليه + 30 له | 100-30 | +70 | ✅ |
| 6 | 100 عليه + 40 له | 100-40 | +60 | ✅ |
| 7 | 100 عليه + 100 له | 100-100 | 0 | ✅ |
| 8 | 100 عليه + 130 له | 100-130 | -30 | ✅ |
| 9 | عدة "عليه" لنفس العملة | 100+25+5 | 130 | ✅ |
| 10 | خليط طويل لنفس العملة | 200-50+30-10+5 | 175 | ✅ |
| 11 | YER لا تُدمَج مع SAR | {yer:100, sar:50}, لا 150 | ✅ | ✅ |
| 12 | 3 عملات مستقلة | yer:60, sar:50, usd:-20 | ✅ | ✅ |
| 13 | 3 عملات لا تُنتج رقمًا موحدًا | لا 900, كل عملة=300 | ✅ | ✅ |
| 14 | تجميع 3 عملاء مستقلين | c1:70(yer), c2:50(usd), c3:-200(sar) | ✅ | ✅ |
| 15 | تجميع بمفتاح نصي | '2026-01':yer100, '2026-02':usd50 | ✅ | ✅ |
| 16 | قائمة فارغة (calculateBalances) | `{}` | فارغة | ✅ |
| 17 | قائمة فارغة (calculateGroupedBalances) | `{}` | فارغة | ✅ |

### الاختبارات القديمة (من قبل P0-01) — فحص يدوي لعدم التأثر

`database_test.dart`, `recurring_test.dart`, `widget_test.dart`,
`integration_test/app_test.dart` — لا تستدعي `BalanceCalculator` ولا أيًا
من الملفات الثلاثة المعدَّلة، وتوقيعات الدوال التي عدَّلناها
(`getCustomerTotals`, `getGlobalTotals`, `getMonthlyTotals`,
`getCustomerBalance`, `globalTotals`) لم تتغيّر شكليًا (نفس النوع
المُعاد). لم يُشغَّل أي منها فعليًا لنفس سبب غياب Flutter SDK.

## Results

**Tests NOT RUN — Flutter SDK unavailable.** لا أدّعي PASS. الحالة
تبقى معلَّقة على تشغيل فعلي في بيئة تملك Flutter SDK قبل أي اعتماد.

## Assumptions

1. "منطق الرصيد" المطلوب مركزته يقتصر على **الرصيد النهائي** (Net Balance)
   لكل عملة — وليس أي عملية حسابية أخرى تستخدم `amount`/`type` (مثل
   إجماليات التصنيف الخام في `getCategoryTotals`، أو مجاميع الفرز في
   `SortOption.highest/lowest`)، بناءً على توجيه المراجعة الصريح
   ("لا تغيّر وظائف ليست حساب رصيد نهائي").
2. حالات الاختبار التي تستخدم معاملتَي "عليه"/"له" معًا هي اختبارات لمنطق
   BalanceCalculator نفسه فقط، وليست بأي شكل اختبارات لسداد (Settlement)
   — أُعيدت تسميتها صراحة على هذا الأساس.
3. لم يُشغَّل أي أمر يتطلب Flutter SDK أو شبكة في أي من الجولتين.

## Deferred Issues (سُجِّلت فقط، لم تُعدَّل، خارج نطاق P0-01بالكامل)

هذه مشاكل حقيقية لوحظت أثناء الفحص (في هذه الجولة أو سابقًا)، **لم يُمَسّ
أي منها**:

1. **فلتر عليه/له** (`home_provider.dart`, `filteredCustomers`): الفلترة
   حاليًا تُرجع أي عميل لديه **أي معاملة تاريخية** من النوع المطلوب، وليس
   من لديه **رصيد حالي** موجب/سالب فعليًا في تلك العملة كما تنص المتطلبات
   (القسم 13). → P1-08.
2. **ترتيب الأعلى/الأقل مبلغًا** (`home_provider.dart`, `SortOption.highest/lowest`):
   يجمع القيم الخام (`t.amount`) بلا احتساب إشارة عليه/له، وليس الرصيد
   الحالي كما تنص المتطلبات. → P1-09.
3. **نقاط في التقارير** (`reports_provider.dart` / شاشات `reports/*`):
   - `getCategoryTotals()` تبقى إجماليًا خامًا غير موقَّع (وهذا صحيح لغرضها
     — عرض "إجمالي عليه" و"إجمالي له" منفصلَين — وليس خطأً بحد ذاته، لكنه
     يُسجَّل هنا للتوضيح فقط، لا حاجة لأي إصلاح).
   - تصدير PDF/Excel (`export_service.dart`) لا يزال غير مربوط بأي شاشة
     تقارير عدا كشف حساب عميل واحد. → P1-12.
4. **لون بطاقة رصيد العميل** (`customer_details_screen.dart`,
   `CustomerBalanceCard`, حوالي السطر 183): `amount >= 0 ? AppColors.credit
   : AppColors.debit` — بعد تصحيح الإشارة في P0-01، الرصيد الموجب الآن
   يمثّل "عليه" لا "له"، فيظهر بلون `AppColors.credit` (أخضر) رغم كونه
   دلاليًا "عليه". الرقم نفسه صحيح تمامًا؛ هذا تأثير بصري فقط. (مذكور سابقًا
   في الجولة الأولى، يبقى غير معالَج).
5. جميع بنود Audit الأخرى في `docs/PROJECT_MAP.md` القسم 12 (السداد،
   الحذف الصامت، Recurring، Backup، المرفقات، Premium، Lifetime، الإعدادات
   غير المتزامنة مع Backup، إلخ) — كما هي، غير مصلحة، بانتظار دورها في
   الترتيب الإجباري (P0-02 فصاعدًا).

## Decision Required

لا يوجد. القرار المالي (عليه=+، له=-) محسوم منذ الجولة السابقة ولم يتغيّر.

## Reviewer Focus

1. **الأهم الآن:** تشغيل `flutter analyze` و`flutter test test/balance_calculator_test.dart`
   فعليًا في بيئة تملك Flutter SDK، والتأكد أن الـ17 حالة تمر جميعها —
   هذا لم يحدث بعد في أي جولة، والتتبع اليدوي أعلاه ليس بديلًا عنه.
2. التأكد أن أسماء الاختبارات الجديدة لا تحمل أي إيحاء بأنها اختبارات سداد.
3. التأكد أن قائمة "Deferred Issues" أعلاه كافية ولا يوجد بند آخر أُصلِح
   بالخطأ خارج نطاق P0-01 (تم التحقق يدويًا أن الملف الوحيد المتغيّر في هذه
   الجولة هو `test/balance_calculator_test.dart`).
