# P0-04 to P0-07 Implementation Report

## Summary

Implemented P0-04 through P0-07 in one pass, preserving the existing P0-03 archive/audit design and avoiding P0-08/P1/P2/P3 scope.

## Changed Files

- `lib/data/repositories/customer_repository.dart`
- `lib/data/repositories/transaction_repository.dart`
- `lib/data/repositories/audit_repository.dart`
- `lib/data/repositories/recurring_repository.dart`
- `lib/core/services/audit_service.dart`
- `lib/core/services/archive_service.dart`
- `lib/features/transactions/providers/add_transaction_provider.dart`
- `lib/data/repositories/backup_repository.dart`
- `lib/core/services/backup_service.dart`
- `lib/core/services/activation_service.dart`
- `lib/features/backup/backup_screen.dart`
- `lib/features/backup/restore_screen.dart`
- `pubspec.yaml`

## New Files

- `lib/core/services/attachment_service.dart`
- `test/p0_04_to_p0_07_test.dart`
- `docs/progress/TASK_P0-04_TO_P0-07_REPORT.md`

## P0-04 Implementation

- Added transaction-aware repository APIs using `sqflite.Transaction`.
- Archive now performs read → validate → archive → audit in one SQLite transaction.
- AuditService accepts an optional transaction and never opens a separate connection when called inside an active transaction.
- Add Transaction now wraps customer creation, transaction creation, attachment reference update, and recurring schedule creation in one transaction.
- A file attachment is copied before the transaction completes; a failure rolls the DB transaction back. The original user-selected file is not deleted.

## P0-05 Implementation

- Backup schema is now `schemaVersion: 2`.
- Backup includes customers, transactions, payments, settlements, recurring schedules, settings, audit logs, and the actual SharedPreferences values used by the app.
- Restore validates schema version, required structures, and core required fields before changing the database.
- Schema version 1 remains accepted; missing `audit_logs`, payments, or recurring schedules are treated as absent for backward compatibility.
- Restore database writes use one SQLite transaction.
- SharedPreferences are restored after database validation/restore, with previous values restored if a later external-file operation fails.
- Backup package is now a portable ZIP containing `backup.json` plus physical attachment files.

## P0-06 Implementation

- Added `AttachmentService`.
- Attachments are stored under application Documents/`attachments/<transactionId>/`.
- Database stores only a relative/stable reference such as `attachments/<id>/attachment_<timestamp>.<ext>`.
- Maximum attachment size is 10 MB.
- Original selected files are never deleted by the app.
- Backup includes physical attachment files.
- Restore stages attachment files first and rejects unsafe `../` traversal or absolute attachment paths.
- Restore replaces the application attachment directory only after database restore succeeds and restores the old directory if replacement fails.

## P0-07 Implementation

- Debug test activation codes are scoped inside a `kDebugMode` branch.
- Added the required DEBUG/TEST ONLY warning.
- Release has no mock activation fallback path; production verification remains dependent on the remote endpoint.
- Existing placeholder endpoint remains explicitly marked `TODO(backend)`; no backend was invented.
- Lifetime activation is represented as non-expiring in `ActivationInfo.isActive`.
- Existing activation state remains in SharedPreferences and is included in backup/restore.

## Database Changes

No database schema version change was required for P0-04 to P0-07.

## Backup Format

```text
backup.zip
├── backup.json
└── attachments/
    └── <transaction-id>/
        └── image.ext
```

`backup.json` uses `schemaVersion = 2`.

## Attachment Format

The DB reference is relative, never an absolute filesystem path. Legacy absolute paths are normalized into backup-local attachment paths when the referenced file still exists; missing/invalid legacy files are not copied into the backup.

## Premium / Activation Boundary

Flutter handles activation state, expiry/lifetime representation, and debug test fallback. Secure issuance, server verification, revocation, and anti-tampering remain backend responsibilities.

## Tests

Added coverage for:

- Archive + Audit atomicity.
- SQLite rollback on a forced failure.
- ZIP backup creation and `schemaVersion = 2`.
- Presence of `audit_logs` in backup JSON.
- Attachment save, relative reference, lookup, deletion, and 10 MB rejection.
- Debug lifetime activation.
- Acceptance of schema version 1 without audit logs.

## Flutter Analyze

**Not executable in this environment.** The uploaded project points `flutter.sdk` to `C:\src\flutter`, but no Flutter SDK is mounted/available in the execution environment. Running `flutter analyze` therefore fails because the `flutter` command is unavailable.

## Debug Build

**Not executable in this environment** for the same missing Flutter SDK reason.

## Release Build

**Not executable in this environment** for the same missing Flutter SDK reason.

## Problems

- Flutter/Dart SDK is not available in the execution environment, so final analyzer/test/debug/release verification cannot honestly be marked passed.
- No project dependency or backend was invented to compensate for the missing SDK.

## Deferred Issues

- Production activation backend remains intentionally deferred and is documented as `TODO(backend)`.
- No P0-08 or later phase work was performed.

## Decision Required

Before calling the task production-verified, run the four required commands on a machine with Flutter SDK configured:

```bash
flutter analyze
flutter test
flutter build apk --debug
flutter build apk --release
```

If any command reports a code issue, fix it before release.


## Corrective Pass — Analyzer Feedback

Fixed the reported P0 test issues:
- Removed the unused `recurring_schedule.dart` import from `test/p0_04_to_p0_07_test.dart`.
- Fixed database closing from `AppDatabase().database.close()` to `(await AppDatabase().database).close()` because `database` returns `Future<Database>`.
- Added `flutter_test` to `dev_dependencies` so test imports are declared correctly.

The remaining `no_leading_underscores_for_local_identifiers` messages are pre-existing lint/info findings in older tests and are not P0-04→P0-07 correctness errors.


## Test correction pass
- Initialized Flutter test binding in `test/p0_04_to_p0_07_test.dart` before using `path_provider`/platform channels.
- Moved the integration test from `test/integration_test/` to the conventional root `integration_test/` directory so Flutter detects the integration_test plugin correctly.

## Corrective pass: flutter test runtime failures

- `test/p0_04_to_p0_07_test.dart`: added a `path_provider` MethodChannel mock for VM tests so backup/attachment tests can resolve the application documents directory without a platform plugin.
- `test/p0_04_to_p0_07_test.dart`: database close is now awaited before temporary-directory cleanup.
- `test/database_test.dart`: uses an isolated temporary sqflite FFI database path and awaits database close, preventing cross-test database locking/timeouts.
- `integration_test/app_test.dart`: remains a real integration test; the `integration_test plugin was not detected` message can appear when the integration test is discovered by plain `flutter test`. It is a runner warning, not an application failure.
