# عقد Backend لتفعيل Wasla Debt

التطبيق أصبح يرسل `deviceId` مع رمز التفعيل، ويحفظ `deviceId` مع حالة الترخيص. كما أن `isPremium()` يرفض الترخيص إذا كان محفوظًا لجهاز مختلف، لذلك لا يمكن نقل التفعيل عبر نسخة Backup إلى جهاز آخر.

## POST
`/v1/activation/verify`

### Request
```json
{
  "code": "WASLA-XXXX-XXXX-XXXX",
  "deviceId": "android-id"
}
```

### Success
```json
{
  "valid": true,
  "deviceId": "android-id",
  "duration": "30d"
}
```

`duration` القيم المدعومة: `30d`, `90d`, `180d`, `365d`, `lifetime`.

### Invalid
```json
{
  "valid": false
}
```

الخادم يجب أن يرفض أي رمز مرتبط بـ `deviceId` مختلف. عنوان الخادم الحالي في التطبيق ما زال Placeholder (`api.wasla-debt.example.com`) ولا يمكن تحويله إلى Backend حقيقي من داخل مشروع Flutter وحده.
