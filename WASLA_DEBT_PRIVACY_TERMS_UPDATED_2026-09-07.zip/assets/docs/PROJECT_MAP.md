# PROJECT_MAP.md — Wasla Debt (Audit — Phase 0)

> تم إنشاء هذا الملف في مرحلة Audit فقط. لم يتم تعديل أي كود.
> بيئة التنفيذ الحالية لا تملك Flutter SDK مثبّتًا ولا اتصال شبكة (pub get غير ممكن)،
> لذلك لم يتم تشغيل `flutter analyze` أو الاختبارات أو أي Build في هذه المرحلة.
> هذا القيد سيؤثر على مرحلة P0-01 (تشغيل الاختبارات) وسيُوثّق هناك كـ "DECISION REQUIRED" إن استمر.

---

## 1. بنية المشروع

```
lib/
  app/            # Theme فقط فعليًا (app.dart و router.dart ملفان فارغان تمامًا وغير مستخدَمين)
  core/
    constants/    # فارغ (app_constants.dart = 0 سطر)
    errors/       # فارغ (exceptions.dart = 0 سطر)
    extensions/   # فارغ
    services/     # activation, backup, export, google_drive, recurring
    utils/        # فارغ (date_utils.dart = 0 سطر)
    widgets/      # فارغ (loading_widget.dart = 0 سطر)
  data/
    database/     # app_database.dart, database_schema.dart
    models/       # customer, debt_transaction, settlement, recurring_schedule, app_settings, backup_metadata
    repositories/ # customer, transaction, recurring, settings, backup
  features/       # about, backup, customers, home, onboarding, reports, search, settings, sharing, subscription, transactions
  main.dart       # يحتوي فعليًا على MyApp + SplashScreen (بدل app/app.dart)
test/             # 3 ملفات اختبار فقط (CRUD عميل، CRUD recurring، widget ترحيبي)
android/          # مشروع Android قياسي (لم تُفحص تفاصيل التوقيع/الإصدار في هذه الجولة)
```

**ملاحظة بنيوية:** `lib/app/app.dart` و `lib/app/router.dart` ملفان فارغان (0 سطر) وغير مستوردين من أي مكان.
منطق التطبيق (`MyApp`, `SplashScreen`, التنقل عبر `Navigator.push` مباشرة بدون router) موجود بالكامل في `lib/main.dart`. هذان الملفان كود ميت.

**ملفات فارغة أخرى (0 سطر) تبدو stubs غير مكتملة:**
`core/constants/app_constants.dart`, `core/errors/exceptions.dart`, `core/extensions/context_extensions.dart`,
`core/utils/date_utils.dart`, `core/widgets/loading_widget.dart`,
`features/backup/providers/backup_provider.dart`,
`features/customers/widgets/customer_balance_card.dart` (لكن يوجد صنف `CustomerBalanceCard` معرّف فعليًا **داخل** `customer_details_screen.dart` نفسه، وليس في هذا الملف),
`features/customers/widgets/transaction_list_item.dart`,
`features/home/widgets/drawer_item.dart`,
`features/onboarding/onboarding_provider.dart` (يوجد `onboarding_screen.dart` بمنطق خاص به بدلاً منه),
`features/search/providers/search_provider.dart` و `features/search/search_screen.dart` (ميزة البحث كشاشة مستقلة **غير منفذة إطلاقًا**؛ البحث الفعلي الوحيد هو حقل نصي داخل `home_provider.dart`),
`features/subscription/providers/subscription_provider.dart` (منطق الاشتراك موجود في `activation_screen.dart` و `activation_service.dart` مباشرة),
`features/transactions/widgets/{amount_field,currency_selector,customer_field,type_selector}.dart` (الحقول الفعلية مبنية inline داخل `add_transaction_screen.dart`).

---

## 2. أهم الملفات

- `lib/main.dart` — نقطة الدخول، MaterialApp، Splash، تشغيل المهام المتكررة والنسخ التلقائي عند الإقلاع.
- `lib/data/database/app_database.dart` + `database_schema.dart` — تعريف SQLite الكامل.
- `lib/data/repositories/*` — طبقة الوصول للبيانات (CRUD خام بدون منطق مالي).
- `lib/features/home/providers/home_provider.dart` — الشاشة الرئيسية: بحث/فرز/فلترة + حساب رصيد مكرر خاص بها.
- `lib/features/customers/providers/customer_details_provider.dart` — تفاصيل العميل + حساب رصيد مكرر آخر.
- `lib/features/reports/providers/reports_provider.dart` — 4 دوال حساب مستقلة (customer/global/monthly/category totals).
- `lib/core/services/{recurring_service,backup_service,export_service,activation_service,google_drive_service}.dart`.

---

## 3. مكان قاعدة البيانات

`lib/data/database/app_database.dart` (Singleton، sqflite، اسم الملف `wasla_debt.db`، `version: 1`، `PRAGMA foreign_keys = ON`).
الجداول معرّفة في `lib/data/database/database_schema.dart`: `customers`, `transactions`, `settlements`, `recurring_schedules`, `app_settings`, `backup_metadata`.
لا يوجد أي migration فعلي في `_onUpgrade` (تعليق فارغ فقط) — يطابق فجوة P0-05/P2 (migrations أكثر صرامة).

---

## 4. مكان منطق الرصيد — **المشكلة الأهم في المشروع**

**لا يوجد Balance Calculator مركزي إطلاقًا.** نفس صيغة الحساب مكرّرة بشكل مستقل في 4 أماكن مختلفة:

1. `customer_details_provider.dart` → `_calculateBalances()`
2. `home_provider.dart` → `getCustomerBalance()` **و** `HomeState.globalTotals` (نسختان داخل نفس الملف)
3. `reports_provider.dart` → `getCustomerTotals()`, `getGlobalTotals()`, `getMonthlyTotals()` (3 نسخ داخل نفس الملف)
4. `export_service.dart` — لا يحسب بنفسه، بل يستقبل `balances` جاهزة من المتصل (المتصل الوحيد حاليًا هو `customer_details_screen.dart`، الذي يمرر `state.balances` القادم من النسخة رقم 1).

كل هذه النسخ تستخدم نفس المعادلة حرفيًا:
```dart
double amount = t.amount;
if (t.type == DebtType.debit) amount = -amount;
balances[t.currency] += amount;
```

### ⚠️ خلل حرج مكتشف: عكس المعنى المالي بين واجهة الإدخال ومنطق الحساب

في `add_transaction_screen.dart` (حوالي السطر 207–224)، ربط الأزرار هو:
```dart
label: 'له'   → type: DebtType.credit
label: 'عليه' → type: DebtType.debit
```

بينما معادلة الحساب في كل الأماكن الأربعة أعلاه تفعل:
```dart
credit → +amount   (أي "له" تُحتسب موجبة)
debit  → -amount   (أي "عليه" تُحتسب سالبة)
```

هذا **معاكس تمامًا** لتعريف `01_REQUIREMENTS.md` القسم 4 وحالات الاختبار في `05_FIRST_TASK.md`:
> "100 عليه = **+100**", "100 له = **-100**"

أي أن التطبيق حاليًا، لو أُدخلت معاملة "عليه" من الشاشة، سيظهر الرصيد **سالبًا** بدل موجب. هذا ليس مجرد تكرار كود؛ إنه انعكاس في المعنى المالي نفسه، ويجب أن يكون أول قرار يُحسم صراحة (تسمية `DebtType` أو قلب الإشارة) قبل أي إصلاح آخر في P0-01. **سيُسجَّل كـ DECISION REQUIRED في تقرير P0-01.**

### مشاكل إضافية في منطق الفرز/الفلترة المرتبطة بالرصيد (`home_provider.dart`)

- `SortOption.highest` / `lowest` يستخدمان `transactions.fold(0.0, (sum, t) => sum + t.amount)` — **مجموع القيم الخام دون احتساب الإشارة (credit/debit)**، وليس الرصيد الحالي كما تنص المتطلبات (القسم 13: "الأعلى مبلغًا يعني أعلى رصيد حالي"). يطابق P1-09.
- الفلترة حسب `FilterType.credit/debit` تُرجع أي عميل لديه **أي معاملة** من هذا النوع تاريخيًا، وليس من لديه **رصيد حالي** موجب/سالب في تلك العملة كما تنص المتطلبات (القسم 13). يطابق P1-08.
- لا تُدرَج `settlements` (السداد) في أي من الحسابات الأربعة، لأن نموذج السداد غير مفعّل في طبقة Repository/Service أصلًا (انظر البند 6 أدناه).

---

## 5. مكان المعاملات

- النموذج: `lib/data/models/debt_transaction.dart` (`DebtType {credit, debit}`, `Currency {yer, sar, usd}`).
- الـRepository: `lib/data/repositories/transaction_repository.dart` — يوفر فقط `insertTransaction`, `deleteTransaction` (حذف نهائي مباشر، **لا Soft Delete/Archive**)، `getAllTransactions`, `getTransactionsByCustomer`.
- **لا توجد دالة `updateTransaction`** في الـRepository رغم أن `01_REQUIREMENTS.md` القسم 3 ينص صراحة: "يجب دعم تعديل المعاملة". يطابق فجوة P1-01.
- لا يوجد فصل بين "تاريخ العملية" و"وقت العملية" في النموذج: الحقل الوحيد هو `date: int` (timestamp واحد لا يميّز بين تاريخ أدخله المستخدم وتاريخ تقريبي). يطابق فجوة P1-06/القسم 15.
- `customer_details_provider.dart.deleteTransaction()` يحذف المعاملة نهائيًا فعليًا، مع تعليق بالعربية في الكود يعترف بذلك:
  > "سنقوم بالأرشفة بدلاً من الحذف الكامل (حسب الخطة)... ولكن في هذه المرحلة سنحذفها مؤقتاً للتبسيط"
  هذا يخالف `01_REQUIREMENTS.md` القسم 8 صراحة ("لا يكون الحذف النهائي للمعاملة المالية هو المسار الافتراضي"). يطابق P0-03.

---

## 6. مكان السداد (settlement)

- **موجود جزئيًا فقط على مستوى النموذج وقاعدة البيانات، غير منفّذ على مستوى منطق التطبيق.**
- النموذج: `lib/data/models/settlement.dart` (يحتوي `transactionId`, `amount`, `currency`, `settledAt`...).
- الجدول: `settlements` معرّف في `database_schema.dart` ومُضمَّن في Backup/Restore (`backup_repository.dart`).
- **لا يوجد** `SettlementRepository` ولا أي Service للسداد، ولا أي شاشة/زر لإضافة سداد، ولا أي استخدام لنموذج `Settlement` خارج تعريفه والمخطط.
- ملاحظة تصميم يجب حسمها في P0-02: جدول `settlements` مرتبط بـ `transactionId` مفرد (`FOREIGN KEY (transactionId) REFERENCES transactions`)، أي أن السداد الحالي في المخطط مُصمَّم كسداد **لمعاملة واحدة بعينها**، وليس سدادًا عامًا لرصيد عميل/عملة كما يوحي القسم 5 من `01_REQUIREMENTS.md` (سداد جزئي/كامل/زائد على مستوى الرصيد الكلي). هذا سيحتاج قرارًا صريحًا عند تنفيذ P0-02 (هل نُبقي الربط بمعاملة واحدة، أم نجعل السداد مرتبطًا بالعميل+العملة مباشرة؟).
- **الخلاصة المطلوبة من P0-01 حسب الأمر الرئيسي:** بما أن السداد غير منفذ فعليًا، سيتم اختبار الجزء القابل للاختبار فقط (بدون سداد) في P0-01، وتسجيل أن P0-02 مطلوبة لاحقًا — هذا مطابق لما هو موثق مسبقًا في `05_FIRST_TASK.md` نفسه.

---

## 7. مكان Recurring

- النموذج: `lib/data/models/recurring_schedule.dart`.
- الـRepository: `lib/data/repositories/recurring_repository.dart` (CRUD + `getEnabledSchedules`, `toggleSchedule`).
- الـService: `lib/core/services/recurring_service.dart` → `processDueSchedules()`, يُستدعى من `main.dart` عند بدء التطبيق فقط (`unawaited(...)`، لا يوجد تنفيذ خلفي حقيقي — معلّق بوضوح في كود `main.dart`).
- **مشاكل مكتشفة (لملف لاحقًا تحت P1-02/P1-03/P1-04، خارج نطاق P0-01):**
  - `processDueSchedules()` ينشئ **معاملة واحدة فقط** لكل جدولة مستحقة بغض النظر عن عدد المرات الفائتة (مثلاً جدولة يومية لم تُشغَّل لمدة أسبوع تُنتج معاملة واحدة فقط لا 7)، وهو ما يخالف صراحة `01_REQUIREMENTS.md` القسم 6: "المواعيد الفائتة لا تُسقط بصمت". يطابق P1-04.
  - `_calculateNextRun()` يحسب الموعد التالي من `DateTime.now()` وليس من `schedule.nextRun` + الفترة، مما يسبب انزلاقًا تراكميًا في المواعيد عند التأخر في التشغيل.
  - الحساب الشهري: `DateTime(now.year, now.month + 1, now.day)` — لا يعالج نهاية الشهر (يوم 31 في شهر أقصر يتدحرج تلقائيًا في Dart إلى الشهر الذي يليه بدل استخدام آخر يوم في الشهر كما تنص المتطلبات القسم 6). يطابق P1-03.
  - عدم تطابق نوع بيانات العملة بين الجداول: `recurring_schedules` تفرض `currency IN ('yer','sar','usd')` (أحرف صغيرة) بينما `transactions`/`settlements` تفرض `('YER','SAR','USD')` (أحرف كبيرة). `RecurringSchedule.toMap()` يستخدم `currency.name` (صغير) بينما `DebtTransaction.toMap()` يستخدم `currency.name.toUpperCase()`. تناقض في القيود (Constraints) يجب توحيده — سيُسجَّل كملاحظة إضافية عند الوصول لـP1-02، ليس ضمن P0-01.

---

## 8. مكان Backup/Restore

- الـService: `lib/core/services/backup_service.dart` (إنشاء نسخة، فرض الحد الأقصى لعدد النسخ، نسخ تلقائي عند الإقلاع إن مفعّل).
- الـRepository: `lib/data/repositories/backup_repository.dart` (`buildBackupData`, `saveBackup` كملف JSON، `restoreBackup` — **منفّذ داخل `db.transaction()` فعليًا، أي ذري بالفعل**، مع فحص `schemaVersion == 1` قبل الاستعادة).
- **نقاط إيجابية موجودة بالفعل:** الاستعادة ذرية (transaction واحدة تحذف ثم تُدرج، rollback تلقائي عند الفشل)، `recurring_schedules` مُضمَّنة، توافق عكسي مع نسخ قديمة لا تحتوي عليها.
- **فجوات مكتشفة (تخص P0-05/P0-06/P1-10، خارج نطاق P0-01):**
  - فحص `schemaVersion` بدائي (مساواة صارمة بـ `1` فقط، لا Validation بنيوي أعمق للحقول/الأنواع قبل الإدراج).
  - **لا تُضمَّن المرفقات (الصور) في النسخة الاحتياطية نفسها** — يُحفظ `imagePath` فقط كنص داخل جدول `transactions`، وهذا يخالف صراحة `01_REQUIREMENTS.md` القسم 9: "حفظ مسار ملف الصورة فقط لا يعتبر نسخة احتياطية للصورة". يطابق P0-06.
  - **الإعدادات الفعلية غير مُضمَّنة في Backup رغم وجود جدول `app_settings` مُضمَّن شكليًا** — انظر البند التالي، هذه مشكلة مؤكدة وليست افتراضًا.

---

## 9. مكان التقارير

- شاشات: `report_summary_screen.dart` (ملخص عام)، `report_monthly_screen.dart` (شهري)، `report_categories_screen.dart` (له/عليه)، `report_movement_screen.dart` (حركة عميل)، `report_details_screen.dart` (تفاصيل)، تُجمَّع في `reports_main_screen.dart`.
- المزوّد: `reports_provider.dart` (انظر البند 4 — 4 نسخ حساب مستقلة داخل نفس الملف).
- **تصدير PDF/Excel (`export_service.dart`) غير مربوط بشاشات التقارير إطلاقًا** — الاستدعاء الوحيد لـ `ExportService.generatePDF/generateExcel` في كامل المشروع هو من `customer_details_screen.dart` (كشف حساب عميل واحد). شاشات الملخص/الشهري/التصنيفات/الحركة لا تملك أي زر أو مسار لتصدير PDF/Excel حاليًا. هذا يخالف جزئيًا `01_REQUIREMENTS.md` القسم 14 ("PDF وExcel والشاشات الأساسية يجب أن تعتمد على نفس منطق الحساب") لأن التصدير لا يغطي إلا شاشة واحدة من أصل خمس، ويعتمد على نسخة حساب رابعة منفصلة (رقم 4 في البند 4 أعلاه) بدل منطق `reports_provider`. يطابق P1-12.

---

## 10. مكان Premium

- الـService: `lib/core/services/activation_service.dart`.
- الشاشة: `lib/features/subscription/activation_screen.dart`.
- الحد المجاني: `_freeCustomersLimit = 30` (مطابق تمامًا لـ `01_REQUIREMENTS.md` القسم 12)، ويُحتسب عبر `CustomerRepository.countActiveCustomers()` (عملاء غير مؤرشفين فقط) — **متسق وصحيح**.
- **Backend فعلي غير موجود فعلًا** — `_verifyEndpoint` يشير إلى `api.wasla-debt.example.com` (نطاق تجريبي وهمي)، والتحقق الفعلي الوحيد العامل هو مسار احتياطي بأكواد تفعيل ثابتة داخل الكود، **محصور صراحة بـ `kDebugMode`** (تعليق في الكود يوثّق هذا الوعي مسبقًا). يطابق P0-07 — يحتاج توثيق رسمي في التقرير بأن هذا ليس Backend إنتاجيًا، وليس إصلاح كود إضافي بالضرورة.
- **Lifetime مُمثَّل كمدة اصطناعية 100 سنة** (`now + 365*100*24*60*60*1000`) بدل حالة صريحة منفصلة، بينما `ActivationStatus` نفسه لا يحتوي قيمة `lifetime` (فقط `active, used, expired, revoked`؛ التمييز الوحيد هو حقل `duration == 'lifetime'` نصي). يخالف `01_REQUIREMENTS.md` القسم 11 صراحة. يطابق P0-08.

---

## 11. الاختبارات الحالية

ثلاثة ملفات فقط في `test/`:

1. `database_test.dart` — CRUD كامل للعميل (إدراج/قراءة/تعديل/أرشفة/حذف نهائي) عبر `sqflite_common_ffi`.
2. `recurring_test.dart` — CRUD لجدولة متكررة واحدة (إدراج/تفعيل-تعطيل/حذف).
3. `widget_test.dart` — يتحقق أن `MyApp` تعرض نص الترحيب من شاشة Onboarding (نص موجود فعليًا في `onboarding_screen.dart`، الاختبار متسق مع الكود).
4. `integration_test/app_test.dart` — لم يُفحص محتواه بالتفصيل بعد في هذه الجولة (مذكور هنا للإكمال).

**لا يوجد أي اختبار حاليًا لـ:** حساب الرصيد/الإشارة المالية، فصل العملات، السداد، الأرشفة الفعلية للمعاملات، منطق نهاية الشهر في التكرار، المواعيد الفائتة، Backup/Restore، المرفقات، Premium، أو التقارير. هذا يطابق حرفيًا الفجوة الموصوفة في `01_REQUIREMENTS.md` القسم 16، وهو ما ستبدأ P0-01 بمعالجته جزئيًا (اختبارات الرصيد الأساسية والحدية فقط).

---

## 12. المشاكل التي اكتشفتها (ملخص، مرتّبة حسب الأولوية التقريبية لخريطة P0/P1)

| # | المشكلة | الفجوة المقابلة |
|---|---|---|
| 1 | **انعكاس معنى عليه/له بين واجهة الإدخال (`add_transaction_screen.dart`) ومعادلة الحساب** — "له" تُخزَّن كـ `credit` (+) و"عليه" كـ `debit` (-)، عكس ما تطلبه حالات الاختبار الرسمية | P0-01 (الأهم) |
| 2 | 4 نسخ مستقلة من معادلة حساب الرصيد في 3 ملفات مختلفة، بلا Balance Calculator مركزي | P0-01 |
| 3 | الفرز "الأعلى/الأقل مبلغًا" يجمع القيم الخام بلا إشارة credit/debit، وليس الرصيد الحالي | P1-09 |
| 4 | الفلترة عليه/له تعتمد على وجود أي معاملة تاريخية، لا على الرصيد الحالي | P1-08 |
| 5 | حذف المعاملة نهائي فعليًا رغم تعليق في الكود يعترف بأنه يجب أن يكون أرشفة | P0-03 |
| 6 | لا توجد دالة تعديل معاملة (`updateTransaction`) في `TransactionRepository` | P1-01 |
| 7 | لا فصل بين تاريخ/وقت العملية — حقل `date` واحد فقط | P1-06 |
| 8 | السداد (Settlement) موجود كنموذج/جدول فقط، بلا Repository/Service/UI؛ وربطه الحالي بمعاملة مفردة بدل رصيد عميل+عملة يحتاج قرارًا | P0-02 |
| 9 | `processDueSchedules` يُسقط المواعيد الفائتة المتعددة صامتًا (ينفّذ مرة واحدة فقط) | P1-04 |
| 10 | حساب `nextRun` الشهري لا يعالج نهاية الشهر (تدحرج تلقائي في Dart) | P1-03 |
| 11 | تضارب حالة أحرف قيمة العملة (كبيرة/صغيرة) بين جدول المعاملات وجدول التكرار | يُسجَّل لاحقًا مع P1-02 |
| 12 | لا تُضمَّن ملفات المرفقات (الصور) في Backup، فقط المسار النصي | P0-06 |
| 13 | الإعدادات الفعلية المستخدمة (`SharedPreferences` عبر `settings_provider.dart`) لا علاقة لها بجدول `app_settings` المُضمَّن في Backup؛ `SettingsRepository` **غير مستخدَم إطلاقًا في كامل المشروع** — أي أن استعادة نسخة احتياطية لن تُعيد أي إعداد فعلي يستخدمه المستخدم | P1-10 |
| 14 | لا تصدير PDF/Excel من أي شاشة تقارير عدا كشف حساب عميل واحد؛ التصدير الموجود يعتمد على نسخة حساب رابعة منفصلة عن `reports_provider` | P1-12 |
| 15 | Premium Backend وهمي (نطاق تجريبي)، والتحقق الفعلي الوحيد محصور بـ `kDebugMode` — موثّق بوعي في الكود لكن يحتاج توثيقًا رسميًا في التقرير | P0-07 |
| 16 | Lifetime مُمثَّل كمدة 100 سنة اصطناعية بدل حالة صريحة في `ActivationStatus` | P0-08 |
| 17 | لا توجد أي اختبارات لمنطق الرصيد/السداد/العملات/الأرشفة/التكرار/Backup/المرفقات/Premium/التقارير | القسم 16 + P0-01..P1-* |
| 18 | ملفات كود ميت/فارغة عديدة (`app/app.dart`, `app/router.dart`, وحدات widgets/providers فارغة استُبدلت بمنطق inline) | تنظيف P2 |
| 19 | لا migrations فعلية في `_onUpgrade` رغم وجود `version` في `openDatabase` | P2 |
| 20 | ميزة "بحث" كشاشة مستقلة (`search_screen.dart`) ملف فارغ تمامًا وغير مستخدم؛ البحث الفعلي حقل داخل الشاشة الرئيسية فقط | يُسجَّل كملاحظة (لا Fix مرقّم مخصص له في `02_FIXES.md`) |

---

## 13. المتطلبات غير المنفذة (بالإشارة إلى `01_REQUIREMENTS.md`)

- القسم 3: تعديل المعاملة — غير مدعوم (لا `update` في Repository، لا شاشة تعديل).
- القسم 3/15: فصل تاريخ عملية عن وقتها — غير موجود، حقل واحد فقط.
- القسم 4: منطق مركزي موحّد للرصيد — غير موجود (4 نسخ) + انعكاس الإشارة (خلل 1 أعلاه).
- القسم 5: السداد بالكامل (جزئي/كامل/زائد) — غير منفّذ في منطق التطبيق.
- القسم 6: عدم إسقاط المواعيد الفائتة صامتًا + سياسة نهاية الشهر — غير منفّذين.
- القسم 8: عدم اعتماد الحذف النهائي كمسار افتراضي — مخالَف حاليًا (حذف مباشر).
- القسم 9: نسخ احتياطي يشمل المرفقات نفسها والإعدادات المستخدمة فعليًا — كلاهما غير مُحقَّق فعليًا رغم وجود بنية جزئية.
- القسم 11: تمثيل Lifetime كحالة صريحة — غير محقَّق (مدة اصطناعية).
- القسم 13: فلاتر عليه/له والأعلى مبلغًا بالاعتماد على الرصيد الحالي — غير محقَّق (يعتمد على تاريخ المعاملات الخام).
- القسم 14: توحيد PDF/Excel/الشاشات على نفس منطق الحساب — غير محقَّق (تصدير PDF/Excel يغطي شاشة واحدة فقط، بمنطق حساب منفصل).
- القسم 16: تغطية اختبارات شاملة — غير محقَّقة (3 ملفات اختبار CRUD/واجهة فقط، بلا اختبارات مالية).

---

## 14. الملفات المتوقع تعديلها في المهام القادمة (تقديري، للتخطيط فقط — لا تعديل حتى الآن)

- **P0-01 (التالية مباشرة):**
  - `lib/data/models/debt_transaction.dart` (أو مكان جديد) — احتمال إنشاء `lib/core/balance/balance_calculator.dart` جديد.
  - `lib/features/customers/providers/customer_details_provider.dart` — استبدال `_calculateBalances` باستدعاء المنطق المركزي.
  - `lib/features/home/providers/home_provider.dart` — استبدال `getCustomerBalance`/`globalTotals`.
  - `lib/features/reports/providers/reports_provider.dart` — استبدال الدوال الأربع.
  - `lib/features/transactions/add_transaction_screen.dart` — حسم انعكاس عليه/له (بعد DECISION REQUIRED).
  - `test/` — ملف اختبار جديد لمنطق الرصيد (مثلاً `test/balance_calculator_test.dart`).
- **لاحقًا (خارج نطاق P0-01، لا تُلمس الآن):** `settlement_repository.dart` (جديد، P0-02)، `transaction_repository.dart` (حذف/تعديل، P0-03/P1-01)، `backup_repository.dart` + `settings_repository.dart`/`settings_provider.dart` (توحيد مصدر الإعدادات، P1-10)، `export_service.dart` + شاشات `reports/*` (P1-12)، `recurring_service.dart` (P1-02/03/04)، `activation_service.dart` (P0-08).

---

**الحالة:** Audit مكتمل. لم يُعدَّل أي كود. بانتظار التعليمات للبدء في P0-01 حسب الأمر الرئيسي.
