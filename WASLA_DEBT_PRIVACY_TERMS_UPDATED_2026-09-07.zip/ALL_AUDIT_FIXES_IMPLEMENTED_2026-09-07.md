# Wasla Debt — Ultimate Audit Fixes Implemented

Date: 2026-09-07

Implemented from the Ultimate Full Project Audit without changing dependencies:

## P0
- Fixed backup restore so an archive with no attachment files never replaces the live attachments directory with an empty directory.
- Restore now creates a safety backup before replacing the live database.
- Added backup size (100 MB) and attachment-count limits.
- Financial formatting now preserves up to two decimal places instead of rounding display/export values to whole units.
- Input/update/transfer/recurring amounts are restricted to at most two decimal places.
- Removed `android/key.properties` and its real signing credentials from the distributable source tree.
- Release builds no longer silently fall back to debug signing; release signing must be explicitly configured.
- Removed the nested `assets/` project snapshot that caused stale source copies to be analyzed.

## P1
- Customer-specific Add Transaction/Add Payment flows now carry `customerId`, not only the display name.
- Add Payment now handles duplicate customer names with an explicit chooser.
- Added archived transaction restore UI and audited restore service.
- Added recurring schedule management UI: list, enable/disable, edit, delete.
- Transfer now validates the destination customer's projected debt/credit limits.
- Google Drive requests now have explicit network timeouts.
- Google Drive backups use `appProperties` to identify Wasla backups instead of filename substring matching.
- Added confirmation before customer/transaction archiving and Drive restore.

## P2 / UX
- Fixed nullable error-state clearing semantics in affected Riverpod states.
- Added semantic tooltips to important icon-only controls.
- Corrected payment-direction colors so `دفع لي` is credit/green and `دفعت له` is debit/red.
- Customer detail balance card now shows only currencies actually in the selected balance context.
- Improved backup/restore user messages so raw filesystem paths/exceptions are not shown.
- Android launcher label is now `دفتر الديون`.
- Added MoneyFormat and MoneyValidator regression tests.
- Removed confirmed empty Dart stubs and stale nested project artifacts.

## Remaining verification gates
The current environment does not contain Flutter/Dart SDK, so the final runtime commands must still be executed on the development machine:

```bash
flutter clean
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

Before a production release, configure a fresh/rotated release keystore outside the source archive and verify Google OAuth/Drive and activation backend with the exact release application identity.
